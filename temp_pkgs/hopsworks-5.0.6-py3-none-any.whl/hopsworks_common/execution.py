#
#   Copyright 2022 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

from __future__ import annotations

import json

import humps
from hopsworks_apigen import public
from hopsworks_common import client, constants, usage, util
from hopsworks_common.core import execution_api
from hopsworks_common.engine import execution_engine


@public("hopsworks.execution.Execution", "hsfs.core.execution.Execution")
class Execution:
    def __init__(
        self,
        id=None,
        state=None,
        final_status=None,
        submission_time=None,
        stdout_path=None,
        stderr_path=None,
        app_id=None,
        hdfs_user=None,
        args=None,
        progress=None,
        user=None,
        files_to_remove=None,
        duration=None,
        monitoring=None,
        type=None,
        href=None,
        job=None,
        **kwargs,
    ):
        self._id = id
        self._final_status = final_status
        self._state = state
        self._submission_time = submission_time
        self._stdout_path = stdout_path
        self._stderr_path = stderr_path
        self._args = args
        self._progress = progress
        self._user = user
        self._duration = duration
        self._monitoring = monitoring
        self._app_id = app_id
        self._hdfs_user = hdfs_user
        self._job = job

        self._execution_engine = execution_engine.ExecutionEngine()
        self._execution_api = execution_api.ExecutionApi()

    @classmethod
    def from_response_json(cls, json_dict, job):
        json_decamelized = humps.decamelize(json_dict)
        if "count" not in json_decamelized:
            return cls(**json_decamelized, job=job)
        if json_decamelized["count"] == 0:
            return []
        return [cls(**execution, job=job) for execution in json_decamelized["items"]]

    def update_from_response_json(self, json_dict):
        json_decamelized = humps.decamelize(json_dict)
        self.__init__(**json_decamelized)
        return self

    @public
    @property
    def id(self):
        """Id of the execution."""
        return self._id

    @public
    @property
    def job_name(self):
        """Name of the job the execution belongs to."""
        return self._job.name

    @public
    @property
    def job_type(self):
        """Type of the job the execution belongs to."""
        return self._job.job_type

    @public
    @property
    def state(self):
        """Current state of the execution.

        Can be: `INITIALIZING`, `INITIALIZATION_FAILED`, `FINISHED`, `RUNNING`, `ACCEPTED`,
        `FAILED`, `KILLED`, `NEW`, `NEW_SAVING`, `SUBMITTED`, `AGGREGATING_LOGS`,
        `FRAMEWORK_FAILURE`, `STARTING_APP_MASTER`, `APP_MASTER_START_FAILED`,
        `GENERATING_SECURITY_MATERIAL`, or `CONVERTING_NOTEBOOK`.
        """
        return self._state

    @public
    @property
    def final_status(self):
        """Final status of the execution. Can be UNDEFINED, SUCCEEDED, FAILED or KILLED."""
        return self._final_status

    @public
    @property
    def submission_time(self):
        """Timestamp when the execution was submitted."""
        return self._submission_time

    @public
    @property
    def stdout_path(self):
        """Path in Hopsworks Filesystem to stdout log file."""
        return self._stdout_path

    @public
    @property
    def stderr_path(self):
        """Path in Hopsworks Filesystem to stderr log file."""
        return self._stderr_path

    @public
    @property
    def app_id(self):
        """Application id for the execution."""
        return self._app_id

    @public
    @property
    def hdfs_user(self):
        """Filesystem user for the execution."""
        return self._hdfs_user

    @public
    @property
    def args(self):
        """Arguments set for the execution."""
        return self._args

    @public
    @property
    def progress(self):
        """Progress of the execution."""
        return self._progress

    @public
    @property
    def user(self):
        """User that submitted the execution."""
        return self._user

    @public
    @property
    def duration(self):
        """Duration in milliseconds the execution ran."""
        return self._duration

    @public
    @property
    def success(self) -> bool | None:
        """Boolean to indicate if execution ran successfully or failed."""
        is_yarn_job = (
            self.job_type.lower() == "spark" or self.job_type.lower() == "pyspark"
        )

        if not is_yarn_job:
            if self.state in constants.JOBS.ERROR_STATES:
                return False
            if self.state in constants.JOBS.SUCCESS_STATES:
                return True
        if self.final_status in constants.JOBS.ERROR_STATES:
            return False
        if self.final_status in constants.JOBS.SUCCESS_STATES:
            return True
        return None

    @public
    @property
    def app_url(self) -> str | None:
        """URL to the Python App UI (Streamlit) if the execution is running.

        Returns the full URL to access the Streamlit application through the Hopsworks proxy,
        or None if the execution is not running or the app URL is not available.
        """
        if (
            self._state == "RUNNING"
            and self._monitoring
            and isinstance(self._monitoring, dict)
            and self._monitoring.get("appUrl")
        ):
            _client = client._get_instance()
            base_url = _client._base_url.rstrip("/")
            app_url = str(self._monitoring["appUrl"]).lstrip("/")
            if app_url.startswith(("http://", "https://")):
                return app_url
            if app_url.startswith("hopsworks-api/"):
                return base_url + "/" + app_url
            return base_url + "/hopsworks-api/" + app_url
        return None

    @public
    def download_logs(self, path: str | None = None) -> tuple[str | None, str | None]:
        """Download stdout and stderr logs for the execution.

        Example: Downloading and printing the logs
            ```python
            # Download logs
            out_log_path, err_log_path = execution.download_logs()

            out_fd = open(out_log_path, "r")
            print(out_fd.read())

            err_fd = open(err_log_path, "r")
            print(err_fd.read())
            ```

        Parameters:
            path: Path to download the logs.

        Returns:
            stdout: Path to downloaded log for stdout.
            stderr: Path to downloaded log for stderr.
        """
        return self._execution_engine._download_logs(self, path)

    @public
    @usage._method_logger
    def delete(self):
        """Delete the execution.

        Danger: Potentially dangerous operation
            This operation deletes the execution.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        self._execution_api._delete(self._job.name, self.id)

    @public
    @usage._method_logger
    def stop(self):
        """Stop the execution.

        Danger: Potentially dangerous operation
            This operation stops the execution.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        self._execution_api._stop(self.job_name, self.id)

    @public
    def await_termination(self, timeout: float | None = None):
        """Wait until execution terminates.

        Parameters:
            timeout:
                The maximum waiting time in seconds.
                If `None` the waiting time is unbounded.
                **Note**: the actual waiting time may be bigger by approximately 3 seconds.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
            hopsworks.client.exceptions.JobExecutionException: If the execution finished with a failure status.
        """
        self._execution_engine._wait_until_finished(self._job, self, timeout)

    def json(self):
        return json.dumps(self, cls=util.Encoder)

    def __str__(self):
        return self.json()

    def __repr__(self):
        return f"Execution({self._final_status!r}, {self._state!r}, {self._submission_time!r}, {self._args!r})"

    @public
    def get_url(self):
        """Get url to view execution details in Hopsworks UI."""
        _client = client._get_instance()
        path = (
            "/p/"
            + str(_client._project_id)
            + "/jobs/named/"
            + self.job_name
            + "/executions"
        )
        return util._get_hostname_replaced_url(path)

#
#   Copyright 2022 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

from __future__ import annotations

import copy
import json
import logging
import math
import os
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, wait
from typing import TYPE_CHECKING, Literal

from hopsworks_apigen import also_available_as, public
from hopsworks_common import client, tag, usage, util
from hopsworks_common.client.exceptions import DatasetException, RestAPIError
from hopsworks_common.core import dataset, inode, users_api, variable_api
from tqdm.auto import tqdm


if TYPE_CHECKING:
    import pandas as pd
    from hsfs.feature_group import FeatureGroup


@also_available_as("hopsworks.core.dataset_api.Chunk", "hsml.core.dataset_api.Chunk")
class Chunk:
    def __init__(self, content, number, status):
        self.content = content
        self.number = number
        self.status = status
        self.retries = 0


@public(
    "hopsworks.core.dataset_api.DatasetApi",
    "hsfs.core.dataset_api.DatasetApi",
    "hsml.core.dataset_api.DatasetApi",
)
class DatasetApi:
    def __init__(self):
        self._log = logging.getLogger(__name__)

    DEFAULT_UPLOAD_FLOW_CHUNK_SIZE = 10 * 1024 * 1024
    DEFAULT_UPLOAD_SIMULTANEOUS_UPLOADS = 3
    DEFAULT_UPLOAD_SIMULTANEOUS_CHUNKS = 3
    DEFAULT_UPLOAD_MAX_CHUNK_RETRIES = 1

    DEFAULT_DOWNLOAD_FLOW_CHUNK_SIZE = 1024 * 1024
    FLOW_PERMANENT_ERRORS = [404, 413, 415, 500, 501]

    # Backend error code for DatasetErrorCode.UPLOAD_DISK_SPACE_ERROR (110000 + 55)
    DATASET_ERROR_CODE_UPLOAD_DISK_SPACE = 110055

    # Backend error code for DatasetErrorCode.UPLOAD_NOT_ALLOWED (110000 + 56)
    DATASET_ERROR_CODE_UPLOAD_NOT_ALLOWED = 110056

    # alias for backwards-compatibility:
    DEFAULT_FLOW_CHUNK_SIZE = DEFAULT_DOWNLOAD_FLOW_CHUNK_SIZE

    @public
    @usage._method_logger
    def download(
        self,
        path: str,
        local_path: str | None = None,
        overwrite: bool | None = False,
        chunk_size: int = DEFAULT_DOWNLOAD_FLOW_CHUNK_SIZE,
    ) -> str:
        """Download file from Hopsworks Filesystem to the current working directory.

        ```python
        import hopsworks

        project = hopsworks.login()

        dataset_api = project.get_dataset_api()

        downloaded_file_path = dataset_api.download("Resources/my_local_file.txt")
        ```

        Parameters:
            path: Path in Hopsworks filesystem to the file.
            local_path: Path where to download the file in the local filesystem.
            overwrite: Overwrite local file if exists.
            chunk_size: Upload chunk size in bytes, defaults to 1 MB.

        Returns:
            The path to the downloaded file.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "dataset",
            "download",
            "with_auth",
            path,
        ]
        query_params = {"type": "DATASET"}

        # Build the path to download the file on the local fs and return to the user, it should be absolute for consistency
        # Download in CWD if local_path not specified
        if local_path is None:
            local_path = os.getcwd()
        # If local_path specified, ensure it is absolute
        elif not os.path.isabs(local_path):
            local_path = os.path.join(os.getcwd(), local_path)

        # If local_path is a directory, download into the directory
        if os.path.isdir(local_path):
            local_path = os.path.join(local_path, os.path.basename(path))

        if overwrite:
            if os.path.isfile(local_path):
                os.remove(local_path)
            elif os.path.isdir(local_path):
                shutil.rmtree(local_path)
        elif os.path.exists(local_path):
            raise OSError(
                f"{local_path} already exists, set overwrite=True to overwrite it"
            )

        file_size = int(self._get(path)["attributes"]["size"])
        with (
            _client._send_request(
                "GET", path_params, query_params=query_params, stream=True
            ) as response,
            open(local_path, "wb") as f,
        ):
            pbar = None
            try:
                pbar = tqdm(
                    total=file_size,
                    bar_format="{desc}: {percentage:.3f}%|{bar}| {n_fmt}/{total_fmt} elapsed<{elapsed} remaining<{remaining}",
                    desc="Downloading",
                )
            except Exception:
                self._log.exception("Failed to initialize progress bar.")
                self._log.info("Starting download")

            for chunk in response.iter_content(chunk_size=chunk_size):
                f.write(chunk)

                if pbar is not None:
                    pbar.update(len(chunk))

            if pbar is not None:
                pbar.close()
            else:
                self._log.info("Download finished")

        return local_path

    @public
    @usage._method_logger
    def upload(
        self,
        local_path: str,
        upload_path: str,
        overwrite: bool = False,
        chunk_size: int = DEFAULT_UPLOAD_FLOW_CHUNK_SIZE,
        simultaneous_uploads: int = DEFAULT_UPLOAD_SIMULTANEOUS_UPLOADS,
        simultaneous_chunks: int = DEFAULT_UPLOAD_SIMULTANEOUS_CHUNKS,
        max_chunk_retries: int = DEFAULT_UPLOAD_MAX_CHUNK_RETRIES,
        chunk_retry_interval: int = 1,
    ) -> str:
        """Upload a file or directory to the Hopsworks filesystem.

        ```python
        import hopsworks

        project = hopsworks.login()

        dataset_api = project.get_dataset_api()

        # upload a file to Resources dataset
        uploaded_file_path = dataset_api.upload("my_local_file.txt", "Resources")

        # upload a directory to Resources dataset
        uploaded_file_path = dataset_api.upload("my_dir", "Resources")
        ```

        Parameters:
            local_path: Local path to file or directory to upload, can be relative or absolute.
            upload_path: Path to directory where to upload the file in Hopsworks Filesystem.
            overwrite: Overwrite file or directory if exists.
            chunk_size: Upload chunk size in bytes, defaults to 10 MB.
            simultaneous_uploads: Number of simultaneous files to be uploaded for directories.
            simultaneous_chunks: Number of simultaneous chunks to upload for each file upload.
            max_chunk_retries: Maximum retry for a chunk.
            chunk_retry_interval: Chunk retry interval in seconds.

        Returns:
            The path to the uploaded file or directory.

        Raises:
            hopsworks.client.exceptions.DatasetException:
                If the destination path already exists and overwrite is not set to `True`, if the upload fails because the HopsFS storage quota is exhausted, or if the cluster upload policy does not permit this user to upload.
                With `overwrite=True` the policy is checked before the existing path is removed, so a refusal leaves it untouched.
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        # local path could be absolute or relative,
        if not os.path.isabs(local_path) and os.path.exists(
            os.path.join(os.getcwd(), local_path)
        ):
            local_path = os.path.join(os.getcwd(), local_path)

        _, file_name = os.path.split(local_path)

        destination_path = upload_path + "/" + file_name

        if self.exists(destination_path):
            if overwrite:
                if "datasetType" in self._get(destination_path):
                    raise DatasetException(
                        "overwrite=True not supported on a top-level dataset"
                    )
                # Before the removal, never after: see _assert_upload_allowed.
                self._assert_upload_allowed(destination_path)
                self.remove(destination_path)
            else:
                raise DatasetException(
                    f"{destination_path} already exists, set overwrite=True to overwrite it"
                )

        if os.path.isdir(local_path):
            self.mkdir(destination_path)

        if os.path.isdir(local_path):
            with ThreadPoolExecutor(simultaneous_uploads) as executor:
                # if path is a dir, upload files and folders iteratively
                for root, dirs, files in os.walk(local_path):
                    # os.walk(local_model_path), where local_model_path is expected to be an absolute path
                    # - root is the absolute path of the directory being walked
                    # - dirs is the list of directory names present in the root dir
                    # - files is the list of file names present in the root dir
                    # we need to replace the local path prefix with the hdfs path prefix (i.e., /srv/hops/....../root with /Projects/.../)
                    remote_base_path = root.replace(
                        local_path, destination_path
                    ).replace(os.sep, "/")
                    for d_name in dirs:
                        self.mkdir(remote_base_path + "/" + d_name)

                    # uploading files in the same folder is done concurrently
                    futures = [
                        executor.submit(
                            self._upload_file,
                            f_name,
                            root + os.sep + f_name,
                            remote_base_path,
                            chunk_size,
                            simultaneous_chunks,
                            max_chunk_retries,
                            chunk_retry_interval,
                        )
                        for f_name in files
                    ]

                    # wait for all upload tasks to complete
                    _, _ = wait(futures)
                    try:
                        _ = [future.result() for future in futures]
                    except Exception as e:
                        raise e
        else:
            self._upload_file(
                file_name,
                local_path,
                upload_path,
                chunk_size,
                simultaneous_chunks,
                max_chunk_retries,
                chunk_retry_interval,
            )

        return upload_path + "/" + os.path.basename(local_path)

    def _upload_file(
        self,
        file_name,
        local_path,
        upload_path,
        chunk_size,
        simultaneous_chunks,
        max_chunk_retries,
        chunk_retry_interval,
    ):
        file_size = os.path.getsize(local_path)

        num_chunks = math.ceil(file_size / chunk_size)

        base_params = self._get_flow_base_params(
            file_name, num_chunks, file_size, chunk_size
        )

        chunk_number = 1
        with open(local_path, "rb") as f:
            pbar = None
            try:
                pbar = tqdm(
                    total=file_size,
                    bar_format="{desc}: {percentage:.3f}%|{bar}| {n_fmt}/{total_fmt} elapsed<{elapsed} remaining<{remaining}",
                    desc=f"Uploading {local_path}",
                )
            except Exception:
                self._log.exception("Failed to initialize progress bar.")
                self._log.info("Starting upload")
            with ThreadPoolExecutor(simultaneous_chunks) as executor:
                all_chunks_processed = False

                while not all_chunks_processed:
                    chunks = []

                    if os.path.getsize(local_path) == 0:
                        chunks.append(Chunk(b"", 1, "pending"))
                        all_chunks_processed = True
                    else:
                        for _ in range(simultaneous_chunks):
                            chunk_data = f.read(chunk_size)
                            if not chunk_data:
                                all_chunks_processed = True
                                break
                            chunks.append(Chunk(chunk_data, chunk_number, "pending"))
                            chunk_number += 1

                    if not chunks:
                        break

                    futures = [
                        executor.submit(
                            self._upload_chunk,
                            base_params,
                            upload_path,
                            file_name,
                            chunk,
                            pbar,
                            max_chunk_retries,
                            chunk_retry_interval,
                        )
                        for chunk in chunks
                    ]

                    try:
                        for future in futures:
                            future.result()
                    except Exception:
                        if pbar:
                            pbar.close()
                        raise

            if pbar is not None:
                pbar.close()
            else:
                self._log.info("Upload finished")

    def _upload_chunk(
        self,
        base_params,
        upload_path,
        file_name,
        chunk: Chunk,
        pbar,
        max_chunk_retries,
        chunk_retry_interval,
    ):
        query_params = copy.copy(base_params)
        query_params["flowCurrentChunkSize"] = len(chunk.content)
        query_params["flowChunkNumber"] = chunk.number

        chunk.status = "uploading"
        while True:
            try:
                self._upload_request(
                    query_params, upload_path, file_name, chunk.content
                )
                break
            except RestAPIError as re:
                chunk.retries += 1
                if (
                    re.response.status_code in DatasetApi.FLOW_PERMANENT_ERRORS
                    or chunk.retries > max_chunk_retries
                ):
                    chunk.status = "failed"
                    if re.error_code == DatasetApi.DATASET_ERROR_CODE_UPLOAD_DISK_SPACE:
                        raise DatasetException(
                            "Upload failed: HopsFS storage is full. "
                            "Please contact your administrator to free up disk space."
                        ) from re
                    if (
                        re.error_code
                        == DatasetApi.DATASET_ERROR_CODE_UPLOAD_NOT_ALLOWED
                    ):
                        raise DatasetException(
                            "Upload failed: uploading files is not allowed on this cluster. "
                            "Please contact your administrator."
                        ) from re
                    raise re
                time.sleep(chunk_retry_interval)
                continue

        chunk.status = "uploaded"

        if pbar is not None:
            pbar.update(query_params["flowCurrentChunkSize"])

    def _get_flow_base_params(self, file_name, num_chunks, size, chunk_size):
        return {
            "templateId": -1,
            "flowChunkSize": chunk_size,
            "flowTotalSize": size,
            "flowIdentifier": str(size) + "_" + file_name,
            "flowFilename": file_name,
            "flowRelativePath": file_name,
            "flowTotalChunks": num_chunks,
        }

    def _assert_upload_allowed(self, destination_path: str) -> None:
        """Refuse an upload the cluster policy will not accept, before anything is removed.

        `upload(..., overwrite=True)` removes the destination before sending any bytes, so a
        refusal discovered on the first chunk leaves the caller with neither the original nor the
        replacement, and for a directory that removal is recursive.

        Anything short of a policy that clearly forbids this caller is treated as permitted, the
        backend being the authority.

        Raises:
            DatasetException: If the cluster upload policy does not permit this caller to upload.
        """
        try:
            policy = variable_api.VariableApi()._get_upload_policy()
        except RestAPIError as re:
            raise self._upload_policy_unreadable(destination_path, re) from re
        policy = policy.strip().lower() if policy else ""

        if policy == "disabled":
            raise DatasetException(
                "Uploading files is disabled on this cluster, so "
                f"{destination_path} was left unchanged. Please contact your administrator."
            )

        if policy != "admins_only":
            return

        # Only this policy depends on the caller, so the profile is read only here.
        try:
            user = users_api.UsersApi()._get_current_user()
        except RestAPIError as re:
            raise self._upload_policy_unreadable(destination_path, re) from re

        if not user or "HOPS_ADMIN" not in user.roles:
            raise DatasetException(
                "Uploading files is restricted to cluster administrators on this cluster, so "
                f"{destination_path} was left unchanged. Please contact your administrator."
            )

    @staticmethod
    def _upload_policy_unreadable(
        destination_path: str, error: RestAPIError
    ) -> DatasetException:
        """Build the refusal for an upload whose policy or role could not be established.

        Refusing costs the caller an overwrite; guessing costs them the file.
        """
        message = (
            "The cluster upload policy could not be established, so "
            f"{destination_path} was left unchanged."
        )
        if error.response.status_code == RestAPIError.STATUS_CODE_FORBIDDEN:
            # Only a refusal points at credentials; a 500 or an expired token does not, and an
            # in-cluster caller authenticates with a JWT and has no API key to widen.
            message += " An API key needs the USER, PROJECT or FEATURESTORE scope to read this."
        return DatasetException(message)

    def _upload_request(self, params, path, file_name, chunk):
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", "upload", path]

        # Flow configuration params are sent as form data
        _client._send_request(
            "POST", path_params, data=params, files={"file": (file_name, chunk)}
        )

    def _get(self, path: str) -> dict:
        """Get dataset metadata.

        Parameters:
            path: Path to check.

        Returns:
            Dataset metadata.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", path]
        headers = {"content-type": "application/json"}
        return _client._send_request("GET", path_params, headers=headers)

    @public
    def get(self, path: str) -> dict:
        """**Deprecated**.

        Get dataset metadata.

        Parameters:
            path: Path to check.

        Returns:
            Dataset metadata.
        """
        return self._get(path)

    @public
    def exists(self, path: str) -> bool:
        """Check if a file exists in the Hopsworks Filesystem.

        Parameters:
            path: Path to check.

        Returns:
            `True` if exists, otherwise `False`.
        """
        try:
            self._get(path)
            return True
        except RestAPIError:
            return False

    @public
    def path_exists(self, remote_path: str) -> bool:
        """**Deprecated**, use `exists` instead.

        Check if a path exists in datasets.

        Parameters:
            remote_path: Path to check.

        Returns:
            `True` if exists, otherwise `False`.
        """
        return self.exists(remote_path)

    @public
    @usage._method_logger
    def remove(self, path: str):
        """Remove a path in the Hopsworks Filesystem.

        Parameters:
            path: Path to remove.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", path]
        return _client._send_request("DELETE", path_params)

    @public
    def rm(self, remote_path: str):
        """**Deprecated**, use `remove` instead.

        Remove a path in the Hopsworks Filesystem.

        Parameters:
            remote_path: Path to remove.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self.remove(remote_path)

    @public
    @usage._method_logger
    def share(
        self,
        path: str,
        target_project: str,
        permission: Literal[
            "READ_ONLY", "EDITABLE", "EDITABLE_BY_OWNERS"
        ] = "READ_ONLY",
    ) -> None:
        """Share a dataset from the active project with another project.

        The caller must have the ``Data owner`` role in the active project; the
        backend rejects the share otherwise.
        Feature-store datasets can only be shared as ``READ_ONLY``.

        ```python
        import hopsworks

        project = hopsworks.login()

        dataset_api = project.get_dataset_api()

        dataset_api.share("Resources/my_dir", target_project="other_project")
        ```

        Parameters:
            path: Dataset path in the active project (e.g. ``Resources/my_dir``).
            target_project: Name of the project to share with.
            permission: One of ``READ_ONLY`` (default), ``EDITABLE``,
                ``EDITABLE_BY_OWNERS``. The target project's data owners
                still have to accept the share before its members see it.

        Raises:
            PermissionError: If the caller lacks the Data Owner role in the
                source project (HTTP 403 from the backend).
            hopsworks.client.exceptions.RestAPIError: If the dataset doesn't
                exist, the target project doesn't exist, or a feature-store
                dataset is shared with a permission other than ``READ_ONLY``.
            ValueError: If ``permission`` is not one of the allowed values
                or ``target_project`` is empty.
        """
        if permission not in ("READ_ONLY", "EDITABLE", "EDITABLE_BY_OWNERS"):
            raise ValueError(
                f"permission must be one of READ_ONLY, EDITABLE, "
                f"EDITABLE_BY_OWNERS; got {permission!r}"
            )
        if not target_project:
            raise ValueError("target_project must be a non-empty project name")
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", path]
        query_params = {
            "action": "SHARE",
            "target_project": target_project,
            "permission": permission,
        }
        try:
            _client._send_request("POST", path_params, query_params=query_params)
        except RestAPIError as e:
            if getattr(e.response, "status_code", None) == 403:
                raise PermissionError(
                    f"Sharing dataset '{path}' with project '{target_project}' "
                    f"requires the Data Owner role in the source project "
                    f"'{_client._project_name}'. Ask a data owner of "
                    f"'{_client._project_name}' to run this, or be granted that role."
                ) from e
            raise

    @public
    @usage._method_logger
    def unshare(self, path: str, target_project: str) -> None:
        """Revoke a previously-granted dataset share with another project.

        Like :meth:`share`, requires Data Owner role in the active (source) project.

        ```python
        import hopsworks

        project = hopsworks.login()

        dataset_api = project.get_dataset_api()

        dataset_api.unshare("Resources/my_dir", target_project="other_project")
        ```

        Parameters:
            path: Dataset path in the active project.
            target_project: Name of the project to revoke the share from.

        Raises:
            PermissionError: If the caller lacks the Data Owner role in the
                source project (HTTP 403 from the backend).
            hopsworks.client.exceptions.RestAPIError: If the dataset isn't
                shared with that project, the target project doesn't exist,
                or the backend otherwise rejects the request.
            ValueError: If ``target_project`` is empty.
        """
        if not target_project:
            raise ValueError("target_project must be a non-empty project name")
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", path]
        query_params = {
            "action": "UNSHARE",
            "target_project": target_project,
        }
        try:
            _client._send_request("DELETE", path_params, query_params=query_params)
        except RestAPIError as e:
            if getattr(e.response, "status_code", None) == 403:
                raise PermissionError(
                    f"Unsharing dataset '{path}' from project '{target_project}' "
                    f"requires the Data Owner role in the source project "
                    f"'{_client._project_name}'. Ask a data owner of "
                    f"'{_client._project_name}' to run this, or be granted that role."
                ) from e
            raise

    @public
    @usage._method_logger
    def mkdir(self, path: str) -> str:
        """Create a directory in the Hopsworks Filesystem.

        ```python
        import hopsworks

        project = hopsworks.login()

        dataset_api = project.get_dataset_api()

        directory_path = dataset_api.mkdir("Resources/my_dir")
        ```

        Parameters:
            path: Path to directory.

        Returns:
            Path to the created directory.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", path]
        query_params = {
            "action": "create",
            "searchable": "true",
            "generate_readme": "false",
            "type": "DATASET",
        }
        headers = {"content-type": "application/json"}
        return _client._send_request(
            "POST", path_params, headers=headers, query_params=query_params
        )["attributes"]["path"]

    @public
    @usage._method_logger
    def copy(self, source_path: str, destination_path: str, overwrite: bool = False):
        """Copy a file or directory in the Hopsworks Filesystem.

        ```python
        import hopsworks

        project = hopsworks.login()

        dataset_api = project.get_dataset_api()

        directory_path = dataset_api.copy("Resources/myfile.txt", "Logs/myfile.txt")
        ```

        Parameters:
            source_path: The source path to copy.
            destination_path: The destination path.
            overwrite: Overwrite destination if exists.

        Raises:
            hopsworks.client.exceptions.DatasetException: If the destination path already exists and overwrite is not set to `True`.
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        if self.exists(destination_path):
            if overwrite:
                if "datasetType" in self._get(destination_path):
                    raise DatasetException(
                        "overwrite=True not supported on a top-level dataset"
                    )
                self.remove(destination_path)
            else:
                raise DatasetException(
                    f"{destination_path} already exists, set overwrite=True to overwrite it"
                )

        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", source_path]
        query_params = {
            "action": "copy",
            "destination_path": destination_path,
        }
        _client._send_request("POST", path_params, query_params=query_params)

    @public
    @usage._method_logger
    def move(self, source_path: str, destination_path: str, overwrite: bool = False):
        """Move a file or directory in the Hopsworks Filesystem.

        ```python
        import hopsworks

        project = hopsworks.login()

        dataset_api = project.get_dataset_api()

        directory_path = dataset_api.move("Resources/myfile.txt", "Logs/myfile.txt")
        ```

        Parameters:
            source_path: The source path to move.
            destination_path: The destination path.
            overwrite: Overwrite destination if exists.

        Raises:
            hopsworks.client.exceptions.DatasetException: If the destination path already exists and overwrite is not set to `True`.
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        if self.exists(destination_path):
            if overwrite:
                if "datasetType" in self._get(destination_path):
                    raise DatasetException(
                        "overwrite=True not supported on a top-level dataset"
                    )
                self.remove(destination_path)
            else:
                raise DatasetException(
                    f"{destination_path} already exists, set overwrite=True to overwrite it"
                )

        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", source_path]
        query_params = {
            "action": "move",
            "destination_path": destination_path,
        }
        _client._send_request("POST", path_params, query_params=query_params)

    @public
    @usage._method_logger
    def upload_feature_group(
        self, feature_group: FeatureGroup, path: str, dataframe: pd.DataFrame
    ):
        """Upload a dataframe to a path in Parquet format using a feature group metadata.

        Warning:
            This method is a legacy method kept for backwards-compatibility; do not use it in new code.

        Parameters:
            feature_group: The feature group metadata to use for the upload.
            path: The path to upload the dataframe to.
            dataframe: The dataframe to upload.
        """
        # Convert the dataframe into PARQUET for upload
        df_parquet = dataframe.to_parquet(index=False)
        parquet_length = len(df_parquet)
        num_chunks = math.ceil(parquet_length / self.DEFAULT_FLOW_CHUNK_SIZE)

        base_params = self._get_flow_base_params(
            feature_group, num_chunks, parquet_length, self.DEFAULT_FLOW_CHUNK_SIZE
        )

        chunk_number = 1
        for i in range(0, parquet_length, self.DEFAULT_FLOW_CHUNK_SIZE):
            query_params = base_params
            query_params["flowCurrentChunkSize"] = len(
                df_parquet[i : i + self.DEFAULT_FLOW_CHUNK_SIZE]
            )
            query_params["flowChunkNumber"] = chunk_number

            self._upload_request(
                query_params,
                path,
                util._feature_group_name(feature_group),
                df_parquet[i : i + self.DEFAULT_FLOW_CHUNK_SIZE],
            )

            chunk_number += 1

    @public
    @usage._method_logger
    def list(self, path: str, offset: int = 0, limit: int = 1000) -> list[str]:
        """List the files and directories from a path in the Hopsworks Filesystem.

        ```python
        import hopsworks

        project = hopsworks.login()

        dataset_api = project.get_dataset_api()

        # list all files in the Resources dataset
        files = dataset_api.list("/Resources")

        # list all datasets in the project
        files = dataset_api.list("/")
        ```

        Parameters:
            path: Path in Hopsworks filesystem to the directory.
            offset: The number of entities to skip.
            limit: Max number of the returned entities.

        Returns:
            List of path to files and directories in the provided path.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        # Normalize path so we can check if the path refers to the root or not
        # That is needed as different backend entities are returned depending on if it is a top level dataset or a subdirectory
        normalized_path = os.path.normpath(path)
        if normalized_path == "/":
            normalized_path = ""
            cls = dataset.Dataset
        else:
            cls = inode.Inode

        count, items = self._list_dataset_path(
            normalized_path, cls, offset=offset, limit=limit
        )

        files = []
        for item in items:
            files.append(
                util._convert_to_project_rel_path(item.path, _client._project_name)
            )
        return files

    @usage._method_logger
    def _list_dataset_path(
        self,
        path: str,
        cls: type[dataset.Dataset | inode.Inode],
        offset: int = 0,
        limit: int = 1000,
        sort_by: str = "ID:asc",
    ) -> tuple[int, tuple[int, list[inode.Inode]] | tuple[int, list[dataset.Dataset]]]:
        """List contents of a directory in the Hopsworks Filesystem.

        Parameters:
            path: Path to the directory to list the contents of.
            offset: The number of Inodes to skip.
            limit: Max number of the returned Inodes.

        Returns:
            Count of Dataset or Inodes and objects.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "dataset",
            path,
        ]
        query_params = {
            "action": "listing",
            "offset": offset,
            "limit": limit,
            "sort_by": sort_by,
            "expand": "inodes",
        }

        items = _client._send_request("GET", path_params, query_params)

        return items["count"], cls.from_response_json(items)

    @public
    @usage._method_logger
    def read_content(self, path: str, dataset_type: str = "DATASET") -> dict | None:
        """Read the content of a file.

        Parameters:
            path: The path to the file to read.
            dataset_type:
                The type of dataset, can be `DATASET` or `HIVEDB`; defaults to `DATASET`.
                `HIVEDB` type is used to read files from Apache Hive.

        Returns:
            An object with `content` attribute containing the file content as bytes, or `None` if the file was not found.
        """
        _client = client._get_instance()

        path_params = [
            "project",
            _client._project_id,
            "dataset",
            "download",
            "with_auth",
            path[1:],
        ]

        query_params = {
            "type": dataset_type,
        }

        return _client._send_request("GET", path_params, query_params, stream=True)

    @public
    def chmod(self, remote_path: str, permissions: str) -> dict:
        """Change permissions of a file or a directory in the Hopsworks Filesystem.

        Parameters:
            remote_path: Path to change the permissions of.
            permissions: Permissions string, for example `"u+x"`.

        Returns:
            dict: The updated dataset metadata.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", remote_path]
        headers = {"content-type": "application/json"}
        query_params = {"action": "PERMISSION", "permissions": permissions}
        return _client._send_request(
            "PUT", path_params, headers=headers, query_params=query_params
        )

    # region Archiving

    def _archive(
        self,
        remote_path: str,
        destination_path: str | None = None,
        block: bool = False,
        timeout: int | None = 120,
        action: Literal["unzip", "zip"] = "unzip",
    ) -> bool:
        """Internal (de)compression logic.

        Parameters:
            remote_path: Path to file or directory to unzip.
            destination_path: Path to upload the zip; is used only if action is `zip`.
            block: If the operation should be blocking until complete.
            timeout: Timeout in seconds for the blocking, defaults to 120; if `None`, the blocking is unbounded.
            action: To zip or to unzip.

        Returns:
            Whether the operation completed in the specified timeout; if non-blocking, always returns `True`.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "dataset", remote_path]

        query_params = {"action": action}

        if destination_path is not None:
            query_params["destination_path"] = destination_path
            query_params["destination_type"] = "DATASET"

        headers = {"content-type": "application/json"}

        _client._send_request(
            "POST", path_params, headers=headers, query_params=query_params
        )

        if not block:
            # the call is successful at this point if we don't want to block
            return True

        # Wait for zip file to appear. When it does, check that parent dir zipState is not set to CHOWNING
        count = 0
        while True:
            if action == "zip":
                zip_path = remote_path + ".zip"
                # Get the status of the zipped file
                if destination_path is None:
                    zip_exists = self.path_exists(zip_path)
                else:
                    zip_exists = self.path_exists(
                        destination_path + "/" + os.path.split(zip_path)[1]
                    )
                # Get the zipState of the directory being zipped
                dir_status = self.get(remote_path)
                zip_state = dir_status.get("zipState", None)
                if zip_exists and zip_state == "NONE":
                    return True
            elif action == "unzip":
                # Get the status of the unzipped dir
                unzipped_dir_exists = self.path_exists(
                    remote_path[: remote_path.index(".")]
                )
                # Get the zipState of the zip being extracted
                dir_status = self.get(remote_path)
                zip_state = dir_status.get("zipState", None)
                if unzipped_dir_exists and zip_state == "NONE":
                    return True
            time.sleep(1)
            count += 1
            if timeout is not None and count >= timeout:
                self._log.info(
                    f"Timeout of {timeout} seconds exceeded while {action} {remote_path}."
                )
                return False

    @public
    def unzip(
        self, remote_path: str, block: bool = False, timeout: int | None = 120
    ) -> bool:
        """Unzip an archive in the dataset.

        Parameters:
            remote_path: Path to file or directory to unzip.
            block: Whether the operation should be blocking until complete.
            timeout: Timeout in seconds for the blocking, defaults to 120; if `None`, the blocking is unbounded.

        Returns:
            Whether the operation completed in the specified timeout; if non-blocking, always returns `True`.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._archive(remote_path, block=block, timeout=timeout, action="unzip")

    @public
    def zip(
        self,
        remote_path: str,
        destination_path: str | None = None,
        block: bool = False,
        timeout: int | None = 120,
    ) -> bool:
        """Zip a file or directory in the dataset.

        Parameters:
            remote_path: Path to file or directory to zip.
            destination_path: Path to upload the zip.
            block: Whether the operation should be blocking until complete.
            timeout: Timeout in seconds for the blocking, defaults to 120; if `None`, the blocking is unbounded.

        Returns:
            Whether the operation completed in the specified timeout; if non-blocking, always returns `True`.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._archive(
            remote_path,
            destination_path=destination_path,
            block=block,
            timeout=timeout,
            action="zip",
        )

    # region Dataset Tags

    @public
    def add(self, path: str, name: str, value: str):
        """**Deprecated**.

        Attach a name/value tag to a model.

        A tag consists of a name/value pair. Tag names are unique identifiers.
        The value of a tag can be any valid json - primitives, arrays or json objects.

        Parameters:
            path: Path to add the tag.
            name: Name of the tag to be added.
            value: Value of the tag to be added.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "dataset",
            "tags",
            "schema",
            name,
            path,
        ]
        headers = {"content-type": "application/json"}
        json_value = json.dumps(value)
        _client._send_request("PUT", path_params, headers=headers, data=json_value)

    @public
    def delete(self, path: str, name: str):
        """**Deprecated**.

        Delete a tag.

        Tag names are unique identifiers.

        Parameters:
            path: Path to delete the tags.
            name: Name of the tag to be removed.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "dataset",
            "tags",
            "schema",
            name,
            path,
        ]
        _client._send_request("DELETE", path_params)

    @public
    def get_tags(self, path: str, name: str | None = None) -> dict:
        """**Deprecated**.

        Get the tags.

        Gets all tags if no tag name is specified.

        Parameters:
            path: Path to get the tags.
            name: Tag name.

        Returns:
            Tag names and values.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "dataset",
            "tags",
        ]

        if name is not None:
            path_params.append("schema")
            path_params.append(name)
        else:
            path_params.append("all")

        path_params.append(path)

        # from_response_json already returns deserialized values.
        return {
            tag._name: tag._value
            for tag in tag.Tag.from_response_json(
                _client._send_request("GET", path_params)
            )
        }

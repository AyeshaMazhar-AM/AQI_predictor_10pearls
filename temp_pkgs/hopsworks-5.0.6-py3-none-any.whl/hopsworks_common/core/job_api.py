#
#   Copyright 2022 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any, Literal

from hopsworks_common import (
    client,
    decorators,
    execution,
    job,
    job_schedule,
    usage,
    util,
)


if TYPE_CHECKING:
    from hopsworks_common.core import (
        ingestion_job_conf,
        job_configuration,
        sink_job_configuration,
    )

from hopsworks_apigen import public


@public(
    "hopsworks.core.job_api.JobApi",
    "hopsworks.core.job_api.JobsApi",
    "hsfs.core.job_api.JobApi",
)
class JobApi:
    @public
    @usage._method_logger
    def create_job(self, name: str, config: dict) -> job.Job:
        """Create a new job or update an existing one.

        ```python
        import hopsworks

        project = hopsworks.login()

        job_api = project.get_job_api()

        spark_config = job_api.get_configuration("PYSPARK")

        spark_config['appPath'] = "/Resources/my_app.py"

        job = job_api.create_job("my_spark_job", spark_config)
        ```

        Parameters:
            name: Name of the job.
            config: Configuration of the job.

        Returns:
            The created job.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()

        config = util._validate_job_conf(config, _client._project_name)

        path_params = ["project", _client._project_id, "jobs", name]

        headers = {"content-type": "application/json"}
        created_job = job.Job.from_response_json(
            _client._send_request(
                "PUT", path_params, headers=headers, data=json.dumps(config)
            )
        )
        print(f"Job created successfully, explore it at {created_job.get_url()}")
        return created_job

    @public
    @usage._method_logger
    @decorators._catch_not_found("hopsworks_common.job.Job", fallback_return=None)
    def get_job(self, name: str) -> job.Job | None:
        """Get a job.

        Parameters:
            name: Name of the job.

        Returns:
            The Job object or `None` if it does not exist.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "jobs",
            name,
        ]
        query_params = {"expand": ["creator"]}
        return job.Job.from_response_json(
            _client._send_request("GET", path_params, query_params=query_params)
        )

    @public
    @usage._method_logger
    def get_jobs(self) -> list[job.Job]:
        """Get all jobs.

        Returns:
            List of all jobs.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "jobs",
        ]
        query_params = {"expand": ["creator"]}
        return job.Job.from_response_json(
            _client._send_request("GET", path_params, query_params=query_params)
        )

    @public
    @usage._method_logger
    def exists(self, name: str) -> bool:
        """Check if a job exists.

        Parameters:
            name: Name of the job.

        Returns:
            `True` if the job exists, otherwise `False`.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        job = self.get_job(name)
        return job is not None

    @public
    @usage._method_logger
    def get_configuration(
        self,
        type: Literal["SPARK", "PYSPARK", "PYTHON", "PYTHON_APP", "DOCKER"],
    ) -> dict:
        """Get configuration for the specific job type.

        Parameters:
            type: The job type to retrieve the configuration of.

        Returns:
            The default job configuration for the specific job type.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "jobs",
            type.lower(),
            "configuration",
        ]

        headers = {"content-type": "application/json"}
        return _client._send_request("GET", path_params, headers=headers)

    def _delete(self, job):
        """Delete the job and all executions.

        Parameters:
            job: Metadata object of job to delete.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "jobs",
            str(job.name),
        ]
        _client._send_request("DELETE", path_params)

    def _update_job(self, name: str, config: dict) -> job.Job:
        """Update the job.

        Parameters:
            name: Name of the job.
            config: New job configuration.

        Returns:
            The updated Job object.
        """
        _client = client._get_instance()

        config = util._validate_job_conf(config, _client._project_name)

        path_params = ["project", _client._project_id, "jobs", name]

        headers = {"content-type": "application/json"}
        return job.Job.from_response_json(
            _client._send_request(
                "PUT", path_params, headers=headers, data=json.dumps(config)
            )
        )

    def _schedule_job(self, name, schedule_config):
        """Attach the `schedule_config` to the job with the given `name`."""
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "jobs", name, "schedule", "v2"]
        headers = {"content-type": "application/json"}
        method = "PUT" if schedule_config["id"] else "POST"

        return job_schedule.JobSchedule.from_response_json(
            _client._send_request(
                method, path_params, headers=headers, data=json.dumps(schedule_config)
            )
        )

    def _delete_schedule_job(self, name):
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "jobs", name, "schedule", "v2"]

        return _client._send_request(
            "DELETE",
            path_params,
        )

    @public
    @usage._method_logger
    def create(
        self,
        name: str,
        job_conf: (
            job_configuration.JobConfiguration
            | ingestion_job_conf.IngestionJobConf
            | sink_job_configuration.SinkJobConfiguration
        ),
    ) -> job.Job:
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "jobs", name]

        headers = {"content-type": "application/json"}
        return job.Job.from_response_json(
            _client._send_request(
                "PUT", path_params, headers=headers, data=job_conf.json()
            )
        )

    @public
    @usage._method_logger
    def launch(self, name: str, args: str = None) -> None:
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "jobs", name, "executions"]

        # The backend has two @POST handlers on this path (text/plain for legacy
        # args and application/json for logical-time params); without an explicit
        # Content-Type Jersey can't dispatch and returns 415.
        headers = {"content-type": "text/plain"}
        _client._send_request("POST", path_params, headers=headers, data=args)

    @public
    @usage._method_logger
    def get(self, name: str) -> job.Job:
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "jobs", name]

        return job.Job.from_response_json(_client._send_request("GET", path_params))

    @public
    @usage._method_logger
    def last_execution(self, job: job.Job) -> execution.Execution:
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "jobs", job.name, "executions"]

        query_params = {"limit": 1, "sort_by": "submissiontime:desc"}

        headers = {"content-type": "application/json"}
        return execution.Execution.from_response_json(
            _client._send_request(
                "GET", path_params, headers=headers, query_params=query_params
            ),
            job=job,
        )

    @public
    @usage._method_logger
    def create_or_update_schedule_job(
        self, name: str, schedule_config: dict[str, Any]
    ) -> job_schedule.JobSchedule:
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "jobs", name, "schedule", "v2"]
        headers = {"content-type": "application/json"}
        method = "PUT" if schedule_config["id"] else "POST"

        return job_schedule.JobSchedule.from_response_json(
            _client._send_request(
                method, path_params, headers=headers, data=json.dumps(schedule_config)
            )
        )

    @public
    @usage._method_logger
    def delete_schedule_job(self, name: str) -> None:
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "jobs", name, "schedule", "v2"]

        return _client._send_request(
            "DELETE",
            path_params,
        )

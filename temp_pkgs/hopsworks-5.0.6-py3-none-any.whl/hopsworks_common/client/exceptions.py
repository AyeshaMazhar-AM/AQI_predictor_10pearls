#
#   Copyright 2020 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Any

from hopsworks_apigen import also_available_as, public
from requests.exceptions import SSLError


if TYPE_CHECKING:
    import requests


@public("hopsworks.client.exceptions.RestAPIError")
@also_available_as("hsml.client.exceptions.RestAPIError")
class RestAPIError(Exception):
    """REST Exception encapsulating the response object and url."""

    STATUS_CODE_BAD_REQUEST = 400
    STATUS_CODE_UNAUTHORIZED = 401
    STATUS_CODE_FORBIDDEN = 403
    STATUS_CODE_NOT_FOUND = 404
    STATUS_CODE_INTERNAL_SERVER_ERROR = 500

    class FeatureStoreErrorCode(int, Enum):
        FEATURE_GROUP_COMMIT_NOT_FOUND = 270227
        STATISTICS_NOT_FOUND = 270228

        def __eq__(self, other: int | Any) -> bool:
            if isinstance(other, int):
                return self.value == other
            if isinstance(other, self.__class__):
                return self is other
            return False

    def __init__(self, url: str, response: requests.Response) -> None:
        try:
            error_object = response.json()
            if isinstance(error_object, str):
                error_object = {"errorMsg": error_object}
        except Exception:
            error_object = {}
            self.error_code = None
        message = (
            "Metadata operation error: (url: {}). Server response: \n"
            "HTTP code: {}, HTTP reason: {}, body: {}, error code: {}, error msg: {}, user "
            "msg: {}".format(
                url,
                response.status_code,
                response.reason,
                response.content,
                error_object.get("errorCode", ""),
                error_object.get("errorMsg", ""),
                error_object.get("usrMsg", ""),
            )
        )
        if len(error_object) != 0:
            self.error_code = error_object.get("errorCode", "")
        super().__init__(message)
        self.url = url
        self.response = response


@public("hopsworks.client.exceptions.UnknownSecretStorageError")
@also_available_as("hsml.client.exceptions.UnknownSecretStorageError")
class UnknownSecretStorageError(Exception):
    """This exception will be raised if an unused secrets storage is passed as a parameter."""


@public("hopsworks.client.exceptions.FeatureStoreException")
@also_available_as("hsml.client.exceptions.FeatureStoreException")
class FeatureStoreException(Exception):
    """Generic feature store exception."""


@public("hopsworks.client.exceptions.TransformationFunctionException")
@also_available_as("hsml.client.exceptions.TransformationFunctionException")
class TransformationFunctionException(Exception):
    """Exception raised when a transformation function fails."""

    def __init__(
        self,
        message: str,
        missing_features: set[str] | None = None,
        transformation_function_name: str | None = None,
        transformation_type: str | None = None,
    ) -> None:
        self.missing_features = missing_features
        self.transformation_function_name = transformation_function_name
        self.transformation_type = (
            transformation_type.replace("_", "-") if transformation_type else None
        )
        super().__init__(message)


@public("hopsworks.client.exceptions.VectorDatabaseException")
@also_available_as("hsml.client.exceptions.VectorDatabaseException")
class VectorDatabaseException(Exception):
    # reason
    REQUESTED_K_TOO_LARGE = "REQUESTED_K_TOO_LARGE"
    REQUESTED_NUM_RESULT_TOO_LARGE = "REQUESTED_NUM_RESULT_TOO_LARGE"
    OTHERS = "OTHERS"

    # info
    REQUESTED_K_TOO_LARGE_INFO_K = "k"
    REQUESTED_NUM_RESULT_TOO_LARGE_INFO_N = "n"

    def __init__(self, reason: str, message: str, info: str) -> None:
        super().__init__(message)
        self._info = info
        self._reason = reason

    @public
    @property
    def reason(self) -> str:
        return self._reason

    @public
    @property
    def info(self) -> str:
        return self._info


@public("hopsworks.client.exceptions.DataValidationException")
@also_available_as("hsml.client.exceptions.DataValidationException")
class DataValidationException(FeatureStoreException):
    """Raised when data validation fails only when using "STRICT" validation ingestion policy."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


@public("hopsworks.client.exceptions.ExternalClientError")
@also_available_as("hsml.client.exceptions.ExternalClientError")
class ExternalClientError(TypeError):
    """Raised when external client cannot be initialized due to missing arguments."""

    def __init__(self, missing_argument: str) -> None:
        message = (
            f"{missing_argument} cannot be of type NoneType, {missing_argument} is a non-optional "
            "argument to connect to hopsworks from an external environment."
        )
        super().__init__(message)


@also_available_as("hsml.client.exceptions.InternalClientError")
class InternalClientError(TypeError):
    """Raised when hopsworks internal client is missing some necessary configuration."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


@public("hopsworks.client.exceptions.HopsworksSSLClientError")
@also_available_as("hsml.client.exceptions.HopsworksSSLClientError")
class HopsworksSSLClientError(SSLError):
    """Raised when the client connection fails with SSL related errors.

    `SSLError` inherits from [`requests.exceptions.ConnectionError`][requests.exceptions.ConnectionError].
    """

    def __init__(self, message: str) -> None:
        super().__init__(message)


@public("hopsworks.client.exceptions.GitException")
@also_available_as("hsml.client.exceptions.GitException")
class GitException(Exception):
    """Generic git exception."""


@public("hopsworks.client.exceptions.JobException")
@also_available_as("hsml.client.exceptions.JobException")
class JobException(Exception):
    """Generic job exception."""


@public("hopsworks.client.exceptions.EnvironmentException")
@also_available_as("hsml.client.exceptions.EnvironmentException")
class EnvironmentException(Exception):
    """Generic python environment exception."""


@public("hopsworks.client.exceptions.KafkaException")
@also_available_as("hsml.client.exceptions.KafkaException")
class KafkaException(Exception):
    """Generic kafka exception."""


@public("hopsworks.client.exceptions.DatasetException")
@also_available_as("hsml.client.exceptions.DatasetException")
class DatasetException(Exception):
    """Generic dataset exception."""


@public("hopsworks.client.exceptions.ProjectException")
@also_available_as("hsml.client.exceptions.ProjectException")
class ProjectException(Exception):
    """Generic project exception."""


@public("hopsworks.client.exceptions.OpenSearchException")
@also_available_as("hsml.client.exceptions.OpenSearchException")
class OpenSearchException(Exception):
    """Generic opensearch exception."""


@public("hopsworks.client.exceptions.JobExecutionException")
@also_available_as("hsml.client.exceptions.JobExecutionException")
class JobExecutionException(Exception):
    """Generic job executions exception."""


@public("hsml.client.exceptions.ModelRegistryException")
class ModelRegistryException(Exception):
    """Generic model registry exception."""


@public("hopsworks.client.exceptions.HuggingFaceImportException")
@also_available_as("hsml.client.exceptions.HuggingFaceImportException")
class HuggingFaceImportException(ModelRegistryException):
    """Raised when an asynchronous HuggingFace model import does not complete successfully.

    Carries the stable error code emitted by the backend so callers can branch on it.
    The backend codes are:

    - ``auth_required`` — the supplied HuggingFace access token was rejected (invalid,
      expired, or missing the gated-repo grant). Retry with a different token.
    - ``not_found_or_auth_required`` — no token was supplied and HuggingFace returned
      401 for the repo. Either the model id is wrong or the repo is private/gated;
      HuggingFace deliberately hides which.
    - ``model_not_found`` — HuggingFace returned 404 for the repo.
    - ``no_disk_space`` — HopsFS storage quota was exhausted while downloading.
    - ``download_failed: <file>`` — a specific file failed to download (network etc.).
    - ``invalid_filename: <name>`` — a file in the repo had a name disallowed by the
      path-safety check (``..`` segments, absolute paths, …).
    - ``registration_failed: ...`` — files downloaded but the final registration step
      failed.
    - ``fetch_failed`` — generic upstream / metadata error talking to HuggingFace.
    """

    # Stable error keys returned by the backend. Match these against
    # ``HuggingFaceImportException.error_code`` rather than substring-checking the message.
    AUTH_REQUIRED = "auth_required"
    NOT_FOUND_OR_AUTH_REQUIRED = "not_found_or_auth_required"
    MODEL_NOT_FOUND = "model_not_found"
    NO_DISK_SPACE = "no_disk_space"
    FETCH_FAILED = "fetch_failed"

    def __init__(self, error_code: str, message: str | None = None):
        self.error_code = error_code
        self.message = message or error_code
        super().__init__(self.message)


@public("hsml.client.exceptions.ModelServingException")
class ModelServingException(Exception):
    """Generic model serving exception."""

    ERROR_CODE_SERVING_NOT_FOUND = 240000
    ERROR_CODE_ILLEGAL_ARGUMENT = 240001
    ERROR_CODE_DUPLICATED_ENTRY = 240011

    ERROR_CODE_DEPLOYMENT_NOT_RUNNING = 250001


@public("hopsworks.client.exceptions.DataSourceException")
@also_available_as("hsml.client.exceptions.DataSourceException")
class DataSourceException(Exception):
    """Generic data source exception."""


@public("hopsworks.client.exceptions.PlatformIntelligenceException")
@also_available_as("hsml.client.exceptions.PlatformIntelligenceException")
class PlatformIntelligenceException(Exception):
    """Raised when a platform-intelligence call cannot be served.

    Either the cluster's LLM is not configured (admin has not set
    `PLATFORM_INTELLIGENCE_LLM_API_KEY`) or the LLM call itself failed.
    Inspect the ``reason`` attribute, which is set to one of the constants
    below, to disambiguate.

    Attributes:
        NOT_CONFIGURED: Reason value when the cluster has no LLM API key configured.
        INFERENCE_FAILED: Reason value when the LLM call itself failed.
    """

    NOT_CONFIGURED = "not_configured"
    INFERENCE_FAILED = "inference_failed"

    def __init__(self, reason: str, message: str) -> None:
        self.reason = reason
        super().__init__(message)


@public("hopsworks.client.exceptions.TrinoException")
@also_available_as("hsml.client.exceptions.TrinoException")
class TrinoException(Exception):
    """Generic Trino exception."""

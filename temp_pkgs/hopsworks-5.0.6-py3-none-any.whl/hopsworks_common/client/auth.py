#
#   Copyright 2020 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

from __future__ import annotations

import os
from pathlib import Path

import requests
from hopsworks_apigen import also_available_as
from hopsworks_common.client import exceptions


@also_available_as(
    "hopsworks.client.auth.BearerAuth",
    "hsfs.client.auth.BearerAuth",
    "hsml.client.auth.BearerAuth",
)
class BearerAuth(requests.auth.AuthBase):
    """Class to encapsulate a Bearer token."""

    def __init__(self, token: str) -> None:
        self._token = token.strip()

    def __call__(self, r: requests.Request) -> requests.Request:
        r.headers["Authorization"] = "Bearer " + self._token
        return r


@also_available_as(
    "hopsworks.client.auth.ApiKeyAuth",
    "hsfs.client.auth.ApiKeyAuth",
    "hsml.client.auth.ApiKeyAuth",
)
class ApiKeyAuth(requests.auth.AuthBase):
    """Class to encapsulate an API key."""

    def __init__(self, token: str) -> None:
        self._token = token.strip()

    def __call__(self, r: requests.Request) -> requests.Request:
        r.headers["Authorization"] = "ApiKey " + self._token
        return r


@also_available_as(
    "hopsworks.client.auth.OnlineStoreKeyAuth",
    "hsfs.client.auth.OnlineStoreKeyAuth",
    "hsml.client.auth.OnlineStoreKeyAuth",
)
class OnlineStoreKeyAuth(requests.auth.AuthBase):
    """Class to encapsulate an API key."""

    def __init__(self, token):
        self._token = token.strip()

    def __call__(self, r):
        r.headers["X-API-KEY"] = self._token
        return r


@also_available_as("hsml.client.auth._get_api_key")
def _get_api_key(api_key_value, api_key_file):
    if api_key_value is not None:
        return api_key_value
    if api_key_file is not None:
        if os.path.exists(api_key_file):
            return Path(api_key_file).read_text()
        raise OSError(f"Could not find api key file on path: {api_key_file}")
    raise exceptions.ExternalClientError(
        "Either api_key_file or api_key_value must be set when connecting to"
        " hopsworks from an external environment."
    )

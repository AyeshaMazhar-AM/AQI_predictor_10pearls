# Copyright 2021 The KServe Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# This implementation has been borrowed from kserve/kserve repository
# https://github.com/kserve/kserve/blob/release-0.11/python/kserve/kserve/utils/numpy_codec.py

import numpy as np
from hopsworks_apigen import also_available_as


@also_available_as("hsml.client.istio.utils.numpy_codec.to_np_dtype")
def to_np_dtype(dtype):
    dtype_map = {
        "BOOL": bool,
        "INT8": np.int8,
        "INT16": np.int16,
        "INT32": np.int32,
        "INT64": np.int64,
        "UINT8": np.uint8,
        "UINT16": np.uint16,
        "UINT32": np.uint32,
        "UINT64": np.uint64,
        "FP16": np.float16,
        "FP32": np.float32,
        "FP64": np.float64,
        "BYTES": np.object_,
    }
    return dtype_map.get(dtype)


@also_available_as("hsml.client.istio.utils.numpy_codec.from_np_dtype")
def from_np_dtype(np_dtype):
    if np_dtype is bool:
        return "BOOL"
    if np_dtype == np.int8:
        return "INT8"
    if np_dtype == np.int16:
        return "INT16"
    if np_dtype == np.int32:
        return "INT32"
    if np_dtype == np.int64:
        return "INT64"
    if np_dtype == np.uint8:
        return "UINT8"
    if np_dtype == np.uint16:
        return "UINT16"
    if np_dtype == np.uint32:
        return "UINT32"
    if np_dtype == np.uint64:
        return "UINT64"
    if np_dtype == np.float16:
        return "FP16"
    if np_dtype == np.float32:
        return "FP32"
    if np_dtype == np.float64:
        return "FP64"
    if np_dtype == np.object_ or np_dtype.type == np.bytes_:
        return "BYTES"
    return None

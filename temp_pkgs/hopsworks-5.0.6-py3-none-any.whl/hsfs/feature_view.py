#
#   Copyright 2022 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

import json
import logging
import os
import warnings
from typing import (
    TYPE_CHECKING,
    Any,
    Literal,
    TypeVar,
)

import humps
import pandas as pd
from hopsworks_apigen import public
from hopsworks_common import client
from hopsworks_common.client.exceptions import FeatureStoreException
from hopsworks_common.core import alerts_api
from hopsworks_common.core.constants import HAS_NUMPY, HAS_POLARS
from hsfs import (
    engine,
    feature_group,
    storage_connector,
    tag,
    training_dataset,
    training_dataset_feature,
    usage,
    util,
)
from hsfs import serving_key as skm
from hsfs.constructor import filter, query
from hsfs.constructor.filter import Filter, Logic
from hsfs.constructor.lookback import FeatureGroupLookback, Lookback
from hsfs.core import data_source as ds
from hsfs.core import (
    explicit_provenance,
    feature_monitoring_config_engine,
    feature_monitoring_result_engine,
    feature_view_engine,
    job,
    statistics_engine,
    transformation_execution_dag,
    transformation_function_engine,
    vector_server,
)
from hsfs.core import feature_monitoring_config as fmc
from hsfs.core import feature_monitoring_result as fmr
from hsfs.core.feature_view_api import FeatureViewApi
from hsfs.core.vector_db_client import VectorDbClient
from hsfs.decorators import typechecked
from hsfs.feature import Feature
from hsfs.training_dataset_split import TrainingDatasetSplit
from hsfs.transformation_function import TransformationFunction, TransformationType


if TYPE_CHECKING:
    from collections.abc import Callable
    from datetime import date, datetime

    from hopsworks_common.alert import Alert, FeatureViewAlert
    from hopsworks_common.core.type_systems import HopsworksLoggingMetadataType
    from hopsworks_common.job import Job
    from hsfs.constructor.filter import Filter, Logic
    from hsfs.core.feature_logging import FeatureLogging
    from hsfs.feature_logger import FeatureLogger
    from hsfs.hopsworks_udf import HopsworksUdf
    from hsfs.statistics import Statistics
    from hsfs.statistics_config import StatisticsConfig
    from hsml.model import Model


if HAS_NUMPY:
    import numpy as np


_logger = logging.getLogger(__name__)

# TODO: Rework TrainingDatasetDataFrameTypes
TrainingDatasetDataFrameTypes = (
    pd.DataFrame
    | TypeVar("pyspark.sql.DataFrame")  # noqa: F821
    | TypeVar("pyspark.RDD")  # noqa: F821
    | np.ndarray
    | list[list[Any]]
)

if HAS_POLARS:
    import polars as pl

    TrainingDatasetDataFrameTypes = TrainingDatasetDataFrameTypes | pl.DataFrame


# TODO: Rework SplineDataFrameTypes
SplineDataFrameTypes = (
    pd.DataFrame
    | TypeVar("pyspark.sql.DataFrame")  # noqa: F821
    | TypeVar("pyspark.RDD")  # noqa: F821
    | np.ndarray
    | list[list[Any]]
    | TypeVar("SplineGroup")  # noqa: F821
)


_logger = logging.getLogger(__name__)


@public
@typechecked
class FeatureView:
    """Metadata class for Hopsworks feature views.

    Feature view is a logical grouping of features, defined by a query over feature groups.
    """

    ENTITY_TYPE = "featureview"
    NOT_FOUND_ERROR_CODE = 270181

    def __init__(
        self,
        name: str,
        query: query.Query,
        featurestore_id: int,
        id: int | None = None,
        version: int | None = None,
        description: str | None = "",
        labels: list[str] | None = None,
        inference_helper_columns: list[str] | None = None,
        training_helper_columns: list[str] | None = None,
        transformation_functions: list[TransformationFunction | HopsworksUdf]
        | None = None,
        featurestore_name: str | None = None,
        serving_keys: list[skm.ServingKey] | None = None,
        logging_enabled: bool | None = False,
        extra_log_columns: list[Feature] | dict[str, str] | None = None,
        missing_mandatory_tags: list[dict[str, Any]] | None = None,
        tags: list[tag.Tag] | None = None,
        **kwargs,
    ) -> None:
        self._name = name
        self._id = id
        self._tags: list[tag.Tag] | None = tags
        self._query = query
        # Check if query has any ambiguous columns and print warning in these cases:
        query.check_and_warn_ambiguous_features()
        self._featurestore_id = featurestore_id
        self._feature_store_id = featurestore_id  # for consistency with feature group
        self._feature_store_name = featurestore_name
        self._version = version
        self._description = description
        self._labels = labels if labels else []
        self._inference_helper_columns = (
            inference_helper_columns if inference_helper_columns else []
        )
        self._training_helper_columns = (
            training_helper_columns if training_helper_columns else []
        )

        self._transformation_functions: list[TransformationFunction] = []

        if transformation_functions:
            for transformation_function in transformation_functions:
                if not isinstance(transformation_function, TransformationFunction):
                    self._transformation_functions.append(
                        TransformationFunction(
                            self.featurestore_id,
                            hopsworks_udf=transformation_function,
                            version=1,
                            transformation_type=TransformationType.MODEL_DEPENDENT,
                        )
                    )
                else:
                    if (
                        not transformation_function.transformation_type
                        or transformation_function.transformation_type
                        == TransformationType.UNDEFINED
                    ):
                        transformation_function.transformation_type = (
                            TransformationType.MODEL_DEPENDENT
                        )
                    self._transformation_functions.append(transformation_function)

        if self._transformation_functions:
            self._transformation_functions = FeatureView._sort_transformation_functions(
                self._transformation_functions
            )

        self._features = []
        self._request_parameters = None
        self._feature_view_engine: feature_view_engine.FeatureViewEngine = (
            feature_view_engine.FeatureViewEngine(featurestore_id)
        )
        self._transformation_function_engine: transformation_function_engine.TransformationFunctionEngine = transformation_function_engine.TransformationFunctionEngine(
            featurestore_id
        )
        self.__vector_server: vector_server.VectorServer | None = None
        self.__batch_scoring_server: vector_server.VectorServer | None = None
        self.__fully_qualified_primary_keys: list[str] = None
        self.__fully_qualified_event_time: list[str] = None
        self._serving_keys = serving_keys if serving_keys else []
        self._prefix_serving_key_map = {}
        self._primary_keys: set[str] = set()  # Lazy initialized via serving keys

        self._vector_db_client = None
        self._statistics_engine = statistics_engine.StatisticsEngine(
            featurestore_id, self.ENTITY_TYPE
        )
        self._logging_enabled = True if extra_log_columns else logging_enabled
        self._feature_logging = None
        self._alert_api = alerts_api.AlertsApi()
        self._missing_mandatory_tags = missing_mandatory_tags or []

        self._extra_log_columns: list[Feature] = (
            [
                Feature.from_response_json(feat) if isinstance(feat, dict) else feat
                for feat in extra_log_columns
            ]
            if extra_log_columns
            else None
        )
        if self._id:
            self._init_feature_monitoring_engine()

        # last_accessed_training_dataset is only from the perspective of the client itself, and not the backend.
        # if multiple clients do training datasets operations, each will have their own view of the last accessed.
        # last accessed (read/write) training dataset is not necessarily the newest (highest version).
        self._last_accessed_training_dataset = None

        self._feature_logger = None
        self._serving_training_dataset_version = None
        # Worker count for parallel transformation application, set by
        # init_serving / init_batch_scoring and used as the default for
        # get_feature_vector(s) / get_batch_data when they are not given one.
        self._transformation_n_processes: int | None = None

        # Lazy initialization for column names used in feature logging.
        self.__label_column_names = None
        self.__transformed_feature_names = None
        self.__untransformed_feature_names = None
        self.__required_serving_key_names = None
        self.__root_feature_group_event_time_column_name = None
        self.__extra_logging_column_names = None

        self._on_demand_transformation_execution_graph: (
            transformation_execution_dag.TransformationExecutionDAG | None
        ) = None  # Initialized when the features are retrieved from the backend.

        # The complete on-demand transformation chain as serialized by the
        # backend. None until hydrated in from_response_json; while None the
        # property falls back to reconstructing the list from per-feature
        # attachments (older backends).
        self.__on_demand_transformation_functions: (
            list[TransformationFunction] | None
        ) = None

        # Building the DAG rejects a cyclic model-dependent configuration here, at
        # construction. The schema is not known yet, so the name-ambiguity check
        # runs when features arrive in from_response_json.
        self._model_dependent_transformation_execution_graph: transformation_execution_dag.TransformationExecutionDAG = transformation_execution_dag.TransformationExecutionDAG(
            self.transformation_functions,
        )

    @public
    def get_last_accessed_training_dataset(self):
        """Get the last accessed training dataset version used for this feature view.

        Note:
            The value does not take into account other connections to Hopsworks.
            If multiple clients do training datasets operations, each will have its own view of the last accessed dataset.
            Also, the last accessed training dataset is not necessarily the newest one with the highest version.
        """
        return self._last_accessed_training_dataset

    @public
    def delete(self, force: bool = False) -> None:
        """Delete current feature view, all associated metadata and training data.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # delete a feature view
            feature_view.delete()
            ```

        Danger: Potentially dangerous operation
            This operation drops all metadata associated with **this version** of the
            feature view **and** related training dataset **and** materialized data in HopsFS.

        Parameters:
            force:
                If True, delete the feature view even if models or deployments are using it.
                Defaults to False, which will raise an error if the feature view is in use.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        warnings.warn(
            f"All jobs associated to feature view `{self._name}`, version `{self._version}` will be removed.",
            util.JobWarning,
            stacklevel=2,
        )
        self._feature_view_engine._delete(self.name, self.version, force)

    @public
    @staticmethod
    def clean(
        feature_store_id: int,
        feature_view_name: str,
        feature_view_version: str,
        force: bool = False,
    ) -> None:
        """Delete the feature view and all associated metadata and training data.

        This can delete corrupted feature view which cannot be retrieved due to a corrupted query for example.

        Example:
            ```python
            # delete a feature view and all associated metadata
            from hsfs.feature_view import FeatureView

            FeatureView.clean(
                feature_store_id=1,
                feature_view_name='feature_view_name',
                feature_view_version=1
            )
            ```

        Danger: Potentially dangerous operation
            This operation drops all metadata associated with **this version** of the feature view **and** related training dataset **and** materialized data in HopsFS.

        Parameters:
            feature_store_id: ID of feature store.
            feature_view_name: Name of feature view.
            feature_view_version: Version of feature view.
            force:
                If True, delete the feature view even if models or deployments are using it.
                Defaults to False, which will raise an error if the feature view is in use.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        if not isinstance(feature_store_id, int):
            raise ValueError("`feature_store_id` should be an integer.")
        FeatureViewApi(feature_store_id).delete_by_name_version(
            feature_view_name, feature_view_version, force
        )

    @public
    def update(self) -> FeatureView:
        """Update the description of the feature view.

        Example: Update the feature view with a new description
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            feature_view.description = "new description"
            feature_view.update()

            # Description is updated in the metadata. Below should return "new description".
            fs.get_feature_view("feature_view_name", 1).description
            ```

        Returns:
            Updated feature view.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._feature_view_engine._update(self)

    @public
    @usage._method_logger
    def init_serving(
        self,
        training_dataset_version: int | None = None,
        external: bool | None = None,
        options: dict[str, Any] | None = None,
        init_sql_client: bool | None = None,
        init_rest_client: bool = False,
        reset_rest_client: bool = False,
        config_rest_client: dict[str, Any] | None = None,
        default_client: Literal["sql", "rest"] | None = None,
        feature_logger: FeatureLogger | None = None,
        n_processes: int | None = None,
        **kwargs,
    ) -> None:
        """Initialise feature view to retrieve feature vector from online and offline feature store.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # initialise feature view to retrieve a feature vector
            feature_view.init_serving(training_dataset_version=1)
            ```

        Parameters:
            training_dataset_version:
                Transformation statistics are fetched from training dataset and applied to the feature vector.
                Defaults to 1 for online feature store.
            external:
                If set to `True`, the connection to the online feature store is established using the same host as for the `host` parameter in the [`hopsworks.login`][hopsworks.login] method.
                If set to `False`, the online feature store storage connector is used which relies on the private IP.
                Defaults to `True` if connection to Hopsworks is established from external environment (e.g AWS Sagemaker or Google Colab), otherwise to `False`.
            options:
                Additional options as key/value pairs for configuring online serving engine.

                - key: kwargs of SqlAlchemy engine creation (See: https://docs.sqlalchemy.org/en/20/core/engines.html#sqlalchemy.create_engine).
                  For example: `{"pool_size": 10}`.
            init_sql_client:
                If set to `True`, this ensure the online store sql client is initialised, otherwise if init_rest_client is set to true it will skip initialising the sql client.
                By default the sql client is initialised if no client is specified to match legacy behaviour.
            init_rest_client:
                If set to `True`, this ensure the online store rest client is initialised.
                Pass additional configuration options via the rest_config parameter.
                Set reset_rest_client to `True` to reset the rest client.
                By default the rest client is not initialised.
            reset_rest_client: If set to `True`, the rest client will be reset and reinitialised with provided configuration.
            config_rest_client:
                Additional configuration options for the rest client.
                If the client is already initialised, this will be ignored.
                Options include:

                - `host`: string, optional.
                  The host of the online store.
                  Dynamically set if not provided.
                - `port`: int, optional.
                  The port of the online store.
                  Defaults to 4406.
                - `verify_certs`: boolean, optional.
                  Verify the certificates of the online store server.
                  Defaults to True.
                - `api_key`: string, optional.
                  The API key to authenticate with the online store.
                  The API key must be provided if initialising the rest client in an internal environment.
                - `timeout`: int, optional.
                  The timeout for the rest client in seconds.
                  Defaults to 2.
                - `use_ssl`: boolean, optional.
                  Use SSL to connect to the online store.
                  Defaults to True.
            default_client: Which client to default to if both are initialised.
            feature_logger:
                Custom feature logger which [`FeatureView.log`][hsfs.feature_view.FeatureView.log] uses to log feature vectors.
                If provided, feature vectors will not be inserted to logging feature group automatically when `FeatureView.log` is called.
            n_processes:
                Number of worker processes used to apply transformation functions in parallel during serving.
                When greater than one, the worker pool is pre-spawned here so the first `get_feature_vector(s)` call does not pay the spawn and engine-init latency.
        """
        # initiate batch scoring server
        # `training_dataset_version` should not be set if `None` otherwise backend will look up the td.
        try:
            self.init_batch_scoring(training_dataset_version)
        except ValueError as e:
            # In 3.3 or before, td version is set to 1 by default.
            # For backward compatibility, if a td version is required, set it to 1.
            if "Training data version is required for transformation" in str(e):
                self.init_batch_scoring(1)
            else:
                raise e
        self._serving_training_dataset_version = training_dataset_version
        # Compatibility with 3.7
        if init_sql_client is None:
            init_sql_client = kwargs.get("init_online_store_sql_client")
        if init_rest_client is False:
            init_rest_client = kwargs.get("init_online_store_rest_client", False)

        if training_dataset_version is None:
            training_dataset_version = 1
            warnings.warn(
                "No training dataset version was provided to initialise serving. Defaulting to version 1.",
                util.VersionWarning,
                stacklevel=1,
            )

        # initiate single vector server
        self._vector_server._init_serving(
            entity=self,
            external=external,
            inference_helper_columns=True,
            options=options,
            init_sql_client=init_sql_client,
            init_rest_client=init_rest_client,
            reset_rest_client=reset_rest_client,
            config_rest_client=config_rest_client,
            default_client=default_client,
            training_dataset_version=training_dataset_version,
        )

        self._prefix_serving_key_map = {
            f"{sk.prefix}{sk.feature_name}": sk
            for sk in self._vector_server.serving_keys
        }
        if len(self._get_embedding_fgs()) > 0:
            self._vector_db_client = VectorDbClient(
                self.query, serving_keys=self._serving_keys
            )

        if feature_logger:
            self._feature_logger = feature_logger
            if not self.logging_enabled:
                self.enable_logging()
            self._feature_logger.init(self)
        else:
            # reset feature logger in case init_serving is called again without feature logger
            self._feature_logger = None

        # Set last: init_serving runs after its internal init_batch_scoring, so
        # the serving worker count wins over the one that call recorded.
        self._transformation_n_processes = n_processes
        self._warmup_transformation_workers(n_processes)

    def _warmup_transformation_workers(self, n_processes: int | None) -> None:
        """Pre-spawn the transformation worker pool when parallel execution is requested.

        Called from init_serving / init_batch_scoring so callers do not warm the
        pool themselves. A no-op unless `n_processes` asks for parallelism, the
        Python engine is in use (Spark pushes transformations down), and the
        feature view actually has transformations to apply.
        """
        if (
            n_processes is not None
            and n_processes > 1
            and engine._get_type() != "spark"
            and (
                self.transformation_functions
                or self._on_demand_transformation_functions
            )
        ):
            transformation_function_engine.TransformationFunctionEngine._warmup_online_workers(
                n_processes
            )

    @staticmethod
    def _sort_transformation_functions(
        transformation_functions: list[TransformationFunction],
    ) -> list[TransformationFunction]:
        """Function that sorts transformation functions in the order of the output column names.

        The list of transformation functions are sorted based on the output columns names to maintain consistent ordering.

        Parameters:
            transformation_functions: List of transformation functions to be sorted.

        Returns:
            The sorted list of transformation functions.
        """
        return sorted(transformation_functions, key=lambda x: x.output_column_names[0])

    @public
    def init_batch_scoring(
        self,
        training_dataset_version: int | None = None,
        n_processes: int | None = None,
    ) -> None:
        """Initialise feature view to retrieve feature vector from offline feature store.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # initialise feature view to retrieve feature vector from offline feature store
            feature_view.init_batch_scoring(training_dataset_version=1)

            # get batch data
            batch_data = feature_view.get_batch_data(...)
            ```

        Parameters:
            training_dataset_version: Transformation statistics are fetched from training dataset and applied to the feature vector.
            n_processes:
                Number of worker processes used to apply transformation functions in parallel during batch scoring.
                When greater than one, the worker pool is pre-spawned here so the first batch call does not pay the spawn and engine-init latency.
        """
        self._serving_training_dataset_version = training_dataset_version
        self._batch_scoring_server._init_batch_scoring(
            self, training_dataset_version=training_dataset_version
        )
        self._transformation_n_processes = n_processes
        self._warmup_transformation_workers(n_processes)

    @public
    def get_batch_query(
        self,
        start_time: str | int | datetime | date | None = None,
        end_time: str | int | datetime | date | None = None,
        extra_filter: filter.Filter | filter.Logic | None = None,
        lookback: FeatureGroupLookback | Lookback | dict[str, Any] | None = None,
    ) -> str:
        """Get a query string of the batch query.

        Example: Batch query for the last 24 hours
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            import datetime
            start_date = (datetime.datetime.now() - datetime.timedelta(hours=24))
            end_date = (datetime.datetime.now())

            # get a query string of batch query
            query_str = feature_view.get_batch_query(
                start_time=start_date,
                end_time=end_date
            )
            # print query string
            print(query_str)
            ```

        Parameters:
            start_time:
                Start event time for the batch query, inclusive.
                Strings should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`, or `%Y-%m-%d %H:%M:%S.%f`.
                Int, i.e., Unix Epoch should be in seconds.
            end_time:
                End event time for the batch query, exclusive.
                Strings should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`, or `%Y-%m-%d %H:%M:%S.%f`.
                Int, i.e., Unix Epoch should be in seconds.
            extra_filter:
                Additional filters to be applied to the batch query on top of any feature view or training dataset filters.
                Filters are pushed down to the data layer and combined with existing filters using AND logic.
            lookback:
                Optional lookback window to bound the PIT join.
                For one window across every feature group, pass a `FeatureGroupLookback` — e.g. `FeatureGroupLookback(key="PARTITION_KEY", start=date(2026, 5, 5), end=date(2026, 5, 17))` or its dict form `{"key": "PARTITION_KEY", "start": date(2026, 5, 5), "end": date(2026, 5, 17)}`.
                For different windows per feature group, pass a `Lookback` — e.g. `Lookback(default=FeatureGroupLookback(...), feature_group_lookbacks={"dim_a": FeatureGroupLookback(...)})` or its dict form `{"default": {...}, "feature_group_lookbacks": {"dim_a": {...}}}`.
                See [`FeatureGroupLookback`][hsfs.constructor.lookback.FeatureGroupLookback] and [`Lookback`][hsfs.constructor.lookback.Lookback] for accepted key values, validation rules, and per-FG key matching semantics.

        Returns:
            The batch query.
        """
        return self._feature_view_engine._get_batch_query_string(
            self,
            start_time,
            end_time,
            training_dataset_version=(
                self._batch_scoring_server.training_dataset_version
                if self._batch_scoring_server
                else None
            ),
            extra_filter=extra_filter,
            lookback=Lookback.from_user_input(lookback),
        )

    @public
    def get_feature_vector(
        self,
        entry: dict[str, Any] | None = None,
        passed_features: dict[str, Any] | None = None,
        external: bool | None = None,
        return_type: Literal["list", "polars", "numpy", "pandas"] = "list",
        allow_missing: bool = False,
        force_rest_client: bool = False,
        force_sql_client: bool = False,
        transform: bool | None = True,
        on_demand_features: bool | None = True,
        request_parameters: dict[str, Any] | None = None,
        transformation_context: dict[str, Any] = None,
        logging_data: bool = False,
        n_processes: int | None = None,
    ) -> (
        list[Any]
        | pd.DataFrame
        | np.ndarray
        | pl.DataFrame
        | HopsworksLoggingMetadataType
    ):
        """Returns assembled feature vector from online feature store.

        Call [`FeatureView.init_serving`][hsfs.feature_view.FeatureView.init_serving] before this method if the following configurations are needed:

        1. The training dataset version of the transformation statistics.
        2. Additional configurations of online serving engine.

        Warning: Missing primary key entries
            If the provided primary key `entry` can't be found in one or more of the feature groups used by this feature view the call to this method will raise an exception.
            Alternatively, setting `allow_missing` to `True` returns a feature vector with missing values.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get assembled serving vector as a python list
            feature_view.get_feature_vector(
                entry = {"pk1": 1, "pk2": 2}
            )

            # get assembled serving vector as a pandas dataframe
            feature_view.get_feature_vector(
                entry = {"pk1": 1, "pk2": 2},
                return_type = "pandas"
            )

            # get assembled serving vector as a numpy array
            feature_view.get_feature_vector(
                entry = {"pk1": 1, "pk2": 2},
                return_type = "numpy"
            )
            ```

        Example: Get feature vector with user-supplied features
            ```python
            # get feature store instance
            fs = ...
            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # the application provides a feature value 'app_attr'
            app_attr = ...

            # get a feature vector
            feature_view.get_feature_vector(
                entry = {"pk1": 1, "pk2": 2},
                passed_features = { "app_feature" : app_attr }
            )
            ```

        Example: Logging feature vector
            ```python
            # get feature store instance
            fs = ...
            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # the application provides a feature value 'app_attr'
            app_attr = ...

            # get a feature vector
            feature_vector = feature_view.get_feature_vector(
                entry = {"pk1": 1, "pk2": 2},
                passed_features = { "app_feature" : app_attr },
                logging_data = True
            )

            # make predictions using the feature vector
            predictions = model.predict(feature_vector)

            # log the feature vector
            feature_view.log(feature_vector, predictions=predictions)
            ```

        Parameters:
            entry:
                Dictionary of feature group primary key and values provided by serving application.
                Set of required primary keys is [`FeatureView.primary_keys`][hsfs.feature_view.FeatureView.primary_keys].
                If the required primary keys is not provided, it will look for name of the primary key in feature group in the entry.
            passed_features:
                Dictionary of feature values provided by the application at runtime.
                They can replace features values fetched from the feature store as well as providing feature values which are not available in the feature store.
                These values take priority over features retrieved from the online feature store but are overridden by `request_parameters` if the same key exists in both.
            external:
                If set to `True`, the connection to the online feature store is established using the same host as for the `host` parameter in the [`hopsworks.login`][hopsworks.login] method.
                If set to `False`, the online feature store storage connector is used which relies on the private IP.
                Defaults to `True` if connection to Hopsworks is established from external environment (e.g AWS Sagemaker or Google Colab), otherwise to `False`.
            return_type: In which format to return the feature vector.
            allow_missing: Setting to `True` returns feature vectors with missing values.
            force_rest_client:
                If set to True, reads from online feature store using the REST client if initialised.
            force_sql_client:
                If set to True, reads from online feature store using the SQL client if initialised.
            transform:
                If set to `True`, model-dependent transformations are applied to the feature vector, and `on_demand_feature` is automatically set to `True`, ensuring the inclusion of on-demand features.
                If set to `False`, the function returns the feature vector without applying any model-dependent transformations.
            on_demand_features: Setting this to `False` returns untransformed feature vectors without any on-demand features.
            request_parameters: Request parameters required by on-demand transformation functions to compute on-demand features present in the feature view.
                These parameters take **highest priority** when resolving feature values - if a key exists in both `request_parameters` and `passed_features` or in the retrieved feature vector, the value from `request_parameters` is used.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution.
                If no context variables are provided, this parameter defaults to `None`.
            logging_data:
                Setting this to `True` return feature vector with logging metadata.
                The feature vector will contain only the required features.
                The logging metadata is available as part of an additional attribute `hopsworks_logging_metadata` of the returned object.
                The logging metadata contains the untransformed features, transformed features, inference helpers, serving keys, request parameters and event time.
                The feature vector object returned can be passed to `feature_view.log()` to log the feature vector along with all the logging metadata.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                When not set, the value passed to `init_serving` is used.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            Returned `list`, `pd.DataFrame`, `polars.DataFrame` or `np.ndarray` (the exact type dependends on `return_type`) contains feature values related to provided primary keys, ordered according to positions of this features in the feature view query.

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: When primary key entry cannot be found in one or more of the feature groups used by this feature view.
        """
        if not self._vector_server._serving_initialized:
            self.init_serving(external=external)

        if n_processes is None:
            n_processes = self._transformation_n_processes

        vector_db_features = None
        if self._vector_db_client:
            vector_db_features = self._get_vector_db_result(entry)
        return self._vector_server._get_feature_vector(
            entry=entry,
            return_type=return_type,
            passed_features=passed_features,
            allow_missing=allow_missing,
            vector_db_features=vector_db_features,
            force_rest_client=force_rest_client,
            force_sql_client=force_sql_client,
            transform=transform,
            on_demand_features=on_demand_features,
            request_parameters=request_parameters,
            transformation_context=transformation_context,
            logging_data=logging_data,
            n_processes=n_processes,
        )

    @public
    def get_feature_vectors(
        self,
        entry: list[dict[str, Any]] | None = None,
        passed_features: list[dict[str, Any]] | None = None,
        external: bool | None = None,
        return_type: Literal["list", "polars", "numpy", "pandas"] = "list",
        allow_missing: bool = False,
        force_rest_client: bool = False,
        force_sql_client: bool = False,
        transform: bool | None = True,
        on_demand_features: bool | None = True,
        request_parameters: list[dict[str, Any]] | None = None,
        transformation_context: dict[str, Any] = None,
        logging_data: bool = False,
        n_processes: int | None = None,
    ) -> (
        list[list[Any]]
        | pd.DataFrame
        | np.ndarray
        | pl.DataFrame
        | HopsworksLoggingMetadataType
    ):
        """Returns assembled feature vectors in batches from online feature store.

        Call [`FeatureView.init_serving`][hsfs.feature_view.FeatureView.init_serving] before this method if the following configurations are needed.

        1. The training dataset version of the transformation statistics.
        2. Additional configurations of online serving engine.

        Warning: Missing primary key entries
            If any of the provided primary key elements in `entry` can't be found in any of the feature groups, no feature vector for that primary key value will be returned.
            If it can be found in at least one but not all feature groups used by this feature view the call to this method will raise an exception.
            Alternatively, setting `allow_missing` to `True` returns feature vectors with missing values.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get assembled serving vectors as a python list of lists
            feature_view.get_feature_vectors(
                entry = [
                    {"pk1": 1, "pk2": 2},
                    {"pk1": 3, "pk2": 4},
                    {"pk1": 5, "pk2": 6}
                ]
            )

            # get assembled serving vectors as a pandas dataframe
            feature_view.get_feature_vectors(
                entry = [
                    {"pk1": 1, "pk2": 2},
                    {"pk1": 3, "pk2": 4},
                    {"pk1": 5, "pk2": 6}
                ],
                return_type = "pandas"
            )

            # get assembled serving vectors as a numpy array
            feature_view.get_feature_vectors(
                entry = [
                    {"pk1": 1, "pk2": 2},
                    {"pk1": 3, "pk2": 4},
                    {"pk1": 5, "pk2": 6}
                ],
                return_type = "numpy"
            )
            ```

        Example: Logging feature vectors
            ```python
            # get feature store instance
            fs = ...
            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # the application provides a feature value 'app_attr'
            app_attr = ...

            # get a feature vectors
            feature_vectors = feature_view.get_feature_vectors(
                entry = [
                    {"pk1": 1, "pk2": 2},
                    {"pk1": 3, "pk2": 4},
                    {"pk1": 5, "pk2": 6}
                ],
                logging_data = True
            )

            # make predictions using the feature vectors
            predictions = model.predict(feature_vectors)

            # log the feature vectors
            feature_view.log(feature_vectors, predictions=predictions)
            ```

        Parameters:
            entry:
                A list of dictionary of feature group primary key and values provided by serving application.
                Set of required primary keys is [`FeatureView.primary_keys`][hsfs.feature_view.FeatureView.primary_keys].
                If the required primary keys is not provided, it will look for name of the primary key in feature group in the entry.
            passed_features:
                A list of dictionary of feature values provided by the application at runtime.
                They can replace features values fetched from the feature store as well as providing feature values which are not available in the feature store.
                These values take priority over features retrieved from the online feature store but are overridden by `request_parameters` if the same key exists in both.
            external:
                If set to `True`, the connection to the online feature store is established using the same host as for the `host` parameter in the [`hopsworks.login`][hopsworks.login] method.
                If set to `False`, the online feature store storage connector is used which relies on the private IP.
                Defaults to `True` if connection to Hopsworks is established from external environment (e.g AWS Sagemaker or Google Colab), otherwise to `False`.
            return_type: The format in which to return the feature vectors.
            allow_missing: Setting to `True` returns feature vectors with missing values.
            force_rest_client: If set to `True`, reads from online feature store using the REST client if initialised.
            force_sql_client: If set to `True`, reads from online feature store using the SQL client if initialised.
            transform:
                If set to `True`, model-dependent transformations are applied to the feature vector, and `on_demand_feature` is automatically set to `True`, ensuring the inclusion of on-demand features.
                If set to `False`, the function returns the feature vector without applying any model-dependent transformations.
            on_demand_features: Setting this to `False` returns untransformed feature vectors without any on-demand features.
            request_parameters: Request parameters required by on-demand transformation functions to compute on-demand features present in the feature view.
                These parameters take **highest priority** when resolving feature values - if a key exists in both `request_parameters` and `passed_features` or in the retrieved feature vectors, the value from `request_parameters` is used.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution.
                If no context variables are provided, this parameter defaults to `None`.
            logging_data:
                Setting this to `True` return feature vector with logging metadata.
                The feature vectors will contain only contain the required features.
                The logging metadata is available as part of an additional attribute `hopsworks_logging_metadata` of the returned object.
                The logging metadata contains the untransformed features, transformed features, inference helpers, serving keys, request parameters and event time.
                The feature vector object returned can be passed to `feature_view.log()` to log the feature vectors along with all the logging metadata.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                When not set, the value passed to `init_serving` is used.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            Returned `list[list]`, `pd.DataFrame`, `polars.DataFrame` or `np.ndarray` (depending on the `return_type`) contains feature values related to provided primary keys, ordered according to positions of this features in the feature view query.

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: When primary key entry cannot be found in one or more of the feature groups used by this feature view.
        """
        if not self._vector_server._serving_initialized:
            self.init_serving(external=external, init_rest_client=force_rest_client)

        if n_processes is None:
            n_processes = self._transformation_n_processes

        vector_db_features = []
        if self._vector_db_client:
            for _entry in entry:
                vector_db_features.append(self._get_vector_db_result(_entry))

        return self._vector_server._get_feature_vectors(
            entries=entry,
            return_type=return_type,
            passed_features=passed_features,
            allow_missing=allow_missing,
            vector_db_features=vector_db_features,
            force_rest_client=force_rest_client,
            force_sql_client=force_sql_client,
            transform=transform,
            on_demand_features=on_demand_features,
            request_parameters=request_parameters,
            transformation_context=transformation_context,
            logging_data=logging_data,
            n_processes=n_processes,
        )

    @public
    def get_inference_helper(
        self,
        entry: dict[str, Any],
        external: bool | None = None,
        return_type: Literal["pandas", "dict", "polars"] = "pandas",
        force_rest_client: bool = False,
        force_sql_client: bool = False,
    ) -> pd.DataFrame | pl.DataFrame | dict[str, Any]:
        """Returns assembled inference helper column vectors from online feature store.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get assembled inference helper column vector
            feature_view.get_inference_helper(
                entry = {"pk1": 1, "pk2": 2}
            )
            ```

        Parameters:
            entry:
                Dictionary of feature group primary key and values provided by serving application.
                Set of required primary keys is [`FeatureView.primary_keys`][hsfs.feature_view.FeatureView.primary_keys].
            external:
                If set to `True`, the connection to the online feature store is established using the same host as for the `host` parameter in the [`hopsworks.login`][hopsworks.login] method.
                If set to `False`, the online feature store storage connector is used which relies on the private IP.
                Defaults to `True` if connection to Hopsworks is established from external environment (e.g AWS Sagemaker or Google Colab), otherwise to `False`.
            return_type: The format in which to return the dataframe.
            force_rest_client: If set to `True`, reads from online feature store using the REST client if initialised.
            force_sql_client: If set to `True`, reads from online feature store using the SQL client if initialised.

        Returns:
            The dataframe.

        Raises:
            Exception: When primary key entry cannot be found in one or more of the feature groups used by this feature view.
        """
        if not self._vector_server._serving_initialized:
            self.init_serving(external=external, init_rest_client=force_rest_client)
        return self._vector_server._get_inference_helper(
            entry, return_type, force_rest_client, force_sql_client
        )

    @public
    def get_inference_helpers(
        self,
        entry: list[dict[str, Any]],
        external: bool | None = None,
        return_type: Literal["pandas", "dict", "polars"] = "pandas",
        force_sql_client: bool = False,
        force_rest_client: bool = False,
    ) -> list[dict[str, Any]] | pd.DataFrame | pl.DataFrame:
        """Returns assembled inference helper column vectors in batches from online feature store.

        Warning: Missing primary key entries
            If any of the provided primary key elements in `entry` can't be found in any of the feature groups, no inference helper column vectors for that primary key value will be returned.
            If it can be found in at least one but not all feature groups used by this feature view the call to this method will raise an exception.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get assembled inference helper column vectors
            feature_view.get_inference_helpers(
                entry = [
                    {"pk1": 1, "pk2": 2},
                    {"pk1": 3, "pk2": 4},
                    {"pk1": 5, "pk2": 6}
                ]
            )
            ```

        Parameters:
            entry:
                A list of dictionary of feature group primary key and values provided by serving application.
                Set of required primary keys is [`FeatureView.primary_keys`][hsfs.feature_view.FeatureView.primary_keys].
            external:
                If set to `True`, the connection to the online feature store is established using the same host as for the `host` parameter in the [`hopsworks.login`][hopsworks.login] method.
                If set to `False`, the online feature store storage connector is used which relies on the private IP.
                Defaults to `True` if connection to Hopsworks is established from external environment (e.g AWS Sagemaker or Google Colab), otherwise to `False`.
            return_type: The format in which to return the dataframes.
            force_sql_client: If set to `True`, reads from online feature store using the SQL client if initialised.
            force_rest_client: If set to `True`, reads from online feature store using the REST client if initialised.

        Returns:
            Returned `pd.DataFrame`, `polars.DataFrame` or `list[dict]` (depending on `return_type`) contains feature values related to provided primary keys, ordered according to positions of this features in the feature view query.

        Raises:
            Exception: When primary key entry cannot be found in one or more of the feature groups used by this feature view.
        """
        if self._vector_server is None:
            self.init_serving(external=external, init_rest_client=force_rest_client)
        return self._vector_server._get_inference_helpers(
            entry, return_type, force_rest_client, force_sql_client
        )

    def _get_vector_db_result(
        self,
        entry: dict[str, Any],
    ) -> dict[str, Any] | None:
        if not self._vector_db_client:
            return {}
        result_vectors = {}
        for join_index, fg in self._vector_db_client.embedding_fg_by_join_index.items():
            complete, fg_entry = self._vector_db_client._filter_entry_by_join_index(
                entry, join_index
            )
            if not complete:
                # Not retrieving from vector db if entry is not completed
                continue
            vector_db_features = self._vector_db_client._read(
                fg.id,
                fg.columns,
                keys=fg_entry,
                index_name=fg.embedding_index.index_name,
            )

            # if result is not empty
            if vector_db_features:
                vector_db_features = vector_db_features[0]  # get the first result
                result_vectors.update(vector_db_features)
        return result_vectors

    @public
    def find_neighbors(
        self,
        embedding: list[int | float],
        feature: Feature | None = None,
        k: int | None = 10,
        filter: Filter | Logic | None = None,
        external: bool | None = None,
        return_type: Literal["list", "polars", "pandas"] = "list",
    ) -> list[list[Any]]:
        """Finds the nearest neighbors for a given embedding in the vector database.

        If `filter` is specified, or if embedding feature is stored in default project index, the number of results returned may be less than k.
        Try using a large value of k and extract the top k items from the results if needed.

        Warning: Duplicate column error in Polars
            If the feature view has duplicate column names, attempting to create a polars DataFrame will raise an error.
            To avoid this, set `return_type` to `"list"` or `"pandas"`.

        Parameters:
            embedding: The target embedding for which neighbors are to be found.
            feature:
                The feature used to compute similarity score.
                Required only if there are multiple embeddings.
            k: The number of nearest neighbors to retrieve.
            filter: A filter expression to restrict the search space.
            external:
                If set to `True`, the connection to the online feature store is established using the same host as for the `host` parameter in the [`hopsworks.login`][hopsworks.login] method.
                If set to `False`, the online feature store storage connector is used which relies on the private IP.
                Defaults to `True` if connection to Hopsworks is established from external environment (e.g AWS Sagemaker or Google Colab), otherwise to `False`.
            return_type: The format in which to return the neighbors.

        Returns:
            The nearest neighbor feature vectors.

        Example:
            ```python
            embedding_index = EmbeddingIndex()
            embedding_index.add_embedding(name="user_vector", dimension=3)
            fg = fs.create_feature_group(
                        name='air_quality',
                        embedding_index=embedding_index,
                        version=1,
                        primary_key=['id1'],
                        online_enabled=True,
                    )
            fg.insert(data)
            fv = fs.create_feature_view("air_quality", fg.select_all())
            fv.find_neighbors(
                [0.1, 0.2, 0.3],
                k=5,
            )

            # apply filter
            fg.find_neighbors(
                [0.1, 0.2, 0.3],
                k=5,
                feature=fg.user_vector,  # optional
                filter=(fg.id1 > 10) & (fg.id1 < 30)
            )
            ```
        """
        if self._vector_db_client is None:
            self.init_serving(external=external)
        results = self._vector_db_client._find_neighbors(
            embedding,
            feature=(feature if feature else None),
            k=k,
            filter=filter,
        )
        if len(results) == 0:
            return []

        return self._vector_server._get_feature_vectors(
            [self._extract_primary_key(res[1]) for res in results],
            return_type=return_type,
            vector_db_features=[res[1] for res in results],
            allow_missing=True,
        )

    def _extract_primary_key(self, result_key: dict[str, str]) -> dict[str, str]:
        primary_key_map = {}
        for prefix_sk, sk in self._prefix_serving_key_map.items():
            if prefix_sk in result_key:
                primary_key_map[sk.required_serving_key] = result_key[prefix_sk]
            elif sk.feature_name in result_key:  # fall back to use raw feature name
                primary_key_map[sk.required_serving_key] = result_key[sk.feature_name]
        if len(set(self._vector_server.required_serving_keys)) > len(primary_key_map):
            raise FeatureStoreException(
                f"Failed to get feature vector because required primary key [{', '.join(list({sk.required_serving_key for sk in self._prefix_serving_key_map.values()} - primary_key_map.keys()))}] are not present in vector db."
                "If the join of the embedding feature group in the query does not have a prefix,"
                " try to create a new feature view with prefix attached."
            )
        return primary_key_map

    def _get_embedding_fgs(
        self,
    ) -> set[feature_group.FeatureGroup]:
        return {fg for fg in self.query.featuregroups if fg.embedding_index}

    @public
    @usage._method_logger
    def get_batch_data(
        self,
        start_time: str | int | datetime | date | None = None,
        end_time: str | int | datetime | date | None = None,
        read_options: dict[str, Any] | None = None,
        spine: SplineDataFrameTypes | None = None,
        primary_key: bool = False,
        event_time: bool = False,
        inference_helper_columns: bool = False,
        dataframe_type: Literal[
            "default", "spark", "pandas", "polars", "numpy", "python"
        ] = "default",
        transformed: bool | None = True,
        transformation_context: dict[str, Any] = None,
        logging_data: bool = False,
        extra_filter: filter.Filter | filter.Logic | None = None,
        lookback: FeatureGroupLookback | Lookback | dict[str, Any] | None = None,
        n_processes: int | None = None,
        **kwargs,
    ) -> TrainingDatasetDataFrameTypes | HopsworksLoggingMetadataType:
        """Get a batch of data from an event time interval from the offline feature store.

        Example: Batch data for the last 24 hours
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            import datetime
            start_date = (datetime.datetime.now() - datetime.timedelta(hours=24))
            end_date = (datetime.datetime.now())

            # get a batch of data
            df = feature_view.get_batch_data(
                start_time=start_date,
                end_time=end_date
            )
            ```

        Example: Log Batch data for the last 24 hours
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            import datetime
            start_date = (datetime.datetime.now() - datetime.timedelta(hours=24))
            end_date = (datetime.datetime.now())

            # get a batch of data
            df = feature_view.get_batch_data(
                start_time=start_date,
                end_time=end_date,
                logging_data=True
            )

            # make predictions using the batch data
            predictions = model.predict(df)

            # log the batch data
            feature_view.log(df, predictions=predictions)
            ```

        Warning: Spine Groups/Dataframes
            Spine groups and dataframes are currently only supported with the Spark engine and Spark dataframes.

        Parameters:
            start_time:
                Start event time for the batch query, inclusive.
                Strings should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`, or `%Y-%m-%d %H:%M:%S.%f`.
                Int, i.e., Unix Epoch should be in seconds.
            end_time:
                End event time for the batch query, exclusive.
                Strings should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`, or `%Y-%m-%d %H:%M:%S.%f`.
                Int, i.e., Unix Epoch should be in seconds.
            read_options:
                User provided read options for python engine, defaults to `{}`:

                - key `"arrow_flight_config"` to pass a dictionary of arrow flight configurations.
                  For example: `{"arrow_flight_config": {"timeout": 900}}`.

            spine:
                Spine dataframe with primary key, event time and label column to use for point in time join when fetching features.
                Defaults to `None` and is only required when feature view was created with spine group in the feature query.
                It is possible to directly pass a spine group instead of a dataframe to overwrite the left side of the feature join, however, the same features as in the original feature group that is being replaced need to be available in the spine group.
            primary_key:
                Whether to include primary key features or not.
                Defaults to `False`, no primary key features.
            event_time:
                Whether to include event time feature or not.
                Defaults to `False`, no event time feature.
            inference_helper_columns:
                Whether to include inference helper columns or not.
                Inference helper columns are a list of feature names in the feature view, defined during its creation, that may not be used in training the model itself but can be used during batch or online inference for extra information.
                If inference helper columns were not defined in the feature view `inference_helper_columns=True` will not any effect.
                Defaults to `False`, no helper columns.
            dataframe_type:
                The type of the returned dataframe.
                Defaults to `"default"`, which maps to Spark dataframe for the Spark Engine and Pandas dataframe for the Python engine.
            transformed: Setting to `False` returns the untransformed feature vectors.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution.
                If no context variables are provided, this parameter defaults to `None`.
            logging_data:
                Setting this to `True` return batch data with logging metadata.
                The batch data will contain only contain the required features.
                The logging metadata is available as part of an additional attribute `hopsworks_logging_metadata` of the returned object.
                The logging metadata contains the untransformed features, transformed features, inference helpers, serving keys, request parameters and event time.
                The batch data object returned can be passed to `feature_view.log()` to log the feature vectors along with all the logging metadata.
            extra_filter:
                Additional filters to be applied to the batch data on top of any feature view or training dataset filters.
                Filters are pushed down to the data layer and combined with existing filters using AND logic.
            lookback:
                Optional lookback window to bound the PIT join.
                For one window across every feature group, pass a `FeatureGroupLookback` — e.g. `FeatureGroupLookback(key="PARTITION_KEY", start=date(2026, 5, 5), end=date(2026, 5, 17))` or its dict form `{"key": "PARTITION_KEY", "start": date(2026, 5, 5), "end": date(2026, 5, 17)}`.
                For different windows per feature group, pass a `Lookback` — e.g. `Lookback(default=FeatureGroupLookback(...), feature_group_lookbacks={"dim_a": FeatureGroupLookback(...)})` or its dict form `{"default": {...}, "feature_group_lookbacks": {"dim_a": {...}}}`.
                See [`FeatureGroupLookback`][hsfs.constructor.lookback.FeatureGroupLookback] and [`Lookback`][hsfs.constructor.lookback.Lookback] for accepted key values, validation rules, and per-FG key matching semantics.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                When not set, the value passed to `init_batch_scoring` is used.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            DataFrame: The spark dataframe containing the feature data.
            pyspark.DataFrame: A Spark DataFrame.
            pandas.DataFrame: A Pandas DataFrame.
            polars.DataFrame: A Polars DataFrame.
            numpy.ndarray: A two-dimensional Numpy array.
            list: A two-dimensional Python list.
        """
        if not self._batch_scoring_server._serving_initialized:
            self.init_batch_scoring()

        if n_processes is None:
            n_processes = self._transformation_n_processes

        return self._feature_view_engine._get_batch_data(
            self,
            start_time,
            end_time,
            self._batch_scoring_server.training_dataset_version,
            self._batch_scoring_server._model_dependent_transformation_functions_execution_graph,
            read_options,
            spine,
            kwargs.get("primary_keys") or primary_key,
            event_time,
            inference_helper_columns,
            dataframe_type,
            transformed=transformed,
            transformation_context=transformation_context,
            logging_data=logging_data,
            extra_filter=extra_filter,
            lookback=Lookback.from_user_input(lookback),
            n_processes=n_processes,
        )

    @public
    def add_tag(self, name: str, value: Any) -> None:
        """Attach a tag to a feature view.

        A tag consists of a name and value pair.
        Tag names are unique identifiers across the whole cluster.
        The value of a tag can be any valid json - primitives, arrays or json objects.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # attach a tag to a feature view
            feature_view.add_tag(name="tag_schema", value={"key", "value"})
            ```

        Parameters:
            name: Name of the tag to be added.
            value: Value of the tag to be added.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._feature_view_engine._add_tag(self, name, value)

    @public
    def get_tag(self, name: str) -> tag.Tag | None:
        """Get the tags of a feature view.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get a tag of a feature view
            name = feature_view.get_tag('tag_name')
            ```

        Parameters:
            name: Name of the tag to get.

        Returns:
            Tag value or `None` if it does not exist.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._feature_view_engine._get_tag(self, name)

    @public
    def get_tags(self) -> dict[str, tag.Tag]:
        """Returns all tags attached to a feature view.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get tags
            list_tags = feature_view.get_tags()
            ```

        Returns:
            The dictionary of tags.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._feature_view_engine._get_tags(self)

    @public
    def get_parent_feature_groups(self) -> explicit_provenance.Links | None:
        """Get the parents of this feature view, based on explicit provenance.

        Parents are feature groups or external feature groups. These feature
        groups can be accessible, deleted or inaccessible.
        For deleted and inaccessible feature groups, only minimal information is
        returned.

        Returns:
            Object containing the section of provenance graph requested or `None` if it does not exist.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        return self._feature_view_engine._get_parent_feature_groups(self)

    @public
    def get_newest_model(
        self, training_dataset_version: int | None = None
    ) -> Model | None:
        """Get the latest generated model using this feature view, based on explicit provenance.

        Search only through the accessible models.
        For more items use the base method, see get_models_provenance.

        Parameters:
            training_dataset_version: Filter generated models based on the used training dataset version.

        Returns:
            Newest Generated Model or `None` if it does not exist.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        models = self.get_models(training_dataset_version=training_dataset_version)
        models.sort(key=lambda model: model.created, reverse=True)
        if models:
            return models[0]
        return None

    @public
    def get_models(self, training_dataset_version: int | None = None) -> list[Model]:
        """Get the generated models using this feature view, based on explicit provenance.

        Only the accessible models are returned.
        For more items use the base method, see get_models_provenance.

        Parameters:
            training_dataset_version: Filter generated models based on the used training dataset version.

        Returns:
            List of models.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        models = self.get_models_provenance(
            training_dataset_version=training_dataset_version
        )
        if models and models.accessible:
            return models.accessible
        return []

    @public
    def get_models_provenance(
        self, training_dataset_version: int | None = None
    ) -> explicit_provenance.Links:
        """Get the generated models using this feature view, based on explicit provenance.

        These models can be accessible or inaccessible.
        Explicit provenance does not track deleted generated model links, so deleted will always be empty.
        For inaccessible models, only a minimal information is returned.

        Parameters:
            training_dataset_version: Filter generated models based on the used training dataset version.

        Returns:
            Object containing the section of provenance graph requested or `None` if it does not exist.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._feature_view_engine._get_models_provenance(
            self, training_dataset_version=training_dataset_version
        )

    @public
    def delete_tag(self, name: str) -> None:
        """Delete a tag attached to a feature view.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # delete a tag
            feature_view.delete_tag('name_of_tag')
            ```

        Parameters:
            name: Name of the tag to be removed.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._feature_view_engine._delete_tag(self, name)

    @public
    def update_last_accessed_training_dataset(self, version: int) -> None:
        """Update the cached last accessed training dataset version.

        Parameters:
            version: The training dataset version to be cached as last accessed.
        """
        if self._last_accessed_training_dataset is not None:
            _logger.info(
                f"Provenance cached data - overwriting last accessed/created training dataset from {self._last_accessed_training_dataset} to {version}."
            )
        self._last_accessed_training_dataset = version

    @public
    @usage._method_logger
    def create_training_data(
        self,
        start_time: str | int | datetime | date | None = "",
        end_time: str | int | datetime | date | None = "",
        storage_connector: storage_connector.StorageConnector | None = None,
        location: str | None = "",
        description: str | None = "",
        extra_filter: filter.Filter | filter.Logic | None = None,
        data_format: str | None = "parquet",
        coalesce: bool | None = False,
        seed: int | None = None,
        statistics_config: StatisticsConfig | bool | dict | None = None,
        write_options: dict[Any, Any] | None = None,
        spine: SplineDataFrameTypes | None = None,
        transformation_context: dict[str, Any] = None,
        data_source: ds.DataSource | dict[str, Any] | None = None,
        tags: tag.Tag | dict[str, Any] | list[tag.Tag | dict[str, Any]] | None = None,
        lookback: FeatureGroupLookback | Lookback | dict[str, Any] | None = None,
        **kwargs,
    ) -> tuple[int, job.Job]:
        """Create the metadata for a training dataset and save the corresponding training data into `location`.

        The training data can be retrieved by calling `feature_view.get_training_data`.

        Example: Create training dataset
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # create a training dataset
            version, job = feature_view.create_training_data(
                description='Description of a dataset',
                data_format='csv',
                # async creation in order not to wait till finish of the job
                write_options={"wait_for_job": False}
            )
            ```

        Example: Create training data specifying date range with dates as strings
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            start_time = "2022-01-01 00:00:00"
            end_time = "2022-06-06 23:59:59"

            # create a training dataset
            version, job = feature_view.create_training_data(
                start_time=start_time,
                end_time=end_time,
                description='Description of a dataset',
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format='csv'
            )

            # When we want to read the training data, we need to supply the training data version returned by the create_training_data method:
            X_train, X_test, y_train, y_test = feature_view.get_training_data(version)
            ```

        Example: Create training data specifying date range with dates as datetime objects
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            from datetime import datetime
            date_format = "%Y-%m-%d %H:%M:%S"

            start_time = datetime.strptime("2022-01-01 00:00:00", date_format)
            end_time = datetime.strptime("2022-06-06 23:59:59", date_format)

            # create a training dataset
            version, job = feature_view.create_training_data(
                start_time=start_time,
                end_time=end_time,
                description='Description of a dataset',
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format='csv'
            )
            ```

        Example: Write training dataset to external storage
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get storage connector instance
            data_source = fs.get_data_source("test_data_source")

            # create a train-test split dataset
            version, job = feature_view.create_training_data(
                start_time=...,
                end_time=...,
                data_source=data_source,
                description=...,
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format=...
            )
            ```

        Info: Data Formats
            The feature store currently supports the following data formats for training datasets:

            1. tfrecord
            2. csv
            3. tsv
            4. parquet
            5. avro
            6. orc
            7. json

            Currently not supported petastorm, hdf5 and npy file formats.

        Warning: Spine Groups/Dataframes
            Spine groups and dataframes are currently only supported with the Spark engine and Spark dataframes.

        Parameters:
            start_time:
                Start event time for the training dataset query, inclusive.
                Strings should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`, or `%Y-%m-%d %H:%M:%S.%f`.
                Int, i.e., Unix Epoch should be in seconds.
            end_time:
                End event time for the training dataset query, exclusive.
                Strings should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`, or `%Y-%m-%d %H:%M:%S.%f`.
                Int, i.e., Unix Epoch should be in seconds.
            storage_connector:
                Storage connector defining the sink location for the training dataset, defaults to `None`, and materializes training dataset on HopsFS. **[DEPRECATED: Use `data_source` instead.]**
            location:
                Path to complement the sink storage connector with, e.g., if the storage connector points to an S3 bucket, this path can be used to define a sub-directory inside the bucket to place the training dataset.
                Defaults to `""`, saving the training dataset at the root defined by the storage connector. **[DEPRECATED: Use `data_source` instead.]**
            description:
                A string describing the contents of the training dataset to improve discoverability for Data Scientists.
            extra_filter:
                Additional filters to be attached to the training dataset.
                The filters will be also applied in `get_batch_data`.
            data_format: The data format used to save the training dataset.
            coalesce:
                If true the training dataset data will be coalesced into a single partition before writing.
                The resulting training dataset will be a single file per split.
            seed: Optionally, define a seed to create the random splits with, in order to guarantee reproducability.
            statistics_config:
                A configuration object, or a dictionary with keys:

                - `"enabled"` to generally enable descriptive statistics computation for
                this feature group,
                - `"correlations"` to turn on feature correlation computation, and
                - `"histograms"` to compute feature value frequencies.

                The values should be booleans indicating the setting.
                To fully turn off statistics computation pass `statistics_config=False`.
                Defaults to `None` and will compute only descriptive statistics.
            write_options:
                Additional options as key/value pairs to pass to the execution engine.

                For `spark` engine: Dictionary of read options for Spark.

                When using the `python` engine, write_options can contain the following entries:

                - key `use_spark` and value `True` to materialize training dataset with Spark instead of [Hopsworks Feature Query Service][arrowflight-server-with-duckdb].
                - key `spark` and value an object of type [hsfs.core.job_configuration.JobConfiguration][hsfs.core.job_configuration.JobConfiguration] to configure the Hopsworks Job used to compute the training dataset.
                - key `wait_for_job` and value `True` or `False` to configure whether or not to the save call should return only after the Hopsworks Job has finished.
                  By default it waits.

            spine:
                Spine dataframe with primary key, event time and label column to use for point in time join when fetching features.
                Defaults to `None` and is only required when feature view was created with spine group in the feature query.
                It is possible to directly pass a spine group instead of a dataframe to overwrite the left side of the feature join, however, the same features as in the original feature group that is being replaced need to be available in the spine group.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution.
            data_source: The data source specifying the location of the data. Overrides the storage_connector and location arguments when specified.
            tags: Tags to attach to the training dataset for better discoverability.
            lookback:
                Optional lookback window persisted with the training dataset so re-reading the same training-dataset version reconstructs the same per-join predicate.
                For one window across every feature group, pass a `FeatureGroupLookback` — e.g. `FeatureGroupLookback(key="PARTITION_KEY", start=date(2026, 5, 5), end=date(2026, 5, 17))` or its dict form `{"key": "PARTITION_KEY", "start": date(2026, 5, 5), "end": date(2026, 5, 17)}`.
                For different windows per feature group, pass a `Lookback` — e.g. `Lookback(default=FeatureGroupLookback(...), feature_group_lookbacks={"dim_a": FeatureGroupLookback(...)})` or its dict form `{"default": {...}, "feature_group_lookbacks": {"dim_a": {...}}}`.
                See [`FeatureGroupLookback`][hsfs.constructor.lookback.FeatureGroupLookback] and [`Lookback`][hsfs.constructor.lookback.Lookback] for accepted key values, validation rules, and per-FG key matching semantics.

        Returns:
            td_version: training dataset version
            Job: When using the `python` engine, the Hopsworks Job that was launched to create the training dataset.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        if not data_source:
            data_source = ds.DataSource(
                storage_connector=storage_connector, path=location
            )
        normalized_tags = tag.Tag._normalize(tags)

        td = training_dataset.TrainingDataset(
            name=self.name,
            version=None,
            event_start_time=start_time,
            event_end_time=end_time,
            description=description,
            data_format=data_format,
            data_source=data_source,
            featurestore_id=self._featurestore_id,
            splits={},
            seed=seed,
            statistics_config=statistics_config,
            coalesce=coalesce,
            extra_filter=extra_filter,
            tags=normalized_tags,
        )
        # td_job is used only if the python engine is used
        td, td_job = self._feature_view_engine._create_training_dataset(
            self,
            td,
            write_options or {},
            spine=spine,
            transformation_context=transformation_context,
            lookback=Lookback.from_user_input(lookback),
        )
        warnings.warn(
            f"Incremented version to `{td.version}`.",
            util.VersionWarning,
            stacklevel=1,
        )
        self.update_last_accessed_training_dataset(td.version)

        return td.version, td_job

    @public
    @usage._method_logger
    def create_train_test_split(
        self,
        test_size: float | None = None,
        train_start: str | int | datetime | date | None = "",
        train_end: str | int | datetime | date | None = "",
        test_start: str | int | datetime | date | None = "",
        test_end: str | int | datetime | date | None = "",
        storage_connector: storage_connector.StorageConnector | None = None,
        location: str | None = "",
        description: str | None = "",
        extra_filter: filter.Filter | filter.Logic | None = None,
        data_format: str | None = "parquet",
        coalesce: bool | None = False,
        seed: int | None = None,
        statistics_config: StatisticsConfig | bool | dict | None = None,
        write_options: dict[Any, Any] | None = None,
        spine: SplineDataFrameTypes | None = None,
        transformation_context: dict[str, Any] = None,
        data_source: ds.DataSource | dict[str, Any] | None = None,
        tags: tag.Tag | dict[str, Any] | list[tag.Tag | dict[str, Any]] | None = None,
        lookback: FeatureGroupLookback | Lookback | dict[str, Any] | None = None,
        **kwargs,
    ) -> tuple[int, job.Job]:
        # TODO: Convert the docstrings from this point on:
        """Create the metadata for a training dataset and save the corresponding training data into `location`.

        The training data is split into train and test set at random or according to time ranges.
        The training data can be retrieved by calling `feature_view.get_train_test_split`.

        Example: Create random splits
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # create a train-test split dataset
            version, job = feature_view.create_train_test_split(
                test_size=0.2,
                description='Description of a dataset',
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format='csv'
            )
            ```

        Example: Create time series splits by specifying date as string
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            train_start = "2022-01-01 00:00:00"
            train_end = "2022-06-06 23:59:59"
            test_start = "2022-06-07 00:00:00"
            test_end = "2022-12-25 23:59:59"

            # create a train-test split dataset
            version, job = feature_view.create_train_test_split(
                train_start=train_start,
                train_end=train_end,
                test_start=test_start,
                test_end=test_end,
                description='Description of a dataset',
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format='csv'
            )
            ```

        Example: Create time series splits by specifying date as datetime object
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            from datetime import datetime
            date_format = "%Y-%m-%d %H:%M:%S"

            train_start = datetime.strptime("2022-01-01 00:00:00", date_format)
            train_end = datetime.strptime("2022-06-06 23:59:59", date_format)
            test_start = datetime.strptime("2022-06-07 00:00:00", date_format)
            test_end = datetime.strptime("2022-12-25 23:59:59" , date_format)

            # create a train-test split dataset
            version, job = feature_view.create_train_test_split(
                train_start=train_start,
                train_end=train_end,
                test_start=test_start,
                test_end=test_end,
                description='Description of a dataset',
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format='csv'
            )
            ```

        Example: Write training dataset to external storage
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get storage connector instance
            data_source = fs.get_data_source("test_data_source")

            # create a train-test split dataset
            version, job = feature_view.create_train_test_split(
                train_start=...,
                train_end=...,
                test_start=...,
                test_end=...,
                data_source=data_source,
                description=...,
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format=...
            )
            ```

        Info: Data Formats
            The feature store currently supports the following data formats for
            training datasets:

            1. tfrecord
            2. csv
            3. tsv
            4. parquet
            5. avro
            6. orc
            7. json

            Currently not supported petastorm, hdf5 and npy file formats.

        Warning: Warning, the following code will fail because category column contains sparse values and training dataset may not have all values available in test split.
            ```python
            import pandas as pd

            df = pd.DataFrame({
                'category_col':['category_a','category_b','category_c','category_d'],
                'numeric_col': [40,10,60,40]
            })

            feature_group = fs.get_or_create_feature_group(
                name='feature_group_name',
                version=1,
                primary_key=['category_col']
            )

            feature_group.insert(df)

            label_encoder = fs.get_transformation_function(name='label_encoder')

            feature_view = fs.create_feature_view(
                name='feature_view_name',
                query=feature_group.select_all(),
                transformation_functions={'category_col':label_encoder}
            )

            feature_view.create_train_test_split(
                test_size=0.5
            )
            # Output: KeyError: 'category_c'
            ```

        Warning: Spine Groups/Dataframes
            Spine groups and dataframes are currently only supported with the Spark engine and
            Spark dataframes.

        Parameters:
            test_size: size of test set.
            train_start: Start event time for the train split query, inclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            train_end: End event time for the train split query, exclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            test_start: Start event time for the test split query, inclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            test_end: End event time for the test split query, exclusive. Strings should
                be  formatted in one of the following ormats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            storage_connector: Storage connector defining the sink location for the
                training dataset, defaults to `None`, and materializes training dataset
                on HopsFS. **[DEPRECATED: Use `data_source` instead.]**
            location: Path to complement the sink storage connector with, e.g if the
                storage connector points to an S3 bucket, this path can be used to
                define a sub-directory inside the bucket to place the training dataset.
                Defaults to `""`, saving the training dataset at the root defined by the
                storage connector. **[DEPRECATED: Use `data_source` instead.]**
            description: A string describing the contents of the training dataset to
                improve discoverability for Data Scientists, defaults to empty string
                `""`.
            extra_filter: Additional filters to be attached to the training dataset.
                The filters will be also applied in `get_batch_data`.
            data_format: The data format used to save the training dataset,
                defaults to `"parquet"`-format.
            coalesce: If true the training dataset data will be coalesced into
                a single partition before writing. The resulting training dataset
                will be a single file per split. Default False.
            seed: Optionally, define a seed to create the random splits with, in order
                to guarantee reproducability, defaults to `None`.
            statistics_config: A configuration object, or a dictionary with keys
                "`enabled`" to generally enable descriptive statistics computation for
                this feature group, `"correlations`" to turn on feature correlation
                computation and `"histograms"` to compute feature value frequencies. The
                values should be booleans indicating the setting. To fully turn off
                statistics computation pass `statistics_config=False`. Defaults to
                `None` and will compute only descriptive statistics.
            write_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                When using the `python` engine, write_options can contain the
                following entries:
                * key `use_spark` and value `True` to materialize training dataset
                  with Spark instead of [Hopsworks Feature Query Service][arrowflight-server-with-duckdb].
                * key `spark` and value an object of type
                [hsfs.core.job_configuration.JobConfiguration][hsfs.core.job_configuration.JobConfiguration]
                  to configure the Hopsworks Job used to compute the training dataset.
                * key `wait_for_job` and value `True` or `False` to configure
                  whether or not to the save call should return only
                  after the Hopsworks Job has finished. By default it waits.
            spine: Spine dataframe with primary key, event time and
                label column to use for point in time join when fetching features. Defaults to `None` and is only required
                when feature view was created with spine group in the feature query.
                It is possible to directly pass a spine group instead of a dataframe to overwrite the left side of the
                feature join, however, the same features as in the original feature group that is being replaced need to
                be available in the spine group.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution. If no context variables are provided, this parameter defaults to `None`.
            data_source: The data source specifying the location of the data. Overrides the storage_connector and location arguments when specified.
            tags: Tags to attach to the training dataset for better discoverability.
            lookback:
                Optional lookback window persisted with the training dataset and applied to all splits.
                For one window across every feature group, pass a `FeatureGroupLookback` — e.g. `FeatureGroupLookback(key="PARTITION_KEY", start=date(2026, 5, 5), end=date(2026, 5, 17))` or its dict form `{"key": "PARTITION_KEY", "start": date(2026, 5, 5), "end": date(2026, 5, 17)}`.
                For different windows per feature group, pass a `Lookback` — e.g. `Lookback(default=FeatureGroupLookback(...), feature_group_lookbacks={"dim_a": FeatureGroupLookback(...)})` or its dict form `{"default": {...}, "feature_group_lookbacks": {"dim_a": {...}}}`.
                See [`FeatureGroupLookback`][hsfs.constructor.lookback.FeatureGroupLookback] and [`Lookback`][hsfs.constructor.lookback.Lookback] for accepted key values, validation rules, and per-FG key matching semantics.

        Returns:
            td_version: The version of the created training dataset.
            Job: When using the `python` engine, the Hopsworks Job that was launched to create the training dataset.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        self._validate_train_test_split(
            test_size=test_size, train_end=train_end, test_start=test_start
        )
        if not data_source:
            data_source = ds.DataSource(
                storage_connector=storage_connector, path=location
            )
        normalized_tags = tag.Tag._normalize(tags)

        td = training_dataset.TrainingDataset(
            name=self.name,
            version=None,
            test_size=test_size,
            time_split_size=2,
            train_start=train_start,
            train_end=train_end,
            test_start=test_start,
            test_end=test_end,
            description=description,
            data_format=data_format,
            data_source=data_source,
            featurestore_id=self._featurestore_id,
            splits={},
            seed=seed,
            statistics_config=statistics_config,
            coalesce=coalesce,
            extra_filter=extra_filter,
            tags=normalized_tags,
        )
        # td_job is used only if the python engine is used
        td, td_job = self._feature_view_engine._create_training_dataset(
            self,
            td,
            write_options or {},
            spine=spine,
            transformation_context=transformation_context,
            lookback=Lookback.from_user_input(lookback),
        )
        warnings.warn(
            f"Incremented version to `{td.version}`.",
            util.VersionWarning,
            stacklevel=1,
        )
        self.update_last_accessed_training_dataset(td.version)
        return td.version, td_job

    @public
    @usage._method_logger
    def create_train_validation_test_split(
        self,
        validation_size: float | None = None,
        test_size: float | None = None,
        train_start: str | int | datetime | date | None = "",
        train_end: str | int | datetime | date | None = "",
        validation_start: str | int | datetime | date | None = "",
        validation_end: str | int | datetime | date | None = "",
        test_start: str | int | datetime | date | None = "",
        test_end: str | int | datetime | date | None = "",
        storage_connector: storage_connector.StorageConnector | None = None,
        location: str | None = "",
        description: str | None = "",
        extra_filter: filter.Filter | filter.Logic | None = None,
        data_format: str | None = "parquet",
        coalesce: bool | None = False,
        seed: int | None = None,
        statistics_config: StatisticsConfig | bool | dict | None = None,
        write_options: dict[Any, Any] | None = None,
        spine: SplineDataFrameTypes | None = None,
        transformation_context: dict[str, Any] = None,
        data_source: ds.DataSource | dict[str, Any] | None = None,
        tags: tag.Tag | dict[str, Any] | list[tag.Tag | dict[str, Any]] | None = None,
        lookback: FeatureGroupLookback | Lookback | dict[str, Any] | None = None,
        **kwargs,
    ) -> tuple[int, job.Job]:
        """Create the metadata for a training dataset and save the corresponding training data into `location`.

        The training data is split into train, validation, and test set at random or according to time range.
        The training data can be retrieved by calling `feature_view.get_train_validation_test_split`.

        Example: Create random splits
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # create a train-validation-test split dataset
            version, job = feature_view.create_train_validation_test_split(
                validation_size=0.3,
                test_size=0.2,
                description='Description of a dataset',
                data_format='csv'
            )
            ```

        Example: Create time series splits by specifying date as string
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            train_start = "2022-01-01 00:00:00"
            train_end = "2022-06-01 23:59:59"
            validation_start = "2022-06-02 00:00:00"
            validation_end = "2022-07-01 23:59:59"
            test_start = "2022-07-02 00:00:00"
            test_end = "2022-08-01 23:59:59"

            # create a train-validation-test split dataset
            version, job = feature_view.create_train_validation_test_split(
                train_start=train_start,
                train_end=train_end,
                validation_start=validation_start,
                validation_end=validation_end,
                test_start=test_start,
                test_end=test_end,
                description='Description of a dataset',
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format='csv'
            )
            ```

        Example: Create time series splits by specifying date as datetime object
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            from datetime import datetime
            date_format = "%Y-%m-%d %H:%M:%S"

            train_start = datetime.strptime("2022-01-01 00:00:00", date_format)
            train_end = datetime.strptime("2022-06-06 23:59:59", date_format)
            validation_start = datetime.strptime("2022-06-02 00:00:00", date_format)
            validation_end = datetime.strptime("2022-07-01 23:59:59", date_format)
            test_start = datetime.strptime("2022-06-07 00:00:00", date_format)
            test_end = datetime.strptime("2022-12-25 23:59:59", date_format)

            # create a train-validation-test split dataset
            version, job = feature_view.create_train_validation_test_split(
                train_start=train_start,
                train_end=train_end,
                validation_start=validation_start,
                validation_end=validation_end,
                test_start=test_start,
                test_end=test_end,
                description='Description of a dataset',
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format='csv'
            )
            ```

        Example: Write training dataset to external storage
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get storage connector instance
            data_source = fs.get_data_source("test_data_source")

            # create a train-validation-test split dataset
            version, job = feature_view.create_train_validation_test_split(
                train_start=...,
                train_end=...,
                validation_start=...,
                validation_end=...,
                test_start=...,
                test_end=...,
                description=...,
                data_source=data_source,
                # you can have different data formats such as csv, tsv, tfrecord, parquet and others
                data_format=...
            )
            ```

        Info: Data Formats
            The feature store currently supports the following data formats for
            training datasets:

            1. tfrecord
            2. csv
            3. tsv
            4. parquet
            5. avro
            6. orc
            7. json

            Currently not supported petastorm, hdf5 and npy file formats.

        Warning: Spine Groups/Dataframes
            Spine groups and dataframes are currently only supported with the Spark engine and
            Spark dataframes.

        Parameters:
            validation_size: size of validation set.
            test_size: size of test set.
            train_start: Start event time for the train split query, inclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            train_end: End event time for the train split query, exclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            validation_start: Start event time for the validation split query, inclusive. Strings
                should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            validation_end: End event time for the validation split query, exclusive. Strings
                should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            test_start: Start event time for the test split query, inclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            test_end: End event time for the test split query, exclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            storage_connector: Storage connector defining the sink location for the
                training dataset, defaults to `None`, and materializes training dataset
                on HopsFS. **[DEPRECATED: Use `data_source` instead.]**
            location: Path to complement the sink storage connector with, e.g if the
                storage connector points to an S3 bucket, this path can be used to
                define a sub-directory inside the bucket to place the training dataset.
                Defaults to `""`, saving the training dataset at the root defined by the
                storage connector. **[DEPRECATED: Use `data_source` instead.]**
            description: A string describing the contents of the training dataset to
                improve discoverability for Data Scientists, defaults to empty string
                `""`.
            extra_filter: Additional filters to be attached to the training dataset.
                The filters will be also applied in `get_batch_data`.
            data_format: The data format used to save the training dataset,
                defaults to `"parquet"`-format.
            coalesce: If true the training dataset data will be coalesced into
                a single partition before writing. The resulting training dataset
                will be a single file per split. Default False.
            seed: Optionally, define a seed to create the random splits with, in order
                to guarantee reproducability, defaults to `None`.
            statistics_config: A configuration object, or a dictionary with keys
                "`enabled`" to generally enable descriptive statistics computation for
                this feature group, `"correlations`" to turn on feature correlation
                computation and `"histograms"` to compute feature value frequencies. The
                values should be booleans indicating the setting. To fully turn off
                statistics computation pass `statistics_config=False`. Defaults to
                `None` and will compute only descriptive statistics.
            write_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                When using the `python` engine, write_options can contain the
                following entries:
                * key `use_spark` and value `True` to materialize training dataset
                  with Spark instead of [Hopsworks Feature Query Service][arrowflight-server-with-duckdb].
                * key `spark` and value an object of type
                [hsfs.core.job_configuration.JobConfiguration][hsfs.core.job_configuration.JobConfiguration]
                  to configure the Hopsworks Job used to compute the training dataset.
                * key `wait_for_job` and value `True` or `False` to configure
                  whether or not to the save call should return only
                  after the Hopsworks Job has finished. By default it waits.
            spine: Spine dataframe with primary key, event time and
                label column to use for point in time join when fetching features. Defaults to `None` and is only required
                when feature view was created with spine group in the feature query.
                It is possible to directly pass a spine group instead of a dataframe to overwrite the left side of the
                feature join, however, the same features as in the original feature group that is being replaced need to
                be available in the spine group.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution. If no context variables are provided, this parameter defaults to `None`.
            data_source: The data source specifying the location of the data. Overrides the storage_connector and location arguments when specified.
            tags: Tags to attach to the training dataset for better discoverability.
            lookback:
                Optional lookback window persisted with the training dataset and applied to all splits.
                For one window across every feature group, pass a `FeatureGroupLookback` — e.g. `FeatureGroupLookback(key="PARTITION_KEY", start=date(2026, 5, 5), end=date(2026, 5, 17))` or its dict form `{"key": "PARTITION_KEY", "start": date(2026, 5, 5), "end": date(2026, 5, 17)}`.
                For different windows per feature group, pass a `Lookback` — e.g. `Lookback(default=FeatureGroupLookback(...), feature_group_lookbacks={"dim_a": FeatureGroupLookback(...)})` or its dict form `{"default": {...}, "feature_group_lookbacks": {"dim_a": {...}}}`.
                See [`FeatureGroupLookback`][hsfs.constructor.lookback.FeatureGroupLookback] and [`Lookback`][hsfs.constructor.lookback.Lookback] for accepted key values, validation rules, and per-FG key matching semantics.

        Returns:
            td_version: The training dataset version.
            job: When using the `python` engine, it returns the Hopsworks Job that was launched to create the training dataset.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        self._validate_train_validation_test_split(
            validation_size=validation_size,
            test_size=test_size,
            train_end=train_end,
            validation_start=validation_start,
            validation_end=validation_end,
            test_start=test_start,
        )
        if not data_source:
            data_source = ds.DataSource(
                storage_connector=storage_connector, path=location
            )
        normalized_tags = tag.Tag._normalize(tags)

        td = training_dataset.TrainingDataset(
            name=self.name,
            version=None,
            validation_size=validation_size,
            test_size=test_size,
            time_split_size=3,
            train_start=train_start,
            train_end=train_end,
            validation_start=validation_start,
            validation_end=validation_end,
            test_start=test_start,
            test_end=test_end,
            description=description,
            data_format=data_format,
            data_source=data_source,
            featurestore_id=self._featurestore_id,
            splits={},
            seed=seed,
            statistics_config=statistics_config,
            coalesce=coalesce,
            extra_filter=extra_filter,
            tags=normalized_tags,
        )
        # td_job is used only if the python engine is used
        td, td_job = self._feature_view_engine._create_training_dataset(
            self,
            td,
            write_options or {},
            spine=spine,
            transformation_context=transformation_context,
            lookback=Lookback.from_user_input(lookback),
        )
        warnings.warn(
            f"Incremented version to `{td.version}`.",
            util.VersionWarning,
            stacklevel=1,
        )
        self.update_last_accessed_training_dataset(td.version)

        return td.version, td_job

    @public
    @usage._method_logger
    def recreate_training_dataset(
        self,
        training_dataset_version: int,
        statistics_config: StatisticsConfig | bool | dict | None = None,
        write_options: dict[Any, Any] | None = None,
        spine: SplineDataFrameTypes | None = None,
        transformation_context: dict[str, Any] = None,
    ) -> job.Job:
        """Recreate a training dataset.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # recreate a training dataset that has been deleted
            feature_view.recreate_training_dataset(training_dataset_version=1)
            ```

        Info:
            If a materialised training data has deleted. Use `recreate_training_dataset()` to
            recreate the training data.

        Warning: Spine Groups/Dataframes
            Spine groups and dataframes are currently only supported with the Spark engine and
            Spark dataframes.

        Parameters:
            training_dataset_version: training dataset version
            statistics_config: A configuration object, or a dictionary with keys
                "`enabled`" to generally enable descriptive statistics computation for
                this feature group, `"correlations`" to turn on feature correlation
                computation and `"histograms"` to compute feature value frequencies. The
                values should be booleans indicating the setting. To fully turn off
                statistics computation pass `statistics_config=False`. Defaults to
                `None` and will compute only descriptive statistics.
            write_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                When using the `python` engine, write_options can contain the
                following entries:
                * key `use_spark` and value `True` to materialize training dataset
                  with Spark instead of [Hopsworks Feature Query Service][arrowflight-server-with-duckdb].
                * key `spark` and value an object of type
                [hsfs.core.job_configuration.JobConfiguration][hsfs.core.job_configuration.JobConfiguration]
                  to configure the Hopsworks Job used to compute the training dataset.
                * key `wait_for_job` and value `True` or `False` to configure
                  whether or not to the save call should return only
                  after the Hopsworks Job has finished. By default it waits.
            spine: Spine dataframe with primary key, event time and
                label column to use for point in time join when fetching features. Defaults to `None` and is only required
                when feature view was created with spine group in the feature query.
                It is possible to directly pass a spine group instead of a dataframe to overwrite the left side of the
                feature join, however, the same features as in the original feature group that is being replaced need to
                be available in the spine group.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution. If no context variables are provided, this parameter defaults to `None`.

        Returns:
            When using the `python` engine, it returns the Hopsworks Job that was launched to create the training dataset.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        td, td_job = self._feature_view_engine._recreate_training_dataset(
            self,
            training_dataset_version=training_dataset_version,
            statistics_config=statistics_config,
            user_write_options=write_options or {},
            spine=spine,
            transformation_context=transformation_context,
        )
        self.update_last_accessed_training_dataset(td.version)

        return td_job

    @public
    @usage._method_logger
    def training_data(
        self,
        start_time: str | int | datetime | date | None = None,
        end_time: str | int | datetime | date | None = None,
        description: str | None = "",
        extra_filter: filter.Filter | filter.Logic | None = None,
        statistics_config: StatisticsConfig | bool | dict | None = None,
        read_options: dict[Any, Any] | None = None,
        spine: SplineDataFrameTypes | None = None,
        primary_key: bool = False,
        event_time: bool = False,
        training_helper_columns: bool = False,
        dataframe_type: str | None = "default",
        transformation_context: dict[str, Any] = None,
        lookback: FeatureGroupLookback | Lookback | dict[str, Any] | None = None,
        n_processes: int | None = None,
        tags: tag.Tag | dict[str, Any] | list[tag.Tag | dict[str, Any]] | None = None,
        **kwargs,
    ) -> tuple[
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes | None,  # optional label DataFrame
    ]:
        """Create the metadata for a training dataset and get the corresponding training data from the offline feature store.

        This returns the training data in memory and does not materialise data in storage.
        The training data can be recreated by calling `feature_view.get_training_data` with the metadata created.

        Example: Create random splits
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get training data
            features_df, labels_df  = feature_view.training_data(
                description='Descriprion of a dataset',
            )
            ```

        Example: Create time-series based splits
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up a date
            start_time = "2022-05-01 00:00:00"
            end_time = "2022-06-04 23:59:59"
            # you can also pass dates as datetime objects

            # get training data
            features_df, labels_df = feature_view.training_data(
                start_time=start_time,
                end_time=end_time,
                description='Description of a dataset'
            )
            ```

        Warning: Spine Groups/Dataframes
            Spine groups and dataframes are currently only supported with the Spark engine and
            Spark dataframes.

        Parameters:
            start_time:
                Start event time for the training dataset query, inclusive.
                Strings should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`, or `%Y-%m-%d %H:%M:%S.%f`.
                Int, i.e Unix Epoch should be in seconds.
            end_time:
                End event time for the training dataset query, exclusive.
                Strings should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`, or `%Y-%m-%d %H:%M:%S.%f`.
                Int, i.e Unix Epoch should be in seconds.
            description:
                A string describing the contents of the training dataset to improve discoverability for Data Scientists, defaults to empty string `""`.
            extra_filter:
                Additional filters to be attached to the training dataset.
                The filters will be also applied in `get_batch_data`.
            statistics_config: A configuration object, or a dictionary with keys
                "`enabled`" to generally enable descriptive statistics computation for
                this feature group, `"correlations`" to turn on feature correlation
                computation and `"histograms"` to compute feature value frequencies. The
                values should be booleans indicating the setting. To fully turn off
                statistics computation pass `statistics_config=False`. Defaults to
                `None` and will compute only descriptive statistics.
            read_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                When using the `python` engine, read_options can contain the
                following entries:
                * key `"arrow_flight_config"` to pass a dictionary of arrow flight configurations.
                  For example: `{"arrow_flight_config": {"timeout": 900}}`.
                * key `spark` and value an object of type
                  [hsfs.core.job_configuration.JobConfiguration][hsfs.core.job_configuration.JobConfiguration]
                  to configure the Hopsworks Job used to compute the training dataset.
            spine: Spine dataframe with primary key, event time and
                label column to use for point in time join when fetching features. Defaults to `None` and is only required
                when feature view was created with spine group in the feature query.
                It is possible to directly pass a spine group instead of a dataframe to overwrite the left side of the
                feature join, however, the same features as in the original feature group that is being replaced need to
                be available in the spine group.
            primary_key: whether to include primary key features or not.  Defaults to `False`, no primary key
                features.
            event_time: whether to include event time feature or not.  Defaults to `False`, no event time feature.
            training_helper_columns: whether to include training helper columns or not.
                Training helper columns are a list of feature names in the feature view, defined during its creation,
                that are not the part of the model schema itself but can be used during training as a helper for
                extra information. If training helper columns were not defined in the feature view
                then`training_helper_columns=True` will not have any effect. Defaults to `False`, no training helper
                columns.
            dataframe_type: str, optional. The type of the returned dataframe.
                Possible values are `"default"`, `"spark"`,`"pandas"`, `"polars"`, `"numpy"` or `"python"`.
                Defaults to "default", which maps to Spark dataframe for the Spark Engine and Pandas dataframe for the Python engine.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution. If no context variables are provided, this parameter defaults to `None`.
            lookback:
                Optional lookback window applied to the PIT join before reading; bounds the rows each joined feature group contributes so the engine can prune partitions before opening files.
                For one window across every feature group, pass a `FeatureGroupLookback` — e.g. `FeatureGroupLookback(key="PARTITION_KEY", start=date(2026, 5, 5), end=date(2026, 5, 17))` or its dict form `{"key": "PARTITION_KEY", "start": date(2026, 5, 5), "end": date(2026, 5, 17)}`.
                For different windows per feature group, pass a `Lookback` — e.g. `Lookback(default=FeatureGroupLookback(...), feature_group_lookbacks={"dim_a": FeatureGroupLookback(...)})` or its dict form `{"default": {...}, "feature_group_lookbacks": {"dim_a": {...}}}`.
                See [`FeatureGroupLookback`][hsfs.constructor.lookback.FeatureGroupLookback] and [`Lookback`][hsfs.constructor.lookback.Lookback] for accepted key values, validation rules, and per-FG key matching semantics.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.
            tags: Tags to attach to the training dataset for better discoverability.

        Returns:
            (X, y): Tuple of dataframe of features and labels. If there are no labels, y returns `None`.
        """
        normalized_tags = tag.Tag._normalize(tags)

        td = training_dataset.TrainingDataset(
            name=self.name,
            version=None,
            splits={},
            event_start_time=start_time,
            event_end_time=end_time,
            description=description,
            data_source=None,
            featurestore_id=self._featurestore_id,
            data_format="tsv",
            statistics_config=statistics_config,
            training_dataset_type=training_dataset.TrainingDataset.IN_MEMORY,
            extra_filter=extra_filter,
            lookback=Lookback.from_user_input(lookback),
            tags=normalized_tags,
        )
        td, df = self._feature_view_engine._get_training_data(
            self,
            read_options,
            training_dataset_obj=td,
            spine=spine,
            primary_keys=kwargs.get("primary_keys") or primary_key,
            event_time=event_time,
            training_helper_columns=training_helper_columns,
            dataframe_type=dataframe_type,
            transformation_context=transformation_context,
            n_processes=n_processes,
        )
        warnings.warn(
            f"Incremented version to `{td.version}`.",
            util.VersionWarning,
            stacklevel=1,
        )
        self.update_last_accessed_training_dataset(td.version)
        return df

    @public
    @usage._method_logger
    def train_test_split(
        self,
        test_size: float | None = None,
        train_start: str | int | datetime | date | None = "",
        train_end: str | int | datetime | date | None = "",
        test_start: str | int | datetime | date | None = "",
        test_end: str | int | datetime | date | None = "",
        description: str | None = "",
        extra_filter: filter.Filter | filter.Logic | None = None,
        statistics_config: StatisticsConfig | bool | dict | None = None,
        read_options: dict[Any, Any] | None = None,
        spine: SplineDataFrameTypes | None = None,
        primary_key: bool = False,
        event_time: bool = False,
        training_helper_columns: bool = False,
        dataframe_type: str | None = "default",
        transformation_context: dict[str, Any] = None,
        lookback: FeatureGroupLookback | Lookback | dict[str, Any] | None = None,
        n_processes: int | None = None,
        tags: tag.Tag | dict[str, Any] | list[tag.Tag | dict[str, Any]] | None = None,
        **kwargs,
    ) -> tuple[
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes | None,
        TrainingDatasetDataFrameTypes | None,
    ]:
        """Create the metadata for a training dataset and get the corresponding training data from the offline feature store.

        This returns the training data in memory and does not materialise data in storage.
        The training data is split into train and test set at random or according to time ranges.
        The training data can be recreated by calling `feature_view.get_train_test_split` with the metadata created.

        Example: Create random train/test splits
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get training data
            X_train, X_test, y_train, y_test = feature_view.train_test_split(
                test_size=0.2
            )
            ```

        Example: Create time-series train/test splits
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            train_start = "2022-05-01 00:00:00"
            train_end = "2022-06-04 23:59:59"
            test_start = "2022-07-01 00:00:00"
            test_end= "2022-08-04 23:59:59"
            # you can also pass dates as datetime objects

            # get training data
            X_train, X_test, y_train, y_test = feature_view.train_test_split(
                train_start=train_start,
                train_end=train_end,
                test_start=test_start,
                test_end=test_end,
                description='Description of a dataset'
            )
            ```

        Warning: Spine Groups/Dataframes
            Spine groups and dataframes are currently only supported with the Spark engine and
            Spark dataframes.

        Parameters:
            test_size: size of test set. Should be between 0 and 1.
            train_start: Start event time for the train split query, inclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`.
            train_end: End event time for the train split query, exclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            test_start: Start event time for the test split query, inclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            test_end: End event time for the test split query, exclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            description: A string describing the contents of the training dataset to
                improve discoverability for Data Scientists, defaults to empty string
                `""`.
            extra_filter: Additional filters to be attached to the training dataset.
                The filters will be also applied in `get_batch_data`.
            statistics_config: A configuration object, or a dictionary with keys
                "`enabled`" to generally enable descriptive statistics computation for
                this feature group, `"correlations`" to turn on feature correlation
                computation and `"histograms"` to compute feature value frequencies. The
                values should be booleans indicating the setting. To fully turn off
                statistics computation pass `statistics_config=False`. Defaults to
                `None` and will compute only descriptive statistics.
            read_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                When using the `python` engine, read_options can contain the
                following entries:
                * key `"arrow_flight_config"` to pass a dictionary of arrow flight configurations.
                  For example: `{"arrow_flight_config": {"timeout": 900}}`
                * key `spark` and value an object of type
                  [hsfs.core.job_configuration.JobConfiguration][hsfs.core.job_configuration.JobConfiguration]
                  to configure the Hopsworks Job used to compute the training dataset.
            spine: Spine dataframe with primary key, event time and
                label column to use for point in time join when fetching features. Defaults to `None` and is only required
                when feature view was created with spine group in the feature query.
                It is possible to directly pass a spine group instead of a dataframe to overwrite the left side of the
                feature join, however, the same features as in the original feature group that is being replaced need to
                be available in the spine group.
            primary_key: whether to include primary key features or not.  Defaults to `False`, no primary key
                features.
            event_time: whether to include event time feature or not.  Defaults to `False`, no event time feature.
            training_helper_columns: whether to include training helper columns or not.
                Training helper columns are a list of feature names in the feature view, defined during its creation,
                that are not the part of the model schema itself but can be used during training as a helper for
                extra information. If training helper columns were not defined in the feature view
                then`training_helper_columns=True` will not have any effect. Defaults to `False`, no training helper
                columns.
            dataframe_type: str, optional. The type of the returned dataframe.
                Possible values are `"default"`, `"spark"`,`"pandas"`, `"polars"`, `"numpy"` or `"python"`.
                Defaults to "default", which maps to Spark dataframe for the Spark Engine and Pandas dataframe for the Python engine.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution. If no context variables are provided, this parameter defaults to `None`.
            lookback:
                Optional lookback window applied to the PIT join before reading; bounds the rows each joined feature group contributes so the engine can prune partitions before opening files. The same window applies to both the train and test splits.
                For one window across every feature group, pass a `FeatureGroupLookback` — e.g. `FeatureGroupLookback(key="PARTITION_KEY", start=date(2026, 5, 5), end=date(2026, 5, 17))` or its dict form `{"key": "PARTITION_KEY", "start": date(2026, 5, 5), "end": date(2026, 5, 17)}`.
                For different windows per feature group, pass a `Lookback` — e.g. `Lookback(default=FeatureGroupLookback(...), feature_group_lookbacks={"dim_a": FeatureGroupLookback(...)})` or its dict form `{"default": {...}, "feature_group_lookbacks": {"dim_a": {...}}}`.
                See [`FeatureGroupLookback`][hsfs.constructor.lookback.FeatureGroupLookback] and [`Lookback`][hsfs.constructor.lookback.Lookback] for accepted key values, validation rules, and per-FG key matching semantics.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.
            tags: Tags to attach to the training dataset for better discoverability.

        Returns:
            (X_train, X_test, y_train, y_test):
                Tuple of dataframe of features and labels
        """
        self._validate_train_test_split(
            test_size=test_size, train_end=train_end, test_start=test_start
        )
        normalized_tags = tag.Tag._normalize(tags)

        td = training_dataset.TrainingDataset(
            name=self.name,
            version=None,
            splits={},
            test_size=test_size,
            train_start=train_start,
            train_end=train_end,
            test_start=test_start,
            test_end=test_end,
            time_split_size=2,
            description=description,
            data_source=None,
            featurestore_id=self._featurestore_id,
            data_format="tsv",
            statistics_config=statistics_config,
            training_dataset_type=training_dataset.TrainingDataset.IN_MEMORY,
            extra_filter=extra_filter,
            lookback=Lookback.from_user_input(lookback),
            tags=normalized_tags,
        )
        td, df = self._feature_view_engine._get_training_data(
            self,
            read_options,
            training_dataset_obj=td,
            splits=[TrainingDatasetSplit.TRAIN, TrainingDatasetSplit.TEST],
            spine=spine,
            primary_keys=kwargs.get("primary_keys") or primary_key,
            event_time=event_time,
            training_helper_columns=training_helper_columns,
            dataframe_type=dataframe_type,
            transformation_context=transformation_context,
            n_processes=n_processes,
        )
        warnings.warn(
            f"Incremented version to `{td.version}`.",
            util.VersionWarning,
            stacklevel=1,
        )
        self.update_last_accessed_training_dataset(td.version)
        return df

    @staticmethod
    def _validate_train_test_split(
        test_size: float | None,
        train_end: str | int | datetime | date | None,
        test_start: str | int | datetime | date | None,
    ) -> None:
        if not ((test_size and 0 < test_size < 1) or (train_end or test_start)):
            raise ValueError(
                "Invalid split input."
                " You should specify either `test_size` or (`train_end` or `test_start`)."
                " `test_size` should be between 0 and 1 if specified."
            )

    @public
    @usage._method_logger
    def train_validation_test_split(
        self,
        validation_size: float | None = None,
        test_size: float | None = None,
        train_start: str | int | datetime | date | None = "",
        train_end: str | int | datetime | date | None = "",
        validation_start: str | int | datetime | date | None = "",
        validation_end: str | int | datetime | date | None = "",
        test_start: str | int | datetime | date | None = "",
        test_end: str | int | datetime | date | None = "",
        description: str | None = "",
        extra_filter: filter.Filter | filter.Logic | None = None,
        statistics_config: StatisticsConfig | bool | dict | None = None,
        read_options: dict[Any, Any] | None = None,
        spine: SplineDataFrameTypes | None = None,
        primary_key: bool = False,
        event_time: bool = False,
        training_helper_columns: bool = False,
        dataframe_type: str | None = "default",
        transformation_context: dict[str, Any] = None,
        lookback: FeatureGroupLookback | Lookback | dict[str, Any] | None = None,
        n_processes: int | None = None,
        tags: tag.Tag | dict[str, Any] | list[tag.Tag | dict[str, Any]] | None = None,
        **kwargs,
    ) -> tuple[
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes | None,
        TrainingDatasetDataFrameTypes | None,
        TrainingDatasetDataFrameTypes | None,
    ]:
        """Create the metadata for a training dataset and get the corresponding training data from the offline feature store.

        This returns the training data in memory and does not materialise data in storage.
        The training data is split into train, validation, and test set at random or according to time ranges.
        The training data can be recreated by calling `feature_view.get_train_validation_test_split` with the metadata created.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get training data
            X_train, X_val, X_test, y_train, y_val, y_test = feature_view.train_validation_test_split(
                validation_size=0.3,
                test_size=0.2
            )
            ```

        Example: Time Series split
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # set up dates
            start_time_train = '2017-01-01 00:00:01'
            end_time_train = '2018-02-01 23:59:59'

            start_time_val = '2018-02-02 23:59:59'
            end_time_val = '2019-02-01 23:59:59'

            start_time_test = '2019-02-02 23:59:59'
            end_time_test = '2020-02-01 23:59:59'
            # you can also pass dates as datetime objects

            # get training data
            X_train, X_val, X_test, y_train, y_val, y_test = feature_view.train_validation_test_split(
                train_start=start_time_train,
                train_end=end_time_train,
                validation_start=start_time_val,
                validation_end=end_time_val,
                test_start=start_time_test,
                test_end=end_time_test
            )
            ```

        Warning: Spine Groups/Dataframes
            Spine groups and dataframes are currently only supported with the Spark engine and
            Spark dataframes.

        Parameters:
            validation_size: size of validation set. Should be between 0 and 1.
            test_size: size of test set. Should be between 0 and 1.
            train_start: Start event time for the train split query, inclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            train_end: End event time for the train split query, exclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            validation_start: Start event time for the validation split query, inclusive. Strings
                should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            validation_end: End event time for the validation split query, exclusive. Strings
                should be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            test_start: Start event time for the test split query, inclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            test_end: End event time for the test split query, exclusive. Strings should
                be formatted in one of the following formats `%Y-%m-%d`, `%Y-%m-%d %H`, `%Y-%m-%d %H:%M`, `%Y-%m-%d %H:%M:%S`,
                or `%Y-%m-%d %H:%M:%S.%f`. Int, i.e Unix Epoch should be in seconds.
            description: A string describing the contents of the training dataset to
                improve discoverability for Data Scientists, defaults to empty string
                `""`.
            extra_filter: Additional filters to be attached to the training dataset.
                The filters will be also applied in `get_batch_data`.
            statistics_config: A configuration object, or a dictionary with keys
                "`enabled`" to generally enable descriptive statistics computation for
                this feature group, `"correlations`" to turn on feature correlation
                computation and `"histograms"` to compute feature value frequencies. The
                values should be booleans indicating the setting. To fully turn off
                statistics computation pass `statistics_config=False`. Defaults to
                `None` and will compute only descriptive statistics.
            read_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                When using the `python` engine, read_options can contain the
                following entries:
                * key `"arrow_flight_config"` to pass a dictionary of arrow flight configurations.
                  For example: `{"arrow_flight_config": {"timeout": 900}}`
                * key `spark` and value an object of type
                  [hsfs.core.job_configuration.JobConfiguration][hsfs.core.job_configuration.JobConfiguration]
                  to configure the Hopsworks Job used to compute the training dataset.
            spine: Spine dataframe with primary key, event time and
                label column to use for point in time join when fetching features. Defaults to `None` and is only required
                when feature view was created with spine group in the feature query.
                It is possible to directly pass a spine group instead of a dataframe to overwrite the left side of the
                feature join, however, the same features as in the original feature group that is being replaced need to
                be available in the spine group.
            primary_key: whether to include primary key features or not.  Defaults to `False`, no primary key
                features.
            event_time: whether to include event time feature or not.  Defaults to `False`, no event time feature.
            training_helper_columns: whether to include training helper columns or not.
                Training helper columns are a list of feature names in the feature view, defined during its creation,
                that are not the part of the model schema itself but can be used during training as a helper for
                extra information. If training helper columns were not defined in the feature view
                then`training_helper_columns=True` will not have any effect. Defaults to `False`, no training helper
                columns.
            dataframe_type: str, optional. The type of the returned dataframe.
                Possible values are `"default"`, `"spark"`,`"pandas"`, `"polars"`, `"numpy"` or `"python"`.
                Defaults to "default", which maps to Spark dataframe for the Spark Engine and Pandas dataframe for the Python engine.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution. If no context variables are provided, this parameter defaults to `None`.
            lookback:
                Optional lookback window applied to the PIT join before reading; bounds the rows each joined feature group contributes so the engine can prune partitions before opening files. The same window applies to all three splits.
                For one window across every feature group, pass a `FeatureGroupLookback` — e.g. `FeatureGroupLookback(key="PARTITION_KEY", start=date(2026, 5, 5), end=date(2026, 5, 17))` or its dict form `{"key": "PARTITION_KEY", "start": date(2026, 5, 5), "end": date(2026, 5, 17)}`.
                For different windows per feature group, pass a `Lookback` — e.g. `Lookback(default=FeatureGroupLookback(...), feature_group_lookbacks={"dim_a": FeatureGroupLookback(...)})` or its dict form `{"default": {...}, "feature_group_lookbacks": {"dim_a": {...}}}`.
                See [`FeatureGroupLookback`][hsfs.constructor.lookback.FeatureGroupLookback] and [`Lookback`][hsfs.constructor.lookback.Lookback] for accepted key values, validation rules, and per-FG key matching semantics.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.
            tags: Tags to attach to the training dataset for better discoverability.

        Returns:
            (X_train, X_val, X_test, y_train, y_val, y_test):
                Tuple of dataframe of features and labels
        """
        self._validate_train_validation_test_split(
            validation_size=validation_size,
            test_size=test_size,
            train_end=train_end,
            validation_start=validation_start,
            validation_end=validation_end,
            test_start=test_start,
        )
        normalized_tags = tag.Tag._normalize(tags)

        td = training_dataset.TrainingDataset(
            name=self.name,
            version=None,
            splits={},
            validation_size=validation_size,
            test_size=test_size,
            time_split_size=3,
            train_start=train_start,
            train_end=train_end,
            validation_start=validation_start,
            validation_end=validation_end,
            test_start=test_start,
            test_end=test_end,
            description=description,
            data_source=None,
            featurestore_id=self._featurestore_id,
            data_format="tsv",
            statistics_config=statistics_config,
            training_dataset_type=training_dataset.TrainingDataset.IN_MEMORY,
            extra_filter=extra_filter,
            lookback=Lookback.from_user_input(lookback),
            tags=normalized_tags,
        )
        td, df = self._feature_view_engine._get_training_data(
            self,
            read_options,
            training_dataset_obj=td,
            splits=[
                TrainingDatasetSplit.TRAIN,
                TrainingDatasetSplit.VALIDATION,
                TrainingDatasetSplit.TEST,
            ],
            spine=spine,
            primary_keys=kwargs.get("primary_keys") or primary_key,
            event_time=event_time,
            training_helper_columns=training_helper_columns,
            dataframe_type=dataframe_type,
            transformation_context=transformation_context,
            n_processes=n_processes,
        )
        warnings.warn(
            f"Incremented version to `{td.version}`.",
            util.VersionWarning,
            stacklevel=1,
        )
        self.update_last_accessed_training_dataset(td.version)
        return df

    @staticmethod
    def _validate_train_validation_test_split(
        validation_size: float | None,
        test_size: float | None,
        train_end: str | int | datetime | date | None,
        validation_start: str | int | datetime | date | None,
        validation_end: str | int | datetime | date | None,
        test_start: str | int | datetime | date | None,
    ) -> None:
        if not (
            (validation_size and 0 < validation_size < 1)
            and (test_size and 0 < test_size < 1)
            and (validation_size + test_size < 1)
            or ((train_end or validation_start) and (validation_end or test_start))
        ):
            raise ValueError(
                "Invalid split input."
                " You should specify either (`validation_size` and `test_size`) or ((`train_end` or `validation_start`) and (`validation_end` or `test_start`))."
                "`validation_size`, `test_size` and sum of `validationSize` and `testSize` should be between 0 and 1 if specified."
            )

    @public
    @usage._method_logger
    def get_training_data(
        self,
        training_dataset_version: int,
        read_options: dict[str, Any] | None = None,
        primary_key: bool = False,
        event_time: bool = False,
        training_helper_columns: bool = False,
        dataframe_type: str | None = "default",
        transformation_context: dict[str, Any] = None,
        n_processes: int | None = None,
        **kwargs,
    ) -> tuple[
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes | None,
    ]:
        """Get training data created by `feature_view.create_training_data` or `feature_view.training_data`.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get training data
            features_df, labels_df = feature_view.get_training_data(training_dataset_version=1)
            ```

        Warning: External Storage Support
            Reading training data that was written to external storage using a Storage
            Connector other than S3 can currently not be read using HSFS APIs with
            Python as Engine, instead you will have to use the storage's native client.

        Parameters:
            training_dataset_version: training dataset version
            read_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                For python engine:
                * key `"arrow_flight_config"` to pass a dictionary of arrow flight configurations.
                  For example: `{"arrow_flight_config": {"timeout": 900}}`
            primary_key: whether to include primary key features or not.  Defaults to `False`, no primary key
                features.
            event_time: whether to include event time feature or not.  Defaults to `False`, no event time feature.
            training_helper_columns: whether to include training helper columns or not.
                Training helper columns are a list of feature names in the feature view, defined during its creation,
                that are not the part of the model schema itself but can be used during training as a helper for
                extra information. If training helper columns were not defined in the feature view or during
                materializing training dataset in the file system then`training_helper_columns=True` will not have
                any effect. Defaults to `False`, no training helper columns.
            dataframe_type: str, optional. The type of the returned dataframe.
                Possible values are `"default"`, `"spark"`,`"pandas"`, `"polars"`, `"numpy"` or `"python"`.
                Defaults to "default", which maps to Spark dataframe for the Spark Engine and Pandas dataframe for the Python engine.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution.
                If no context variables are provided, this parameter defaults to `None`.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            (X, y): Tuple of dataframe of features and labels
        """
        td, df = self._feature_view_engine._get_training_data(
            self,
            read_options,
            training_dataset_version=training_dataset_version,
            primary_keys=kwargs.get("primary_keys") or primary_key,
            event_time=event_time,
            training_helper_columns=training_helper_columns,
            dataframe_type=dataframe_type,
            transformation_context=transformation_context,
            n_processes=n_processes,
        )
        self.update_last_accessed_training_dataset(td.version)
        util._check_missing_mandatory_tags(td.missing_mandatory_tags)
        return df

    @public
    @usage._method_logger
    def get_train_test_split(
        self,
        training_dataset_version: int,
        read_options: dict[Any, Any] | None = None,
        primary_key: bool = False,
        event_time: bool = False,
        training_helper_columns: bool = False,
        dataframe_type: str | None = "default",
        transformation_context: dict[str, Any] = None,
        n_processes: int | None = None,
        **kwargs,
    ) -> tuple[
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes | None,
        TrainingDatasetDataFrameTypes | None,
    ]:
        """Get training data created by `feature_view.create_train_test_split` or `feature_view.train_test_split`.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get training data
            X_train, X_test, y_train, y_test = feature_view.get_train_test_split(training_dataset_version=1)
            ```

        Parameters:
            training_dataset_version: training dataset version
            read_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                For python engine:
                * key `"arrow_flight_config"` to pass a dictionary of arrow flight configurations.
                  For example: `{"arrow_flight_config": {"timeout": 900}}`
            primary_key: whether to include primary key features or not.  Defaults to `False`, no primary key
                features.
            event_time: whether to include event time feature or not.  Defaults to `False`, no event time feature.
            training_helper_columns: whether to include training helper columns or not.
                Training helper columns are a list of feature names in the feature view, defined during its creation,
                that are not the part of the model schema itself but can be used during training as a helper for
                extra information. If training helper columns were not defined in the feature view or during
                materializing training dataset in the file system then`training_helper_columns=True` will not have
                any effect. Defaults to `False`, no training helper columns.
            dataframe_type: str, optional. The type of the returned dataframe.
                Possible values are `"default"`, `"spark"`,`"pandas"`, `"polars"`, `"numpy"` or `"python"`.
                Defaults to "default", which maps to Spark dataframe for the Spark Engine and Pandas dataframe for the Python engine.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution. If no context variables are provided, this parameter defaults to `None`.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            (X_train, X_test, y_train, y_test):
                Tuple of dataframe of features and labels
        """
        td, df = self._feature_view_engine._get_training_data(
            self,
            read_options,
            training_dataset_version=training_dataset_version,
            splits=[TrainingDatasetSplit.TRAIN, TrainingDatasetSplit.TEST],
            primary_keys=kwargs.get("primary_keys") or primary_key,
            event_time=event_time,
            training_helper_columns=training_helper_columns,
            dataframe_type=dataframe_type,
            transformation_context=transformation_context,
            n_processes=n_processes,
        )
        self.update_last_accessed_training_dataset(td.version)
        return df

    @public
    @usage._method_logger
    def get_train_validation_test_split(
        self,
        training_dataset_version: int,
        read_options: dict[str, Any] | None = None,
        primary_key: bool = False,
        event_time: bool = False,
        training_helper_columns: bool = False,
        dataframe_type: str = "default",
        transformation_context: dict[str, Any] = None,
        n_processes: int | None = None,
        **kwargs,
    ) -> tuple[
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes,
        TrainingDatasetDataFrameTypes | None,
        TrainingDatasetDataFrameTypes | None,
        TrainingDatasetDataFrameTypes | None,
    ]:
        """Get training data created by `feature_view.create_train_validation_test_split` or `feature_view.train_validation_test_split`.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get training data
            X_train, X_val, X_test, y_train, y_val, y_test = feature_view.get_train_validation_test_splits(training_dataset_version=1)
            ```

        Parameters:
            training_dataset_version: training dataset version
            read_options: Additional options as key/value pairs to pass to the execution engine.
                Defaults to `{}`.
                For spark engine: Dictionary of read options for Spark.
                For python engine:
                * key `"arrow_flight_config"` to pass a dictionary of arrow flight configurations.
                  For example: `{"arrow_flight_config": {"timeout": 900}}`
            primary_key: whether to include primary key features or not.  Defaults to `False`, no primary key
                features.
            event_time: whether to include event time feature or not.  Defaults to `False`, no event time feature.
            training_helper_columns: whether to include training helper columns or not.
                Training helper columns are a list of feature names in the feature view, defined during its creation,
                that are not the part of the model schema itself but can be used during training as a helper for
                extra information. If training helper columns were not defined in the feature view or during
                materializing training dataset in the file system then`training_helper_columns=True` will not have
                any effect. Defaults to `False`, no training helper columns.
            dataframe_type: str, optional. The type of the returned dataframe.
                Possible values are `"default"`, `"spark"`,`"pandas"`, `"polars"`, `"numpy"` or `"python"`.
                Defaults to "default", which maps to Spark dataframe for the Spark Engine and Pandas dataframe for the Python engine.
            transformation_context:
                A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution. If no context variables are provided, this parameter defaults to `None`.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            (X_train, X_val, X_test, y_train, y_val, y_test):
                Tuple of dataframe of features and labels
        """
        td, df = self._feature_view_engine._get_training_data(
            self,
            read_options,
            training_dataset_version=training_dataset_version,
            splits=[
                TrainingDatasetSplit.TRAIN,
                TrainingDatasetSplit.VALIDATION,
                TrainingDatasetSplit.TEST,
            ],
            primary_keys=kwargs.get("primary_keys") or primary_key,
            event_time=event_time,
            training_helper_columns=training_helper_columns,
            dataframe_type=dataframe_type,
            transformation_context=transformation_context,
            n_processes=n_processes,
        )
        self.update_last_accessed_training_dataset(td.version)
        return df

    @public
    @usage._method_logger
    def get_training_datasets(self) -> list[training_dataset.TrainingDatasetBase]:
        """Returns the metadata of all training datasets created with this feature view.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get all training dataset metadata
            list_tds_meta = feature_view.get_training_datasets()
            ```

        Returns:
            List of training datasets metadata.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        tds = self._feature_view_engine._get_training_datasets(self)
        for td in tds:
            util._check_missing_mandatory_tags(
                td.missing_mandatory_tags,
                message=f"Training dataset '{td.name}' version {td.version} has missing mandatory tags",
            )
        return tds

    @public
    @usage._method_logger
    def get_training_dataset_statistics(
        self,
        training_dataset_version: int,
        before_transformation: bool = False,
        feature_names: list[str] | None = None,
    ) -> Statistics:
        """Get statistics of a training dataset.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get training dataset statistics
            statistics = feature_view.get_training_dataset_statistics(training_dataset_version=1)
            ```

        Parameters:
            training_dataset_version: Training dataset version
            before_transformation: Whether the statistics were computed before transformation functions or not.
            feature_names: List of feature names of which statistics are retrieved.

        Returns:
            `Statistics`
        """
        return self._statistics_engine._get(
            self,
            training_dataset_version=training_dataset_version,
            before_transformation=before_transformation,
            feature_names=feature_names,
        )

    @public
    @usage._method_logger
    def add_training_dataset_tag(
        self,
        training_dataset_version: int,
        name: str,
        value: dict[str, Any] | tag.Tag,
    ) -> None:
        """Attach a tag to a training dataset.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature feature view instance
            feature_view = fs.get_feature_view(...)

            # attach a tag to a training dataset
            feature_view.add_training_dataset_tag(
                training_dataset_version=1,
                name="tag_schema",
                value={"key", "value"}
            )
            ```

        Parameters:
            training_dataset_version: training dataset version
            name: Name of the tag to be added.
            value: Value of the tag to be added.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        return self._feature_view_engine._add_tag(
            self, name, value, training_dataset_version=training_dataset_version
        )

    @public
    @usage._method_logger
    def get_training_dataset_tag(
        self, training_dataset_version: int, name: str
    ) -> tag.Tag | None:
        """Get the tags of a training dataset.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get a training dataset tag
            tag_str = feature_view.get_training_dataset_tag(
                training_dataset_version=1,
                 name="tag_schema"
            )
            ```

        Parameters:
            training_dataset_version: training dataset version
            name: Name of the tag to get.

        Returns:
            tag value or `None` if it does not exist.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        return self._feature_view_engine._get_tag(
            self, name, training_dataset_version=training_dataset_version
        )

    @public
    @usage._method_logger
    def get_training_dataset_tags(
        self, training_dataset_version: int
    ) -> dict[str, tag.Tag]:
        """Returns all tags attached to a training dataset.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # get a training dataset tags
            list_tags = feature_view.get_training_dataset_tags(
                training_dataset_version=1
            )
            ```

        Parameters:
            training_dataset_version: The training dataset version to get tags for.

        Returns:
            Dictionary of tags.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        return self._feature_view_engine._get_tags(
            self, training_dataset_version=training_dataset_version
        )

    @public
    @usage._method_logger
    def delete_training_dataset_tag(
        self, training_dataset_version: int, name: str
    ) -> None:
        """Delete a tag attached to a training dataset.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # delete training dataset tag
            feature_view.delete_training_dataset_tag(
                training_dataset_version=1,
                name='name_of_dataset'
            )
            ```

        Parameters:
            training_dataset_version: training dataset version
            name: Name of the tag to be removed.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        return self._feature_view_engine._delete_tag(
            self, name, training_dataset_version=training_dataset_version
        )

    @public
    @usage._method_logger
    def purge_training_data(self, training_dataset_version: int) -> None:
        """Delete a training dataset (data only).

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # purge training data
            feature_view.purge_training_data(training_dataset_version=1)
            ```

        Parameters:
            training_dataset_version: Version of the training dataset to be removed.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        if self._last_accessed_training_dataset == training_dataset_version:
            self.update_last_accessed_training_dataset(None)
        self._feature_view_engine._delete_training_dataset_only(
            self, training_data_version=training_dataset_version
        )

    @public
    @usage._method_logger
    def purge_all_training_data(self) -> None:
        """Delete all training datasets (data only).

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # purge all training data
            feature_view.purge_all_training_data()
            ```

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        if self._last_accessed_training_dataset is not None:
            self.update_last_accessed_training_dataset(None)
        self._feature_view_engine._delete_training_dataset_only(self)

    @public
    @usage._method_logger
    def delete_training_dataset(self, training_dataset_version: int) -> None:
        """Delete a training dataset. This will delete both metadata and training data.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # delete a training dataset
            feature_view.delete_training_dataset(
                training_dataset_version=1
            )
            ```

        Parameters:
            training_dataset_version: Version of the training dataset to be removed.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        if self._last_accessed_training_dataset == training_dataset_version:
            self.update_last_accessed_training_dataset(None)
        self._feature_view_engine._delete_training_data(
            self, training_data_version=training_dataset_version
        )

    @public
    @usage._method_logger
    def delete_all_training_datasets(self) -> None:
        """Delete all training datasets. This will delete both metadata and training data.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # delete all training datasets
            feature_view.delete_all_training_datasets()
            ```

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
        """
        if self._last_accessed_training_dataset is not None:
            self.update_last_accessed_training_dataset(None)
        self._feature_view_engine._delete_training_data(self)

    @public
    def visualize_transformations(
        self,
        kind: str = "all",
        mode: str = "auto",
        orient: str = "LR",
    ) -> None:
        """Visualize transformation function execution DAGs attached to this feature view.

        Renders the transformation pipeline as a directed graph showing input features,
        transformation functions, dependency edges with linking column names, and
        output features. When ``kind="all"`` (the default), the model-dependent and
        on-demand DAGs render sequentially, each under its own heading.

        Example:
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            fv = fs.get_feature_view(...)

            # visualize all transformations (renders inline in Jupyter)
            fv.visualize_transformations()

            # visualize only model-dependent transformations
            fv.visualize_transformations(kind="model_dependent")

            # force text output
            fv.visualize_transformations(mode="text")
            ```

        Parameters:
            kind: Which transformations to visualize. One of:
                `"all"` (default) - both on-demand and model-dependent transformations,
                `"on_demand"` - only on-demand transformations,
                `"model_dependent"` - only model-dependent transformations.
            mode: Display mode. One of `"auto"` (default), `"text"`, `"mermaid"`.
            orient: Layout direction for the rendered flowchart. One of:
                `"LR"` (left-to-right, default), `"TB"` (top-to-bottom),
                `"BT"` (bottom-to-top), `"RL"` (right-to-left).

        Raises:
            `ValueError`: If `kind` is not one of `"all"`, `"on_demand"`, `"model_dependent"`.
            `FeatureStoreException`: If the requested DAG is not available.
        """
        valid_kinds = ("all", "on_demand", "model_dependent")
        if kind not in valid_kinds:
            raise ValueError(f"Invalid kind '{kind}'. Must be one of {valid_kinds}.")

        if kind == "on_demand":
            if self._on_demand_transformation_execution_graph is None:
                raise FeatureStoreException(
                    "On-demand transformation execution graph is not available. "
                    "Ensure features have been retrieved from the backend."
                )
            self._on_demand_transformation_execution_graph._visualize(
                mode=mode, orient=orient
            )
            return

        if kind == "model_dependent":
            self._model_dependent_transformation_execution_graph._visualize(
                mode=mode, orient=orient
            )
            return

        # kind == "all": render each non-empty DAG under its own heading; each
        # DAG renders itself, so empty ones are simply skipped.
        md = self._model_dependent_transformation_execution_graph
        od = self._on_demand_transformation_execution_graph
        sections: list[
            tuple[str, transformation_execution_dag.TransformationExecutionDAG]
        ] = []
        if md is not None and md.nodes:
            sections.append(("Model-Dependent Transformations", md))
        if od is not None and od.nodes:
            sections.append(("On-Demand Transformations", od))

        if not sections:
            print("No transformation functions attached to this feature view.")
            return

        in_jupyter = (
            transformation_execution_dag.TransformationExecutionDAG._in_jupyter()
        )

        if mode == "text" or (mode == "auto" and not in_jupyter):
            for i, (title, dag) in enumerate(sections):
                if i > 0:
                    print()
                print(title)
                print(dag)
            return

        # Inline mode in Jupyter: emit a Markdown header per DAG, then let
        # each DAG render its own Mermaid block.
        from IPython.display import Markdown, display

        for title, dag in sections:
            display(Markdown(f"### {title}"))
            dag._visualize(mode=mode, orient=orient)

    @public
    def get_feature_monitoring_configs(
        self,
        name: str | None = None,
        feature_name: str | None = None,
        config_id: int | None = None,
    ) -> fmc.FeatureMonitoringConfig | list[fmc.FeatureMonitoringConfig] | None:
        """Fetch feature monitoring configs attached to the feature view.

        If no arguments is provided the method will return all feature monitoring configs
        attached to the feature view, meaning all feature monitoring configs that are attach
        to a feature in the feature view. If you wish to fetch a single config, provide the
        its name. If you wish to fetch all configs attached to a particular feature, provide
        the feature name.

        Example:
            ```python3
            # fetch your feature view
            fv = fs.get_feature_view(name="my_feature_view", version=1)
            # fetch all feature monitoring configs attached to the feature view
            fm_configs = fv.get_feature_monitoring_configs()
            # fetch a single feature monitoring config by name
            fm_config = fv.get_feature_monitoring_configs(name="my_config")
            # fetch all feature monitoring configs attached to a particular feature
            fm_configs = fv.get_feature_monitoring_configs(feature_name="my_feature")
            # fetch a single feature monitoring config with a particular id
            fm_config = fv.get_feature_monitoring_configs(config_id=1)
            ```

        Parameters:
            name: If provided fetch only the feature monitoring config with the given name.
            feature_name: If provided, fetch only configs attached to a particular feature.
            config_id: If provided, fetch only the feature monitoring config with the given id.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request
            hopsworks.client.exceptions.FeatureStoreException: If the feature view is not registered in Hopsworks
            ValueError: if both name and feature_name are provided.
            TypeError: if name or feature_name are not string or None.

        Returns:
            A list of feature monitoring configs.
            If name provided, returns either a single config or None if not found.
        """
        # TODO: Should this filter out scheduled statistics only configs?
        if not self._id:
            raise FeatureStoreException(
                "Only Feature View registered with Hopsworks can fetch feature monitoring configurations."
            )

        return self._feature_monitoring_config_engine._get_feature_monitoring_configs(
            name=name,
            feature_name=feature_name,
            config_id=config_id,
        )

    @public
    def get_feature_monitoring_history(
        self,
        config_name: str | None = None,
        config_id: int | None = None,
        start_time: int | str | datetime | date | None = None,
        end_time: int | str | datetime | date | None = None,
        with_statistics: bool | None = True,
    ) -> list[fmr.FeatureMonitoringResult]:
        """Fetch feature monitoring history for a given feature monitoring config.

        Example:
            ```python3
            # fetch your feature view
            fv = fs.get_feature_view(name="my_feature_view", version=1)
            # fetch feature monitoring history for a given feature monitoring config
            fm_history = fv.get_feature_monitoring_history(
                config_name="my_config",
                start_time="2020-01-01",
            )
            # or use the config id
            fm_history = fv.get_feature_monitoring_history(
                config_id=1,
                start_time=datetime.now() - timedelta(weeks=2),
                end_time=datetime.now() - timedelta(weeks=1),
                with_statistics=False,
            )
            ```

        Parameters:
            config_name: The name of the feature monitoring config to fetch history for.
            config_id: The id of the feature monitoring config to fetch history for.
            start_time: The start date of the feature monitoring history to fetch.
            end_time: The end date of the feature monitoring history to fetch.
            with_statistics: Whether to include statistics in the feature monitoring history.
                If False, only metadata about the monitoring will be fetched.

        Raises:
            hopsworks.client.exceptions.RestAPIError: In case the backend encounters an issue
            hopsworks.client.exceptions.FeatureStoreException: If the feature view is not registered in Hopsworks
            ValueError: if both config_name and config_id are provided.
            TypeError: if config_name or config_id are not respectively string, int or None.

        Returns:
            A list of feature monitoring results containing the monitoring metadata as well as the computed statistics for the detection and reference window if requested.
        """
        if not self._id:
            raise FeatureStoreException(
                "Only Feature View registered with Hopsworks can fetch feature monitoring history."
            )

        return self._feature_monitoring_result_engine._get_feature_monitoring_results(
            config_name=config_name,
            config_id=config_id,
            start_time=start_time,
            end_time=end_time,
            with_statistics=with_statistics,
        )

    @public
    def create_scheduled_statistics(
        self,
        name: str,
        feature_names: str | list[str] | None = None,
        description: str | None = None,
        start_date_time: int | str | datetime | date | pd.Timestamp | None = None,
        end_date_time: int | str | datetime | date | pd.Timestamp | None = None,
        cron_expression: str | None = "0 0 12 ? * * *",
    ) -> fmc.FeatureMonitoringConfig:
        """Create a job to compute statistics on snapshot of feature data on a schedule.

        Example:
            ```python3
            # fetch feature view
            fv = fs.get_feature_view(name="my_feature_view", version=1)

            # enable statistics monitoring
            my_config = fv.create_scheduled_statistics(
                name="my_config",
                start_date_time="2021-01-01 00:00:00",
                description="my description",
                cron_expression="0 0 12 ? * * *",
            ).with_detection_window(
                # Statistics computed on 10% of the last week of data
                time_offset="1w",
                row_percentage=0.1,
            ).save()
            ```

        Parameters:
            name: Name of the feature monitoring configuration.
                name must be unique for all configurations attached to the feature view.
            feature_names: Names of the features to monitor. If not specified, statistics
                will be computed for all features.
            description: Description of the feature monitoring configuration.
            start_date_time: Start date and time from which to start computing statistics.
            end_date_time: End date and time at which to stop computing statistics.
            cron_expression: Cron expression to use to schedule the job. The cron expression
                must be in UTC and follow the Quartz specification. Default is '0 0 12 ? * * *',
                every day at 12pm UTC.

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: If the feature view is not registered in Hopsworks

        Returns:
            Configuration with minimal information about the feature monitoring.
            Additional information are required before feature monitoring is enabled.
        """
        if not self._id:
            raise FeatureStoreException(
                "Only Feature View registered with Hopsworks can enable scheduled statistics."
            )

        valid_features = {feat.name: feat.type for feat in self._features}
        valid_feature_names = list(valid_features.keys())

        if feature_names is None:
            # choose all features if none is selected
            feature_names = valid_feature_names
        elif not isinstance(feature_names, list):
            feature_names = [feature_names]

        return self._feature_monitoring_config_engine._build_default_scheduled_statistics_config(
            name=name,
            feature_names=feature_names,
            description=description,
            start_date_time=start_date_time,
            valid_feature_names=valid_feature_names,
            cron_expression=cron_expression,
            end_date_time=end_date_time,
            valid_features=valid_features,
        )

    @public
    def create_feature_monitoring(
        self,
        name: str,
        description: str | None = None,
        start_date_time: int | str | datetime | date | pd.Timestamp | None = None,
        end_date_time: int | str | datetime | date | pd.Timestamp | None = None,
        cron_expression: str | None = "0 0 12 ? * * *",
    ) -> fmc.FeatureMonitoringConfig:
        """Enable feature monitoring to compare statistics on snapshots of feature data over time.

        Experimental:
            Public API is subject to change, this feature is not suitable for production use-cases.

        Example:
            ```python3
            # fetch feature view
            fg = fs.get_feature_view(name="my_feature_view", version=1)

            # enable feature monitoring
            my_config = fg.create_feature_monitoring(
                name="my_monitoring_config",
                description="my monitoring config description",
                cron_expression="0 0 12 ? * * *",
            ).with_detection_window(
                # Data inserted in the last day
                time_offset="1d",
                window_length="1d",
            ).with_reference_window(
                # compare to a given value
                specific_value=0.5,
            ).compare_on(
                feature_name="my_feature",
                metric="mean",
                threshold=0.5,
            ).save()
            ```

        Parameters:
            name: Name of the feature monitoring configuration.
                name must be unique for all configurations attached to the feature view.
            description: Description of the feature monitoring configuration.
            start_date_time: Start date and time from which to start computing statistics.
            end_date_time: End date and time at which to stop computing statistics.
            cron_expression: Cron expression to use to schedule the job.
                The cron expression must be in UTC and follow the Quartz specification.
                The default value means "every day at 12pm UTC".

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: If the feature view is not registered in Hopsworks.

        Returns:
            Configuration with minimal information about the feature monitoring.
            Additional information are required before feature monitoring is enabled.
        """
        if not self._id:
            raise FeatureStoreException(
                "Only Feature View registered with Hopsworks can enable feature monitoring."
            )

        valid_features = {feat.name: feat.type for feat in self._features}
        return self._feature_monitoring_config_engine._build_default_feature_monitoring_config(
            name=name,
            description=description,
            start_date_time=start_date_time,
            valid_feature_names=list(valid_features.keys()),
            end_date_time=end_date_time,
            cron_expression=cron_expression,
            valid_features=valid_features,
        )

    @public
    def create_model_monitoring(
        self,
        name: str,
        model_name: str,
        model_version: int,
        description: str | None = None,
        start_date_time: int | str | datetime | date | pd.Timestamp | None = None,
        end_date_time: int | str | datetime | date | pd.Timestamp | None = None,
        cron_expression: str | None = "0 0 12 ? * * *",
    ) -> fmc.FeatureMonitoringConfig:
        """Enable feature monitoring on the inference logs of a specific deployed model.

        Targets the logging feature group (``{fv_name}_{version}_log``) and filters by
        ``model_name`` and ``model_version`` so the FM job only consumes the inference
        rows produced by that one deployment. The reference window
        defaults to the training dataset version used to train the model — this is
        recorded on the model at registration time. Any explicit
        :func:`FeatureMonitoringConfig.with_reference_training_dataset` call is validated
        against the model's training TD version and raises on mismatch.

        Experimental:
            Public API is subject to change, this feature is not suitable for production use-cases.

        Example:
            ```python3
            fv = fs.get_feature_view(name="my_feature_view", version=1)

            my_config = fv.create_model_monitoring(
                name="model_psi_monitoring",
                model_name="iris_classifier",
                model_version=3,
                cron_expression="0 0 12 ? * * *",
            ).with_detection_window(
                # served by this model in the last day
                time_offset="1d",
                window_length="1d",
            ).with_reference_training_dataset(
                # omitted -> defaults to the TD version used to train iris_classifier v3
            ).compare_on_distribution(
                feature_name="petal_length",
                metric="PSI",
                threshold=0.2,
            ).save()
            ```

        Parameters:
            name: Name of the feature monitoring configuration. Must be unique among the
                configurations attached to the logging feature group.
            model_name: Name of the model whose inference logs are monitored.
            model_version: Version of the model whose inference logs are monitored.
            description: Description of the feature monitoring configuration.
            start_date_time: Start date and time from which to start computing statistics.
            end_date_time: End date and time at which to stop computing statistics.
            cron_expression: Cron expression to use to schedule the job. The cron
                expression must be in UTC and follow the Quartz specification. The
                default value means "every day at 12pm UTC".

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: If feature logging is not
                enabled, the feature view is not registered, the named model is not
                found, or the model has no recorded training dataset version.

        Returns:
            Configuration with minimal information about the feature monitoring.
            Additional information are required before feature monitoring is enabled.
        """
        if not self.logging_enabled:
            raise FeatureStoreException(
                "Feature logging is not enabled for this feature view. "
                "Call self.enable_logging() first."
            )

        # Idea A — warn when a sub-hourly cron is used for model monitoring.
        # The inference-log feature group materializes offline data at most hourly, so a
        # finer cron produces redundant or incomplete detection windows.
        if util._is_sub_hour_cron(cron_expression):
            warnings.warn(
                f"The cron expression '{cron_expression}' fires more than once per hour "
                "but the inference-log feature group materializes offline data at most "
                "hourly. Sub-hourly crons produce redundant or incomplete detection "
                "windows. Consider using a cron that fires at most once per hour (e.g. "
                "'0 0 * * * ? *'). ",
                UserWarning,
                stacklevel=2,
            )

        # Lazy imports: hsml is a sibling SDK package and the rest of hsfs imports it
        # the same way (see explicit_provenance.py).
        try:
            from hsml.core import model_api as hsml_model_api
        except ModuleNotFoundError as err:
            raise FeatureStoreException(
                "Model monitoring requires the hsml library, which is not installed. "
                "Install hsml before creating a model monitoring configuration."
            ) from err

        _client = client._get_instance()
        model_meta = hsml_model_api.ModelApi()._get(
            name=model_name,
            version=model_version,
            model_registry_id=_client._project_id,
        )
        if model_meta is None:
            raise FeatureStoreException(
                f"Model '{model_name}' version {model_version} was not found in the "
                "model registry of this project."
            )
        training_dataset_version = model_meta.training_dataset_version
        if not training_dataset_version:
            raise FeatureStoreException(
                f"Model '{model_name}' version {model_version} has no recorded "
                "training dataset version. Re-register the model with the feature "
                "view and training_dataset_version that was used to train it."
            )

        logging_fg = self.feature_logging.get_feature_group()
        config = logging_fg.create_feature_monitoring(
            name=name,
            description=description,
            start_date_time=start_date_time,
            end_date_time=end_date_time,
            cron_expression=cron_expression,
        )
        # Stamp model fields onto the config — they are persisted via to_dict() and
        # threaded through to the FM job, where they become a Filter on the logging FG.
        config._model_name = model_name
        config._model_version = model_version
        config._associated_model_td_version = training_dataset_version
        return config

    @public
    def get_alerts(self) -> list[FeatureViewAlert] | Alert:
        """Get all alerts for this feature view.

        Returns:
            A list of `FeatureViewAlert` objects or a single `Alert` object if there is only one alert.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._alert_api.get_feature_view_alerts(
            self._feature_store_id,
            feature_view_name=self._name,
            feature_view_version=self._version,
        )

    @public
    def get_alert(self, alert_id: int) -> FeatureViewAlert | None:
        """Get an alert for this feature view by ID.

        Parameters:
            alert_id: The id of the alert to get.

        Returns:
            A single FeatureViewAlert object is returned.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._alert_api.get_feature_view_alert(
            self._feature_store_id,
            feature_view_name=self._name,
            feature_view_version=self._version,
            alert_id=alert_id,
        )

    @public
    def create_alert(
        self,
        receiver: str,
        status: Literal[
            "feature_validation_success",
            "feature_validation_warning",
            "feature_validation_failure",
            "monitoring_shift_undetected",
            "monitoring_shift_detected",
            "monitoring_empty_detection_window",
            # deprecated since ~=3.8.1; kept for one release
            "feature_monitor_shift_undetected",
            "feature_monitor_shift_detected",
        ],
        severity: Literal["info", "warning", "critical"],
    ) -> FeatureViewAlert:
        """Create an alert for this feature view.

        Example:
            ```python
            # get feature store instance
            fs = ...
            # get feature view instance
            feature_view = fs.get_feature_view(...)
            # create an alert
            alert = feature_view.create_alert(
                receiver="email",
                status="monitoring_shift_undetected",
                severity="info",
            )
            ```

        Parameters:
            receiver: The receiver of the alert.
            status: The status that will trigger the alert.
                The names feature_monitor_shift_undetected and
                feature_monitor_shift_detected are deprecated since ~=3.8.1 and will
                be removed in a future release.
            severity: The severity of the alert.

        Returns:
            The created FeatureViewAlert object.

        Raises:
            ValueError: If the status is not valid.
            ValueError: If the severity is not valid.
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self._alert_api.create_feature_view_alert(
            feature_store_id=self._feature_store_id,
            feature_view_name=self._name,
            feature_view_version=self._version,
            receiver=receiver,
            status=status,
            severity=severity,
        )

    @classmethod
    def from_response_json(cls, json_dict: dict[str, Any]) -> FeatureView:
        """Function that constructs the class object from its json serialization.

        Parameters:
            json_dict: JSON serialized dictionary for the class.

        Returns:
            JSON deserialized class object.
        """
        json_decamelized = humps.decamelize(json_dict)

        serving_keys = json_decamelized.get("serving_keys", None)
        if serving_keys is not None:
            serving_keys = [
                skm.ServingKey.from_response_json(sk) for sk in serving_keys
            ]
        transformation_functions = json_decamelized.get("transformation_functions", {})
        tags_response = json_decamelized.get("tags", None)
        tags = None
        if tags_response:
            tags = tag.Tag.from_response_json(tags_response)
        fv = cls(
            id=json_decamelized.get("id", None),
            name=json_decamelized["name"],
            query=query.Query.from_response_json(json_decamelized["query"]),
            featurestore_id=json_decamelized["featurestore_id"],
            version=json_decamelized.get("version", None),
            description=json_decamelized.get("description", None),
            featurestore_name=json_decamelized.get("featurestore_name", None),
            serving_keys=serving_keys,
            logging_enabled=json_decamelized.get("logging_enabled", False),
            transformation_functions=(
                [
                    TransformationFunction.from_response_json(
                        {
                            **transformation_function,
                            "transformation_type": TransformationType.MODEL_DEPENDENT,
                        }
                    )
                    for transformation_function in transformation_functions
                ]
                if transformation_functions
                else []
            ),
            missing_mandatory_tags=json_decamelized.get("missing_mandatory_tags", None),
            tags=tags,
        )
        features = json_decamelized.get("features", [])
        if features:
            for feature_index in range(len(features)):
                feature = (
                    training_dataset_feature.TrainingDatasetFeature.from_response_json(
                        features[feature_index]
                    )
                )
                features[feature_index] = feature
        fv.schema = features

        # The backend serializes the feature view's complete on-demand
        # transformation chain, including the producers of dropped intermediates
        # that surface no feature. Hydrate it so the on-demand graph is built
        # from the full chain rather than reconstructed from per-feature
        # attachments (which lose dropped-intermediate producers). Older
        # backends omit this field, so the property falls back to the per-feature
        # walk.
        on_demand_transformation_functions = json_decamelized.get(
            "on_demand_transformation_functions", None
        )
        if on_demand_transformation_functions:
            fv.__on_demand_transformation_functions = [
                TransformationFunction.from_response_json(
                    {
                        **transformation_function,
                        "transformation_type": TransformationType.ON_DEMAND,
                    }
                )
                for transformation_function in on_demand_transformation_functions
            ]

        # The schema is known here, so both graphs rebuild with the entity's
        # feature names: a consumed name that exists both as a raw feature
        # and as another TF's output triggers the ambiguity warning. Cycles
        # downgrade to a warning so the entity stays readable.
        # Only raw features count: an on-demand output (incl. a kept chained
        # intermediate) is not a raw feature, so excluding it avoids warning
        # on every chained output the schema carries.
        schema_feature_names = {
            feature.name
            for feature in features
            if feature.on_demand_transformation_function is None
        }
        fv._on_demand_transformation_execution_graph = (
            transformation_execution_dag.TransformationExecutionDAG(
                fv._on_demand_transformation_functions,
                schema_feature_names=schema_feature_names,
            )
        )
        fv._model_dependent_transformation_execution_graph = (
            transformation_execution_dag.TransformationExecutionDAG(
                fv.transformation_functions,
                schema_feature_names=schema_feature_names,
            )
        )

        fv.labels = [feature.name for feature in features if feature.label]
        fv.inference_helper_columns = [
            feature.name for feature in features if feature.inference_helper_column
        ]
        fv.training_helper_columns = [
            feature.name for feature in features if feature.training_helper_column
        ]
        return fv

    def update_from_response_json(self, json_dict: dict[str, Any]) -> FeatureView:
        """Function that updates the class object from its json serialization.

        Parameters:
            json_dict: JSON serialized dictionary for the class.

        Returns:
            JSON deserialized class object.
        """
        other = self.from_response_json(json_dict)
        for key in [
            "name",
            "description",
            "id",
            "query",
            "featurestore_id",
            "version",
            "labels",
            "inference_helper_columns",
            "training_helper_columns",
            "transformation_functions",
            "schema",
            "serving_keys",
            "logging_enabled",
        ]:
            self._update_attribute_if_present(self, other, key)
        self._init_feature_monitoring_engine()
        return self

    @public
    def compute_on_demand_features(
        self,
        feature_vector: list[Any]
        | list[list[Any]]
        | pd.DataFrame
        | pl.DataFrame
        | None = None,
        request_parameters: list[dict[str, Any]] | dict[str, Any] | None = None,
        transformation_context: dict[str, Any] | None = None,
        return_type: Literal["list", "numpy", "pandas", "polars"] | None = None,
        n_processes: int | None = None,
    ) -> list[Any] | list[list[Any]] | pd.DataFrame | pl.DataFrame:
        """Function computes on-demand features present in the feature view.

        Parameters:
            feature_vector: The feature vector to be transformed.
            request_parameters: Request parameters required by on-demand transformation functions to compute on-demand features present in the feature view.
                These parameters take **highest priority** when resolving feature values.
                If a key exists in both `request_parameters` and the feature vector, the value from `request_parameters` is used.
            transformation_context: A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution.
            return_type: Defaults to the same type as the input feature vector.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            The feature vector that contains all on-demand features in the feature view.
        """
        return self._vector_server._compute_on_demand_features(
            feature_vectors=feature_vector,
            request_parameters=request_parameters,
            transformation_context=transformation_context,
            return_type=return_type,
            n_processes=n_processes,
        )

    @public
    def transform(
        self,
        feature_vector: list[Any] | list[list[Any]] | pd.DataFrame | pl.DataFrame,
        external: bool | None = None,
        transformation_context: dict[str, Any] | None = None,
        return_type: Literal["list", "numpy", "pandas", "polars"] | None = None,
        n_processes: int | None = None,
    ) -> list[Any] | list[list[Any]] | pd.DataFrame | pl.DataFrame:
        """Transform the input feature vector by applying Model-dependent transformations attached to the feature view.

        Warning: List input must match the schema of the feature view
                    If features are provided as a List to the transform function. Make sure that the input are ordered to match the schema
                    in the feature view.
        Parameters:
            feature_vector: The feature vector to be transformed.
            external: boolean, optional. If set to True, the connection to the
                online feature store is established using the same host as
                for the `host` parameter in the [`hopsworks.login`][hopsworks.login] method.
                If set to False, the online feature store storage connector is used
                which relies on the private IP. Defaults to True if connection to Hopsworks is established from
                external environment (e.g AWS Sagemaker or Google Colab), otherwise to False.
            transformation_context: A dictionary mapping variable names to objects that will be provided as contextual information to the transformation function at runtime.
                The `context` variable must be explicitly defined as parameters in the transformation function for these to be accessible during execution.
            return_type: Defaults to the same type as the input feature vector.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            The transformed feature vector obtained by applying Model-Dependent Transformations.
        """
        if not self._vector_server._serving_initialized:
            self.init_serving(external=external)

        return self._vector_server._transform(
            feature_vectors=feature_vector,
            transformation_context=transformation_context,
            return_type=return_type,
            n_processes=n_processes,
        )

    @public
    def enable_logging(
        self, extra_log_columns: Feature | dict[str, str] = None
    ) -> None:
        """Enable feature logging for the current feature view.

        This method activates logging of features.

        Parameters:
            extra_log_columns: Additional columns to be logged. Any duplicate columns will be ignored.

        Example: Enable feature logging
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # enable logging
            feature_view.enable_logging()
            ```

        Example: Enable feature logging and add extra log columns
            ```python
            # get feature store instance
            fs = ...

            # get feature view instance
            feature_view = fs.get_feature_view(...)

            # enable logging with two extra log columns
            feature_view.enable_logging(extra_log_columns=[{"name": "logging_col_1", "type": "string"},
                                                           {"name": "logging_col_2", "type": "int"}])
            ```

        Raises:
            hopsworks.client.exceptions.RestAPIError: In case the backend encounters an issue
        """
        fv = self._feature_view_engine._enable_feature_logging(self, extra_log_columns)
        self._feature_logging = self._feature_view_engine._get_feature_logging(fv)
        return fv

    @public
    def init_feature_logger(self, feature_logger: FeatureLogger) -> None:
        """Initialize the feature logger.

        Parameters:
            feature_logger: The logger to be used for logging features.
        """
        if feature_logger:
            self._feature_logger = feature_logger
            if not self.logging_enabled:
                self.enable_logging()
            self._feature_logger.init(self)
        else:
            # reset feature logger in case init_serving is called again without feature logger
            self._feature_logger = None

    @public
    def log(
        self,
        logging_data: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | TypeVar("pyspark.sql.DataFrame")
        | None = None,
        untransformed_features: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | TypeVar("pyspark.sql.DataFrame")
        | None = None,
        predictions: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | None = None,
        transformed_features: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | TypeVar("pyspark.sql.DataFrame")
        | None = None,
        inference_helper_columns: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | TypeVar("pyspark.sql.DataFrame")
        | None = None,
        request_parameters: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | TypeVar("pyspark.sql.DataFrame")
        | None = None,
        event_time: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | TypeVar("pyspark.sql.DataFrame")
        | None = None,
        serving_keys: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | TypeVar("pyspark.sql.DataFrame")
        | None = None,
        extra_logging_features: pd.DataFrame
        | pl.DataFrame
        | list[list[Any]]
        | list[dict[str, Any]]
        | np.ndarray
        | TypeVar("pyspark.sql.DataFrame")
        | None = None,
        request_id: str | list[str] | None = None,
        write_options: dict[str, Any] | None = None,
        training_dataset_version: int | None = None,
        model: Model | None = None,
        model_name: str | None = None,
        model_version: int | None = None,
    ) -> list[Job] | None:
        """Log features and optionally predictions for the current feature view. The logged features are written periodically to the offline store. If you need it to be available immediately, call `materialize_log`.

        Note:
            If features is a `pyspark.Dataframe`, prediction needs to be provided as columns in the dataframe, values in `predictions` will be ignored.

        Parameters:
            logging_data: The features to be logged, this can contain both transformed features, untransfored features and predictions.
            untransformed_features: The untransformed features to be logged.
            predictions: The predictions to be logged.
            transformed_features: The transformed features to be logged.
            inference_helper_columns: The inference helper columns to be logged.
            request_parameters: The request parameters to be logged.
            event_time: The event time to be logged.
            serving_keys: The serving keys to be logged.
            extra_logging_features:
                Extra features to be logged.
                The features must be specified when enabled logging or while creating the feature view.
            request_id: The request ID that can be used to identify an online inference request.
            write_options: Options for writing the log.
            training_dataset_version:
                Version of the training dataset.
                If training dataset version is definied in `init_serving` or `init_batch_scoring`, or model has training dataset version, or training dataset version was cached, then the version will be used, otherwise defaults to None.
            model: Hopsworks model associated with the log.
            model_name:
                Name of the model to be associated with the log.
                If `model` is provided, this parameter will be ignored.
            model_version:
                Version of the model to be associated with the log.
                If `model` is provided, this parameter will be ignored.

        Returns:
            Job information for feature insertion if python engine is used.

        Example: Implicitly Logging Batch Data and Predictions with all Logging metadata
            ```python

            df = fv.get_batch_data(logging_data=True)
            predictions = model.predict(df)

            # log passed features
            feature_view.log(df, predictions=predictions)
            ```

        Example: Implicitly Logging Feature Vectors and Predictions with all Logging metadata
            ```python

            feature_vector = fv.get_feature_vector({"pk": 1}, logging_data=True)
            predictions = model.predict(feature_vector)

            # log passed features
            feature_view.log(feature_vector, predictions=predictions)
            ```

        Example: Logging DataFrames with Predictions
            ```python

            df = fv.get_batch_data()
            predictions = model.predict(df)

            # log passed features
            feature_view.log(df, predictions=predictions)
            ```

        Example: Explicit Logging of untransformed and transformed Features
            ```python
            serving_keys = [{"pk": 1}]
            untransformed_feature_vector = fv.get_feature_vectors({"pk": 1})
            transformed_feature_vector = fv.transform(untransformed_feature_vector)
            predictions = model.predict(transformed_feature_vector)

            # log both untransformed and transformed features
            feature_view.log(
                untransformed_features=untransformed_feature_vector,
                transformed_features=transformed_feature_vector,
                servings_keys=serving_keys,
                predictions=predictions
            )
            ```

        Raises:
            hopsworks.client.exceptions.RestAPIError: in case the backend fails to log features.
        """
        if not self.logging_enabled:
            warnings.warn(
                "Feature logging is not enabled. It may take longer to enable logging before logging the features. You can call `feature_view.enable_logging()` to enable logging beforehand.",
                stacklevel=1,
            )
            logging_features = (
                self._feature_view_engine._get_logging_feature_from_dataframe(
                    dataframes=[
                        untransformed_features,
                        transformed_features,
                        predictions,
                        logging_data,
                        inference_helper_columns,
                        request_parameters,
                        event_time,
                        serving_keys,
                    ],
                    feature_view_obj=self,
                )
            )
            self.enable_logging(extra_log_columns=logging_features)
        return self._feature_view_engine._log_features(
            self,
            feature_logging=self.feature_logging,
            logs=logging_data,
            untransformed_features=untransformed_features,
            transformed_features=transformed_features,
            predictions=predictions,
            inference_helper_columns=inference_helper_columns,
            request_parameters=request_parameters,
            event_time=event_time,
            serving_keys=serving_keys,
            request_id=request_id,
            write_options=write_options,
            training_dataset_version=(
                training_dataset_version
                or self._serving_training_dataset_version
                or (model.training_dataset_version if model else None)
                or self.get_last_accessed_training_dataset()
            ),
            extra_logging_features=extra_logging_features,
            hsml_model=model,
            logger=self._feature_logger,
            model_name=model_name,
            model_version=model_version,
        )

    @public
    def get_log_timeline(
        self,
        wallclock_time: str | int | datetime | datetime.date | None = None,
        limit: int | None = None,
        transformed: bool | None = False,
    ) -> dict[str, dict[str, str]]:
        """Retrieve the log timeline for the current feature view.

        Parameters:
            wallclock_time: Specific time to get the log timeline for. Can be a string, integer, datetime, or date.
            limit: Maximum number of entries to retrieve.
            transformed: Whether to include transformed logs.

        Example:
            ```python
            # get log timeline
            log_timeline = feature_view.get_log_timeline(limit=10)
            ```

        Returns:
            Dictionary object of commit metadata timeline, where Key is commit id and value is `dict[str, str]` with key value pairs of date committed on, number of rows updated, inserted and deleted.

        Raises:
            hopsworks.client.exceptions.RestAPIError: in case the backend fails to retrieve the log timeline.
        """
        return self._feature_view_engine._get_log_timeline(
            self, wallclock_time, limit, transformed
        )

    @public
    def read_log(
        self,
        start_time: str | int | datetime | datetime.date | None = None,
        end_time: str | int | datetime | datetime.date | None = None,
        filter: Filter | Logic | None = None,
        transformed: bool | None = False,
        training_dataset_version: int | None = None,
        model: Model | None = None,
        model_name: str | None = None,
        model_version: int | None = None,
    ) -> TypeVar("pyspark.sql.DataFrame") | pd.DataFrame | pl.DataFrame:
        """Read the log entries for the current feature view.

        Optionally, filter can be applied to start/end time, training dataset version, hsml model, and custom filter.

        Parameters:
            start_time: Start time for the log entries. Can be a string, integer, datetime, or date.
            end_time: End time for the log entries. Can be a string, integer, datetime, or date.
            filter: Filter to apply on the log entries. Can be a Filter or Logic object.
            transformed: Whether to include transformed logs.
            training_dataset_version: Version of the training dataset.
            model: HSML model associated with the log.
            model_name: Name of the model to filter the log entries. If `model` is provided, this parameter will be ignored.
            model_version: Version of the model to filter the log entries. If `model` is provided, this parameter will be ignored.

        Example:
            ```python
            # read all log entries
            log_entries = feature_view.read_log()
            # read log entries within time ranges
            log_entries = feature_view.read_log(start_time="2022-01-01", end_time="2022-01-31")
            # read log entries of a specific training dataset version
            log_entries = feature_view.read_log(training_dataset_version=1)
            # read log entries of a specific hopsworks model
            log_entries = feature_view.read_log(model=Model(1, "dummy", version=1))
            # read log entries by applying filter on features of feature group `fg` in the feature view
            log_entries = feature_view.read_log(filter=fg.feature1 > 10)
            ```

        Returns:
            The dataframe containing the feature data.

        Raises:
            hopsworks.client.exceptions.RestAPIError: in case the backend fails to read the log entries.
        """
        return self._feature_view_engine._read_feature_logs(
            self,
            start_time,
            end_time,
            filter,
            transformed,
            training_dataset_version,
            model,
            model_name,
            model_version,
        )

    @public
    def pause_logging(self) -> None:
        """Pause scheduled materialization job for the current feature view.

        Example:
            ```python
            # pause logging
            feature_view.pause_logging()
            ```

        Raises:
            hopsworks.client.exceptions.RestAPIError: in case the backend fails to pause feature logging.
        """
        self._feature_view_engine._pause_logging(self)

    @public
    def resume_logging(self) -> None:
        """Resume scheduled materialization job for the current feature view.

        Example:
            ```python
            # resume logging
            feature_view.resume_logging()
            ```

        Raises:
            hopsworks.client.exceptions.RestAPIError: in case the backend fails to pause feature logging.
        """
        self._feature_view_engine._resume_logging(self)

    @public
    def materialize_log(
        self, wait: bool = False, transformed: bool | None = None
    ) -> list[Job]:
        """Materialize the log for the current feature view.

        Parameters:
            wait: Whether to wait for the materialization to complete.
            transformed: Whether to materialize transformed or untrasformed logs. Defaults to None, in which case the returned list contains a job for materialization of transformed features and then a job for untransformed features. Otherwise the list contains only transformed jobs if transformed is True and untransformed jobs if it is False.

        Example:
            ```python
            # materialize log
            materialization_result = feature_view.materialize_log(wait=True)
            ```

        Returns:
            Job information for the materialization jobs of transformed and untransformed features.

        Raises:
            hopsworks.client.exceptions.RestAPIError: in case the backend fails to materialize the log.
        """
        return self._feature_view_engine._materialize_feature_logs(
            self, wait, transformed
        )

    @public
    def delete_log(self, transformed: bool | None = None) -> None:
        """Delete the logged feature data for the current feature view.

        Parameters:
            transformed: Whether to delete transformed logs. Defaults to None. Delete both transformed and untransformed logs.

        Example:
            ```python
            # delete log
            feature_view.delete_log()
            ```

        Raises:
             hopsworks.client.exceptions.RestAPIError: in case the backend fails to delete the log.
        """
        if self.feature_logging is not None:
            self._feature_view_engine._delete_feature_logs(
                self, self.feature_logging, transformed
            )

    @public
    def create_feature_logger(self):
        """Create an asynchronous feature logger for logging features in Hopsworks serving deployments.

        Example:
            ```python
            # get feature logger
            feature_logger = feature_view.create_feature_logger()

            # initialize feature view for serving with feature logger
            feature_view.init_serving(1, feature_logger=feature_logger)

            # log features
            feature_view.log(...)
            ```

        Raises:
            `hopsworks.client.exceptions.FeatureStoreException`: If not running in a Hopsworks serving deployment.
        """
        if (
            "DEPLOYMENT_NAME" not in os.environ
            or "HOPSWORKS_PROJECT_NAME" not in os.environ
        ):
            raise FeatureStoreException(
                "Feature logging only supported in Hopsworks serving deployments"
            )
        from hsfs.feature_logger_async import AsyncFeatureLogger

        return AsyncFeatureLogger(
            project_id=int(client._get_instance()._project_id),
            source="localhost",
            namespace=os.environ["HOPSWORKS_PROJECT_NAME"].replace("_", "-"),
            deployment_name=os.environ["DEPLOYMENT_NAME"],
            max_concurrent_tasks=int(
                os.environ.get("FEATURE_LOGGER_CLIENT_POOL_SIZE", "3")
            ),
            feature_logger_config={
                "timeout": int(
                    os.environ.get("FEATURE_LOGGER_CLIENT_REQ_TIMEOUT", "3")
                ),
            },
        )

    @public
    def execute_odts(
        self,
        data: pd.DataFrame | pl.DataFrame | dict[str, Any],
        online: bool | None = None,
        transformation_context: dict[str, Any] | list[dict[str, Any]] = None,
        request_parameters: dict[str, Any] | list[dict[str, Any]] = None,
        n_processes: int | None = None,
    ) -> dict[str, Any] | pd.DataFrame:
        """Apply on-demand transformations attached to the feature view on the provided data.

        This method allows you to test on-demand transformation functions locally.
        It executes all on-demand transformations (ODTs) attached to the feature view on the input data.

        Example: Testing on-demand transformations
            ```python
            @udf(return_type=float)
            def compute_ratio(amount, quantity):
                return amount / quantity

            fv = fs.get_or_create_feature_view(name="transactions_fv",
                                        version=1,
                                        query=fg.select_features(),
                                        transformation_functions=[compute_ratio("amount", "quantity")])

            # Test with a DataFrame (offline mode)
            test_df = pd.DataFrame({
                "amount": [100.0, 200.0, 300.0],
                "quantity": [2, 4, 5]
            })
            result_df = fv.execute_odts(test_df)

            # Test with a dictionary (single record, online inference simulation)
            test_dict = {"amount": 100.0, "quantity": 2}
            result_dict = fv.execute_odts(test_dict, online=True)
            ```

        Parameters:
            data:
                Input data to apply transformations to.
                This can a dataframe or a dictionary.
            online:
                Whether to apply transformations in online mode (single values) or offline mode (batch/vectorized).
                Defaults to offline mode
            transformation_context:
                A dictionary mapping variable names to objects that provide contextual information to the transformation function at runtime.
                The `context` variables must be defined as parameters in the transformation function for these to be accessible during execution.
                For batch processing with different contexts per row, provide a list of dictionaries.
            request_parameters:
                Request parameters passed to the transformation functions.
                For batch processing with different parameters per row, provide a list of dictionaries.
                These parameters take **highest priority** when resolving feature values -- if a key exists in both `request_parameters` and the input data, the value from `request_parameters` is used.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            The transformed data in the same format as the input:
                - `pd.DataFrame` if input was a DataFrame
                - `dict[str, Any]` if input was a dictionary
        """
        if self._on_demand_transformation_functions:
            data = self._feature_view_engine._apply_transformations(
                execution_graph=self._on_demand_transformation_execution_graph,
                data=data,
                online=online,
                transformation_context=transformation_context,
                request_parameters=request_parameters,
                n_processes=n_processes,
            )
        else:
            _logger.info(
                "No on-demand transformation functions attached to the feature view, no transformations applied."
            )
        return data

    @public
    def execute_mdts(
        self,
        data: pd.DataFrame | pl.DataFrame | dict[str, Any],
        online: bool | None = None,
        transformation_context: dict[str, Any] | list[dict[str, Any]] = None,
        request_parameters: dict[str, Any] | list[dict[str, Any]] = None,
        n_processes: int | None = None,
    ) -> dict[str, Any] | pd.DataFrame:
        """Apply model-dependent transformations attached to the feature view on the provided data.

        This method allows you to test model-dependent transformation functions locally.
        It executes all model-dependent transformations (MDTs) attached to the feature view, using the statistics computed from training data.

        Example: Testing model-dependent transformations with statistics
            ```python
            from hsfs.transformation_statistics import TransformationStatistics

            @udf(return_type=float)
            def normalize(amount, statistics=TransformationStatistics("amount")):
                return (amount - statistics.amount.mean) / statistics.amount.std_dev

            fv = fs.get_or_create_feature_view(name="transactions_fv",
                                        version=1,
                                        query=fg.select_features(),
                                        transformation_functions=[normalize("amount")])

            # Create training data for training dataset statistics
            # Alternatively you can initialize the feature view with statistics of previously created training data using `init_batch_scoring` or `init_serving`.
            features, labels = fv.create_training_data()

            # Testing with a DataFrame
            test_df = pd.DataFrame({"amount": [100.0, 200.0, 300.0]})
            result_df = fv.execute_mdts(test_df)

            # Testing with a dictionary (online inference simulation)
            test_dict = {"amount": 100.0}
            result_dict = fv.execute_mdts(test_dict, online=True)
            ```

        Parameters:
            data:
                Input data to apply transformations to.
                This can a dataframe or a dictionary.
            online:
                Whether to apply transformations in online mode (single values) or offline mode (batch/vectorized).
                Defaults to offline mode.
            transformation_context:
                A dictionary mapping variable names to objects that provide contextual information to the transformation function at runtime.
                The `context` variables must be defined as parameters in the transformation function for these to be accessible during execution.
                For batch processing with different contexts per row, provide a list of dictionaries.
            request_parameters:
                Request parameters passed to the transformation functions.
                For batch processing with different parameters per row, provide a list of dictionaries.
                These parameters take **highest priority** when resolving feature values -- if a key exists in both `request_parameters` and the input data, the value from `request_parameters` is used.
            n_processes: Number of worker processes used to apply transformation functions in parallel.
                Independent transformations run concurrently; a chained sequence runs in order.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine, which pushes transformations down to Spark.

        Returns:
            The transformed data in the same format as the input:
                - `pd.DataFrame` if input was a DataFrame
                - `dict[str, Any]` if input was a dictionary
        """
        if self.transformation_functions:
            data = self._feature_view_engine._apply_transformations(
                execution_graph=self._model_dependent_transformation_execution_graph,
                data=data,
                online=online,
                transformation_context=transformation_context,
                request_parameters=request_parameters,
                n_processes=n_processes,
            )
        else:
            _logger.info(
                "No model dependent transformation functions attached to the feature view, no transformations applied."
            )
        return data

    def __getattr__(self, name: str) -> Any:
        try:
            return self.__getitem__(name)
        except KeyError as err:
            raise AttributeError(
                f"'FeatureView' object has no attribute '{name}'. "
            ) from err

    def __getitem__(self, name: str):
        if not isinstance(name, str):
            raise TypeError(
                f"Expected type `str`, got `{type(name)}`. "
                "Transformations are accessible by name."
            )
        transformations = [
            tf.hopsworks_udf
            for tf in self.__getattribute__("transformation_functions")
            + self.__getattribute__("_on_demand_transformation_functions")
            if tf.hopsworks_udf.function_name == name
        ]
        if len(transformations) == 1:
            return transformations[0]
        raise KeyError(
            f"'FeatureView' object has no transformation function called '{name}'."
        )

    @staticmethod
    def _update_attribute_if_present(this: FeatureView, new: Any, key: str) -> None:
        if getattr(new, key):
            setattr(this, key, getattr(new, key))

    def _init_feature_monitoring_engine(self) -> None:
        self._feature_monitoring_config_engine = (
            feature_monitoring_config_engine.FeatureMonitoringConfigEngine(
                feature_store_id=self._featurestore_id,
                feature_view_name=self._name,
                feature_view_version=self._version,
            )
        )
        self._feature_monitoring_result_engine = (
            feature_monitoring_result_engine.FeatureMonitoringResultEngine(
                feature_store_id=self._featurestore_id,
                feature_view_name=self._name,
                feature_view_version=self._version,
            )
        )

    def json(self) -> str:
        """Convert class into its JSON serialized form.

        Returns:
            JSON serialized object.
        """
        return json.dumps(self, cls=util.Encoder)

    def to_dict(self) -> dict[str, Any]:
        """Convert class into a dictionary.

        Returns:
            Dictionary that contains all data required to JSON serialize the object.
        """
        fv_dict = {
            "featurestoreId": self._featurestore_id,
            "name": self._name,
            "version": self._version,
            "description": self._description,
            "query": self._query,
            "features": self._features,
            "loggingEnabled": self._logging_enabled,
            "transformationFunctions": self._transformation_functions,
            "type": "featureViewDTO",
            "extraLogColumns": self._extra_log_columns,
        }
        tags_dict = tag.Tag._tags_to_dict(self._tags)
        if tags_dict:
            fv_dict["tags"] = tags_dict
        return fv_dict

    @public
    def get_training_dataset_schema(
        self, training_dataset_version: int | None = None
    ) -> list[training_dataset_feature.TrainingDatasetFeature]:
        """Function that returns the schema of the training dataset that is generated from a feature view.

        It provides the schema of the features after all transformation functions have been applied.

        Parameters:
            training_dataset_version:
                Specifies the version of the training dataset for which the schema should be generated.
                By default, this is set to None.
                However, if the `one_hot_encoder` transformation function is used, the training dataset version must be provided.
                This is because the schema will then depend on the statistics of the training data used.

        Example:
            ```python
            schema = feature_view.get_training_dataset_schema(training_dataset_version=1)
            ```

        Returns:
            List of training dataset features objects.
        """
        return self._feature_view_engine._get_training_dataset_schema(
            self, training_dataset_version
        )

    @public
    @property
    def id(self) -> int:
        """Feature view id."""
        return self._id

    @id.setter
    def id(self, id: int | None) -> None:
        self._id = id

    @public
    @property
    def featurestore_id(self) -> int:
        """Feature store id."""
        return self._featurestore_id

    @featurestore_id.setter
    def featurestore_id(self, id: int | None) -> None:
        self._featurestore_id = id

    @public
    @property
    def feature_store_name(self) -> str | None:
        """Name of the feature store in which the feature group is located."""
        return self._feature_store_name

    @public
    @property
    def name(self) -> str:
        """Name of the feature view."""
        return self._name

    @name.setter
    def name(self, name: str) -> None:
        self._name = name

    @public
    @property
    def version(self) -> int:
        """Version number of the feature view."""
        return self._version

    @version.setter
    def version(self, version: int) -> None:
        self._version = version

    @property
    def missing_mandatory_tags(self) -> list[dict[str, Any]]:
        """List of missing mandatory tags for the feature view."""
        return self._missing_mandatory_tags

    @public
    @property
    def labels(self) -> list[str]:
        """The labels/prediction feature of the feature view.

        Can be a composite of multiple features.
        """
        return self._labels

    @labels.setter
    def labels(self, labels: list[str]) -> None:
        self._labels = [util._autofix_feature_name(lb) for lb in labels]

    @public
    @property
    def inference_helper_columns(self) -> list[str]:
        """The helper column sof the feature view.

        Can be a composite of multiple features.
        """
        return self._inference_helper_columns

    @inference_helper_columns.setter
    def inference_helper_columns(self, inference_helper_columns: list[str]) -> None:
        self._inference_helper_columns = [
            util._autofix_feature_name(exf) for exf in inference_helper_columns
        ]

    @public
    @property
    def training_helper_columns(self) -> list[str]:
        """The helper column sof the feature view.

        Can be a composite of multiple features.
        """
        return self._training_helper_columns

    @training_helper_columns.setter
    def training_helper_columns(self, training_helper_columns: list[str]) -> None:
        self._training_helper_columns = [
            util._autofix_feature_name(exf) for exf in training_helper_columns
        ]

    @public
    @property
    def description(self) -> str | None:
        """Description of the feature view."""
        return self._description

    @description.setter
    def description(self, description: str | None) -> None:
        self._description = description

    @public
    @property
    def query(self) -> query.Query:
        """Query of the feature view."""
        return self._query

    @query.setter
    def query(self, query_obj: query.Query) -> None:
        self._query = query_obj

    @public
    def get_feature(self, name: str) -> Feature:
        """Return a Feature for `name` (bare or join-prefixed) from this FV's query.

        Delegates to `self.query.get_feature(...)`.
        The returned Feature carries its feature_group, so it can be passed
        directly into `extra_filter` on `get_batch_data` / `get_batch_query`:

            fv.get_batch_data(extra_filter=(fv.get_feature("amount") > 100))

        For joined feature views, accepts either the bare name (resolves to
        the left FG if it owns the feature, else the first joined match) or
        the join-prefixed name (e.g. `"customers_1_customer_id"`) for an
        unambiguous lookup.

        Parameters:
            name: Feature name.
                Use a bare name when the feature is unambiguous.
                Use the join-prefixed form (e.g. `"customers_1_customer_id"`)
                when the feature view joins multiple feature groups that
                share the column.

        Returns:
            The `Feature` from the feature view's query, with its feature
            group attached so it can be used directly in `extra_filter`.

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: if `name`
                is not in the feature view's query, or is ambiguous across
                joined feature groups and no prefix was used.
        """
        return self._query.get_feature(name)

    @public
    @property
    def transformation_functions(
        self,
    ) -> list[TransformationFunction]:
        """Get transformation functions."""
        return self._transformation_functions

    @transformation_functions.setter
    def transformation_functions(
        self,
        transformation_functions: list[TransformationFunction],
    ) -> None:
        self._transformation_functions = transformation_functions
        # Reassigning the TF list must rebuild the execution DAG; otherwise
        # subsequent calls use a stale graph and a stale topological order.
        # A cyclic configuration is rejected here, when the DAG is rebuilt.
        self._model_dependent_transformation_execution_graph = (
            transformation_execution_dag.TransformationExecutionDAG(
                transformation_functions,
            )
        )

    @public
    @property
    def model_dependent_transformations(self) -> dict[str, Callable]:
        """Get Model-Dependent transformations as a dictionary mapping transformed feature names to transformation function."""
        return {
            transformation_function.hopsworks_udf.output_column_names[
                0
            ]: transformation_function.hopsworks_udf._get_udf()
            for transformation_function in self.transformation_functions
        }

    @public
    @property
    def on_demand_transformations(self) -> dict[str, Callable]:
        """Get On-Demand transformations as a dictionary mapping on-demand feature names to transformation function."""
        return {
            feature.on_demand_transformation_function.hopsworks_udf.function_name: feature.on_demand_transformation_function.hopsworks_udf._get_udf()
            for feature in self.features
            if feature.on_demand_transformation_function
        }

    @property
    def _on_demand_transformation_functions(self) -> list[TransformationFunction]:
        """Get all on-demand transformations in the feature view.

        When the backend serializes the complete chain it is used directly: it
        includes the producers of dropped intermediates, which surface no
        feature and so cannot be recovered from per-feature attachments.

        The fallback (older backends that omit the list) reconstructs from the
        features. A multi-output TF appears on every feature it produces, so the
        raw collection contains duplicates. Dedup by `__eq__` (which compares the
        serialized TF) and preserve the first occurrence so downstream DAG
        construction sees each TF exactly once. This fallback cannot recover the
        producers of dropped intermediates, which surface no feature.
        """
        if self.__on_demand_transformation_functions is not None:
            return self.__on_demand_transformation_functions
        seen: list[TransformationFunction] = []
        for feature in self.features:
            tf = feature.on_demand_transformation_function
            if tf and tf not in seen:
                seen.append(tf)
        return seen

    @public
    @property
    def request_parameters(self) -> list[str]:
        """Get request parameters required for the for on-demand transformations atatched to the feature view."""
        if self._request_parameters is None:
            feature_names = [feature.name for feature in self.features]
            # Intermediate features: outputs of one TF that are inputs to
            # another. These are computed by the transformation chain and
            # should not be listed as required request parameters.
            all_output_cols: set[str] = set()
            for tf in self._on_demand_transformation_functions:
                all_output_cols.update(tf.hopsworks_udf.output_column_names)
            self._request_parameters = []
            for tf in self._on_demand_transformation_functions:
                for feature_name in tf.hopsworks_udf.transformation_features:
                    if (
                        feature_name not in feature_names
                        and feature_name not in self._request_parameters
                        and feature_name not in all_output_cols
                    ):
                        self._request_parameters.append(feature_name)

        return self._request_parameters

    @public
    @property
    def schema(self) -> list[training_dataset_feature.TrainingDatasetFeature]:
        """Schema of untransformed features in the Feature view."""
        return self._features

    @public
    @property
    def features(self) -> list[training_dataset_feature.TrainingDatasetFeature]:
        """Schema of untransformed features in the Feature view. (alias)."""
        return self._features

    @schema.setter
    def schema(
        self, features: list[training_dataset_feature.TrainingDatasetFeature]
    ) -> None:
        self._features = features

    @public
    @property
    def primary_keys(self) -> set[str]:
        """Set of primary key names that is required as keys in input dict object for [`FeatureView.get_feature_vector`][hsfs.feature_view.FeatureView.get_feature_vector] method.

        When there are duplicated primary key names and prefix is not defined in the query,
        prefix is generated and prepended to the primary key name in this format
        "fgId_{feature_group_id}_{join_index}" where `join_index` is the order of the join.
        """
        if not (hasattr(self, "_primary_keys") and len(self._primary_keys) > 0):
            self._primary_keys = {key.required_serving_key for key in self.serving_keys}
        return self._primary_keys

    @public
    @property
    def serving_keys(self) -> list[skm.ServingKey]:
        """All primary keys of the feature groups included in the query."""
        if (
            (not hasattr(self, "_serving_keys"))
            or self._serving_keys is None
            or len(self._serving_keys) == 0
        ):
            self._serving_keys = util._build_serving_keys_from_prepared_statements(
                self._feature_view_engine._feature_view_api._get_serving_prepared_statement(
                    name=self.name,
                    version=self.version,
                    batch=False,
                    inference_helper_columns=False,
                ),
                feature_store_id=self.featurestore_id,
                ignore_prefix=True,  # if serving_keys have to be built it is because feature_view older than 3.3, this ensure compatibility
            )
        return self._serving_keys

    @serving_keys.setter
    def serving_keys(self, serving_keys: list[skm.ServingKey]) -> None:
        self._serving_keys = serving_keys

    @public
    @property
    def logging_enabled(self) -> bool:
        """Whether feature logging is enabled for the feature view."""
        return self._logging_enabled

    @logging_enabled.setter
    def logging_enabled(self, logging_enabled) -> None:
        self._logging_enabled = logging_enabled

    @public
    @property
    def feature_logging(self) -> FeatureLogging | None:
        """Feature logging feature groups of this feature view."""
        if self.logging_enabled and self._feature_logging is None:
            self._feature_logging = self._feature_view_engine._get_feature_logging(self)
        return self._feature_logging

    def _get_spine_fg_ids(self) -> list[feature_group.SpineGroup]:
        return [
            fg.id
            for fg in self.query.featuregroups
            if isinstance(fg, feature_group.SpineGroup)
        ]

    def _get_skip_fg_ids(self) -> set[int]:
        embedding_fg_ids = [fg.id for fg in self._get_embedding_fgs()]
        return set(embedding_fg_ids + self._get_spine_fg_ids())

    @property
    def _vector_server(self) -> vector_server.VectorServer:
        if not self.__vector_server:
            self.__vector_server = vector_server.VectorServer(
                feature_store_id=self._featurestore_id,
                features=self._features,
                serving_keys=self._serving_keys,
                skip_fg_ids=self._get_skip_fg_ids(),
                skip_feature_decoding_fg_ids=self._get_spine_fg_ids(),
                feature_view_name=self._name,
                feature_view_version=self._version,
                feature_store_name=self._feature_store_name,
            )
        return self.__vector_server

    @property
    def _batch_scoring_server(self) -> vector_server.VectorServer:
        if not self.__batch_scoring_server:
            self.__batch_scoring_server = vector_server.VectorServer(
                feature_store_id=self._featurestore_id,
                features=self._features,
                serving_keys=self._serving_keys,
                skip_fg_ids=self._get_skip_fg_ids(),
                skip_feature_decoding_fg_ids=self._get_spine_fg_ids(),
                feature_view_name=self._name,
                feature_view_version=self._version,
                feature_store_name=self._feature_store_name,
            )
        return self.__batch_scoring_server

    @property
    def _fully_qualified_primary_keys(self) -> list[str]:
        """Get name for primary key with fully qualified names from the feature view."""
        if not self.__fully_qualified_primary_keys:
            self.__fully_qualified_primary_keys = (
                self._feature_view_engine._get_primary_keys_from_query(self.query)
            )
        return self.__fully_qualified_primary_keys

    @property
    def _fully_qualified_event_time(self) -> list[str]:
        """Get fully qualified names for applicable event time from the feature view."""
        if not self.__fully_qualified_event_time:
            self.__fully_qualified_event_time = (
                self._feature_view_engine._get_eventtimes_from_query(self.query)
            )
        return self.__fully_qualified_event_time

    @property
    def _label_column_names(self) -> set[str]:
        """Get label column names."""
        if self.__label_column_names is None:
            training_dataset_schema = self.get_training_dataset_schema()
            self.__label_column_names = {
                feature.name for feature in training_dataset_schema if feature.label
            }
        return self.__label_column_names

    @property
    def _transformed_feature_names(self) -> list[str]:
        """Get transformed feature names."""
        if self.__transformed_feature_names is None:
            training_dataset_schema = self.get_training_dataset_schema()
            self.__transformed_feature_names = [
                feature.name
                for feature in training_dataset_schema
                if feature.name not in self._label_column_names
                and feature.name not in self.training_helper_columns
                and feature.name not in self.inference_helper_columns
            ]
        return self.__transformed_feature_names

    @property
    def _untransformed_feature_names(self) -> list[str]:
        """Get untransformed feature names."""
        if self.__untransformed_feature_names is None:
            self.__untransformed_feature_names = [
                feature.name
                for feature in self.features
                if feature.name not in self._label_column_names
                and feature.name not in self.training_helper_columns
                and feature.name not in self.inference_helper_columns
            ]
        return self.__untransformed_feature_names

    @property
    def _required_serving_key_names(self) -> list[str]:
        """Get required serving key names."""
        if self.__required_serving_key_names is None:
            self.__required_serving_key_names = [
                sk.feature_name for sk in self.serving_keys if sk.required
            ]
        return self.__required_serving_key_names

    @property
    def _root_feature_group_event_time_column_name(self) -> str | None:
        """Get event time column name of the root feature group in the feature view."""
        return self.query._left_feature_group.event_time

    @property
    def _extra_logging_column_names(self) -> list[str]:
        """Get extra logging column names used for feature logging."""
        if self.__extra_logging_column_names is None:
            self.__extra_logging_column_names = (
                [f.name for f in self.feature_logging.extra_logging_columns]
                if self.feature_logging.extra_logging_columns
                else []
            )
        return self.__extra_logging_column_names

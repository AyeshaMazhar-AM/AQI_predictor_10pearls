#
#   Copyright 2024 Hopsworks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

import ast
import copy
import inspect
import json
import logging
import re
import warnings
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date, datetime, time
from enum import Enum
from typing import TYPE_CHECKING, Any, Literal

import humps
from hopsworks_apigen import public
from hopsworks_common import client
from hopsworks_common.client.exceptions import FeatureStoreException
from hopsworks_common.constants import FEATURES
from hopsworks_common.version import __version__ as current_version
from hsfs import engine, util
from hsfs.decorators import typechecked
from hsfs.transformation_statistics import TransformationStatistics
from packaging.version import Version


if TYPE_CHECKING:
    import pandas as pd
    from hsfs.core.feature_descriptive_statistics import FeatureDescriptiveStatistics

_logger = logging.getLogger(__name__)


class UDFExecutionMode(Enum):
    """Class that store the possible execution types of UDF's."""

    DEFAULT = "default"
    PYTHON = "python"
    PANDAS = "pandas"

    def _get_current_execution_mode(self, online):
        if self == UDFExecutionMode.DEFAULT and online:
            return UDFExecutionMode.PYTHON
        if self == UDFExecutionMode.DEFAULT and not online:
            return UDFExecutionMode.PANDAS
        return self

    @staticmethod
    def from_string(execution_mode: str):
        try:
            return UDFExecutionMode[execution_mode.upper()]
        except KeyError as e:
            raise FeatureStoreException(
                f"Ivalid execution mode `{execution_mode}` for UDF. Please use `default`, `python` or `pandas` instead."
            ) from e


class UDFKeyWords(Enum):
    """Class that stores the keywords used as arguments in a UDFs."""

    STATISTICS = "statistics"
    CONTEXT = "context"


@public
def udf(
    return_type: list[type] | type,
    drop: str | list[str] | None = None,
    mode: Literal["default", "python", "pandas"] = "default",
) -> HopsworksUdf:
    """Create an User Defined Function that can be and used within the Hopsworks Feature Store to create transformation functions.

    Hopsworks UDF's are user defined functions that executes as 'pandas_udf' when executing in spark engine and as pandas functions in the python engine.
    The pandas udf/pandas functions gets as inputs pandas Series's and can provide as output a pandas Series or a pandas DataFrame.
    A Hopsworks udf is defined using the `hopsworks_udf` decorator.
    The outputs of the defined UDF must be mentioned in the decorator as a list of python types.


    Example:
        ```python
        from hopsworks import udf

        @udf(float)
        def add_one(data1):
            return data1 + 1
        ```

    Parameters:
        return_type: The output types of the defined UDF.
        drop: The features to be dropped after application of transformation functions.
        mode: The exection mode of the UDF.

    Returns:
        The metadata object for hopsworks UDF's.

    Raises:
        hopsworks.client.exceptions.FeatureStoreException: If unable to create UDF.
    """

    def wrapper(func: Callable) -> HopsworksUdf:
        return HopsworksUdf(
            func=func,
            return_types=return_type,
            dropped_argument_names=drop,
            execution_mode=UDFExecutionMode.from_string(mode),
        )

    return wrapper


@public
@dataclass
class TransformationFeature:
    """Mapping of feature names to their corresponding statistics argument names in the code.

    The statistic_argument_name for a feature name would be None if the feature does not need statistics.

    Parameters:
        feature_name: Name of the feature.
        statistic_argument_name: Name of the statistics argument in the code for the feature specified in the feature name.
    """

    feature_name: str
    statistic_argument_name: str | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "feature_name": self.feature_name,
            "statistic_argument_name": self.statistic_argument_name,
        }


@public
@typechecked
class HopsworksUdf:
    """Meta data for user defined functions.

    Stores meta data required to execute the user defined function in both spark and python engine.
    The class generates uses the metadata to dynamically generate user defined functions based on the engine it is executed in.

    Parameters:
        func: The transformation function object or the source code of the transformation function.
        return_types: A python type or a list of python types that denotes the data types of the columns output from the transformation functions.
        name: Name of the transformation function.
        transformation_features: A list of objects of `TransformationFeature` that maps the feature used for transformation to their corresponding statistics argument names if any.
        transformation_function_argument_names: The argument names of the transformation function.
        dropped_argument_names: The arguments to be dropped from the finial DataFrame after the transformation functions are applied.
        dropped_feature_names: The feature name corresponding to the arguments names that are dropped.
        feature_name_prefix: Prefixes if any used in the feature view.
        output_column_names: The names of the output columns returned from the transformation function.
        generate_output_col_names: Generate default output column names for the transformation function.
    """

    # Mapping for converting python types to spark types - required for creating pandas UDF's.
    PYTHON_SPARK_TYPE_MAPPING = {
        str: "string",
        int: "bigint",
        float: "double",
        bool: "boolean",
        datetime: "timestamp",
        time: "timestamp",
        date: "date",
    }

    def __init__(
        self,
        func: Callable | str,
        return_types: list[type] | type | list[str] | str,
        execution_mode: UDFExecutionMode,
        name: str | None = None,
        transformation_features: list[TransformationFeature] | None = None,
        transformation_function_argument_names: list[str] | None = None,
        dropped_argument_names: list[str] | None = None,
        dropped_feature_names: list[str] | None = None,
        feature_name_prefix: str | None = None,
        output_column_names: str | None = None,
        generate_output_col_names: bool = True,
    ):
        self._return_types: list[str] = HopsworksUdf._validate_and_convert_output_types(
            return_types
        )

        self._execution_mode: UDFExecutionMode = execution_mode

        self._feature_name_prefix: str | None = (
            feature_name_prefix  # Prefix to be added to feature names
        )

        self._function_name: str = func.__name__ if name is None else name

        self._function_source: str = (
            HopsworksUdf._extract_source_code(func)
            if isinstance(func, Callable)
            else func
        )

        # The parameter `output_column_names` is initialized lazily.
        # It is only initialized if the output column names are retrieved from the backend or explicitly specified using the `alias` function or is initialized with default column names if the UDF is accessed from a transformation function.
        # Output column names are only stored in the backend when a model dependent or on demand transformation function is created using the defined UDF.
        self._output_column_names: list[str] = []

        # Lazily initialized property caches: computed on first access, invalidated by setters.
        self._cached_output_column_names: list[str] | None = None
        self._cached_transformation_features: list[str] | None = None
        self._cached_unprefixed_transformation_features: list[str] | None = None
        self._cached_dropped_features: list[str] | None = None

        if not transformation_features:
            # New transformation function being declared so extract source code from function
            self._transformation_features: list[TransformationFeature] = (
                transformation_features
                if transformation_features
                else HopsworksUdf._extract_function_arguments(func)
            )

            self._transformation_function_argument_names = [
                feature.feature_name for feature in self._transformation_features
            ]

            self._dropped_argument_names: list[str] = (
                HopsworksUdf._validate_and_convert_drop_features(
                    dropped_argument_names,
                    self.transformation_features,
                    feature_name_prefix,
                )
            )
            self._dropped_features = self._dropped_argument_names

        else:
            self._transformation_features = transformation_features
            self._transformation_function_argument_names = (
                transformation_function_argument_names
            )
            self._dropped_argument_names = dropped_argument_names
            self._dropped_features = (
                dropped_feature_names
                if dropped_feature_names
                else dropped_argument_names
            )
            self._output_column_names = (
                output_column_names if output_column_names else []
            )

        self._formatted_function_source, self._module_imports = (
            HopsworksUdf._format_source_code(self._function_source)
        )

        self._statistics: TransformationStatistics | None = None

        self._transformation_context: dict[str, Any] = {}

        # Cache for compiled UDF wrapper functions: (execution_mode, engine_type, online, return_types) -> (wrapper_fn, scope)
        self._udf_cache: dict[tuple, tuple[Callable, dict]] = {}
        self._return_types_tuple: tuple | None = None

        # Denote if the output feature names have to be generated.
        # Set to `False` if the output column names are saved in the backend and the udf is constructed from it using `from_response_json` function or if user has specified the output feature names using the `alias`` function.
        self._generate_output_col_name: bool = generate_output_col_names

    def __getstate__(self):
        """Exclude _udf_cache and property caches from pickling.

        Cached wrapper functions are dynamically exec'd and not picklable by reference.
        """
        state = self.__dict__.copy()
        state["_udf_cache"] = {}
        state["_cached_output_column_names"] = None
        state["_cached_transformation_features"] = None
        state["_cached_unprefixed_transformation_features"] = None
        state["_cached_dropped_features"] = None
        state["_return_types_tuple"] = None
        return state

    @staticmethod
    def _validate_and_convert_drop_features(
        dropped_features: str | list[str],
        transformation_feature: list[str],
        feature_name_prefix: str,
    ) -> list[str]:
        """Function that converts dropped features to a list and validates if the dropped feature is present in the transformation function.

        Parameters:
            dropped_features: Features of be dropped.
            transformation_feature: Features to be transformed in the UDF.

        Returns:
            A list of features to be dropped.
        """
        if not dropped_features:
            return None

        dropped_features = (
            [dropped_features]
            if not isinstance(dropped_features, list)
            else dropped_features
        )

        feature_name_prefix = feature_name_prefix if feature_name_prefix else ""

        missing_drop_features = []
        for dropped_feature in dropped_features:
            dropped_feature = feature_name_prefix + dropped_feature
            if dropped_feature not in transformation_feature:
                missing_drop_features.append(dropped_feature)

        if missing_drop_features:
            missing_drop_features = "', '".join(missing_drop_features)
            raise FeatureStoreException(
                f"Cannot drop features '{missing_drop_features}' as they are not features given as arguments in the defined UDF."
            )

        return dropped_features

    @staticmethod
    def _validate_and_convert_output_types(
        output_types: list[type] | list[str],
    ) -> list[str]:
        """Function that takes in a type or list of types validates if it is supported and return a list of strings.

        Parameters:
            output_types: List of python types.

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: If any of the output type is invalid.
        """
        convert_output_types = []
        output_types = (
            output_types if isinstance(output_types, list) else [output_types]
        )
        for output_type in output_types:
            if (
                output_type not in HopsworksUdf.PYTHON_SPARK_TYPE_MAPPING
                and output_type not in HopsworksUdf.PYTHON_SPARK_TYPE_MAPPING.values()
            ):
                raise FeatureStoreException(
                    f"Output type {output_type} is not supported. Please refer to the documentation to get more information on the supported types."
                )
            convert_output_types.append(
                output_type
                if isinstance(output_type, str)
                else HopsworksUdf.PYTHON_SPARK_TYPE_MAPPING[output_type]
            )
        return convert_output_types

    @staticmethod
    def _get_module_imports(path: str) -> list[str]:
        """Function that extracts the imports used in the python file specified in the path.

        Parameters:
            path: Path to python file from which imports are to be extracted.

        Returns:
            A list of string that contains the import statement using in the file.
        """
        imports = []
        with open(path) as fh:
            root = ast.parse(fh.read(), path)
        for node in ast.iter_child_nodes(root):
            if isinstance(node, ast.Import):
                imported_module = False
            elif isinstance(node, ast.ImportFrom):
                imported_module = node.module
            else:
                continue
            for n in node.names:
                if imported_module:
                    import_line = "from " + imported_module + " import " + n.name
                elif n.asname:
                    import_line = "import " + n.name + " as " + n.asname
                else:
                    import_line = "import " + n.name
                imports.append(import_line)
        return imports

    @staticmethod
    def _extract_source_code(udf_function: Callable) -> str:
        """Function to extract the source code of the function along with the imports used in the file.

        The module imports cannot be extracted if the function is defined in a jupyter notebook.

        Parameters:
            udf_function: Function for which the source code must be extracted.

        Returns:
            A string that contains the source code of function along with the extracted module imports.
        """
        try:
            module_imports = HopsworksUdf._get_module_imports(
                inspect.getfile(udf_function)
            )
        except FileNotFoundError:
            module_imports = [""]
            warnings.warn(
                "Cannot extract imported dependencies for the UDF from the module in which it is defined. Please make sure to import all dependencies for the UDF inside the function.",
                stacklevel=2,
            )

        function_code = inspect.getsource(udf_function)
        return "\n".join(module_imports) + "\n" + function_code

    @staticmethod
    def _parse_function_signature(source_code: str) -> tuple[list[str], str, int, int]:
        """Function to parse the source code to extract the argument along with the start and end line of the function signature.

        Parameters:
            source_code: Source code of a function.

        Returns:
            list[str]: List of function arguments.
            str: Function signature.
            int: Starting line number of function signature.
            int: Ending line number of function signature.
        """
        source_code = source_code.split("\n")

        signature_start_line = None
        signature_end_line = None
        # Find the line where the function signature is defined
        for i, line in enumerate(source_code):
            if line.strip().startswith("def "):
                signature_start_line = i
            if signature_start_line is not None and re.search(
                r"\)\s*(->.*)?\s*:$", line.split("#")[0].strip()
            ):
                signature_end_line = i
                break

        # Parse the function signature to remove the specified argument
        signature = "".join(
            [
                code.split("#")[0]
                for code in source_code[signature_start_line : signature_end_line + 1]
            ]
        )
        arg_list = signature.split("(")[1].split(")")[0].split(",")
        arg_list = [
            arg.split(":")[0].split("=")[0].strip()
            for arg in arg_list
            if arg.strip() != ""
        ]

        # Extracting keywords like `context`and `statistics` from the function signature.
        keyword_to_remove = [keyword.value for keyword in UDFKeyWords]
        arg_list = [arg for arg in arg_list if arg not in keyword_to_remove]

        return arg_list, signature, signature_start_line, signature_end_line

    @staticmethod
    def _extract_function_arguments(function: Callable) -> list[TransformationFeature]:
        """Function to extract the argument names from a provided function source code.

        Parameters:
            source_code: The function for which the value are to be extracted.

        Returns:
            List of TransformationFeature that provide a mapping from feature names to corresponding statistics parameters if any is present.
        """
        arg_list = []
        statistics = None
        signature = inspect.signature(function).parameters
        if not signature:
            raise FeatureStoreException(
                "No arguments present in the provided user defined function. Please provide at least one argument in the defined user defined function."
            )

        # Extracting keywords like `context`and `statistics` from the function signature.
        for arg in inspect.signature(function).parameters.values():
            # Fetching default value for statistics parameter to find argument names that require statistics.
            if arg.name == UDFKeyWords.STATISTICS.value:
                statistics = arg.default
            elif arg.name != UDFKeyWords.CONTEXT.value:
                arg_list.append(arg.name)

        if statistics:
            missing_statistic_features = [
                statistic_feature
                for statistic_feature in statistics._features
                if statistic_feature not in arg_list
            ]
            if missing_statistic_features:
                missing_statistic_features = "', '".join(missing_statistic_features)
                raise FeatureStoreException(
                    f"No argument corresponding to statistics parameter '{missing_statistic_features}' present in function definition."
                )
            return [
                TransformationFeature(arg, arg if arg in statistics._features else None)
                for arg in arg_list
            ]
        return [TransformationFeature(arg, None) for arg in arg_list]

    @staticmethod
    def _format_source_code(source_code: str) -> tuple[str, str]:
        """Function that parses the existing source code to remove statistics parameter and remove all decorators and type hints from the function source code.

        Parameters:
            source_code: Source code of a function.

        Returns:
            Tuple that contains Source code that does not contain any decorators, type hints or statistics parameters and the module imports
        """
        arg_list, signature, _, signature_end_line = (
            HopsworksUdf._parse_function_signature(source_code)
        )
        module_imports = source_code.split("@")[0]

        # Reconstruct the function signature
        new_signature = (
            signature.split("(")[0].strip() + "(" + ", ".join(arg_list) + "):"
        )
        source_code = source_code.split("\n")
        # Reconstruct the modified function as a string
        modified_source = (
            new_signature + "\n\t" + "\n\t".join(source_code[signature_end_line + 1 :])
        )

        return modified_source, module_imports

    def _create_pandas_udf_return_schema_from_list(self) -> str:
        """Function that creates the return schema required for executing the defined UDF's as pandas UDF's in Spark.

        Returns:
            DDL-formatted type string that denotes the return types of the user defined function.
        """
        if len(self.return_types) > 1:
            return ", ".join(
                [
                    f"`{self.output_column_names[i]}` {self.return_types[i]}"
                    for i in range(len(self.return_types))
                ]
            )
        return self.return_types[0]

    def _prepare_transformation_function_scope(self, **kwargs) -> dict[str, Any]:
        """Function that prepares the scope for the transformation function to be executed.

        This scope would include any variable that are required to be injected into the transformation function.

        By default the output column names, transformation statistics and transformation context are injected into the scope if they are required by the transformation function.
        Any additional arguments can be passed as kwargs.

        Note: under `fork` the worker inherits the user's interactive
        `__main__` so notebook globals are visible. Under `forkserver` or
        `spawn` (configurable via `HOPSWORKS_TF_POOL_START_METHOD`) the worker's
        `__main__` is the bootstrap module, not the user's notebook session,
        and UDFs referencing notebook globals will NameError there. This is a
        known limitation of non-fork start methods and applies regardless of
        the scope-build policy here.
        """
        # The wrapper inlines the UDF source via self._formatted_function_source
        # and recompiles it with exec(code, scope). Any non-import name the user
        # referenced from the enclosing scope (notebook globals, module-level
        # constants) is resolved against this dict at runtime, so the scope
        # must include __main__ globals. Restricting to {"__builtins__": ...}
        # raises NameError on UDFs that reference notebook constants.
        scope = __import__("__main__").__dict__.copy()

        # Adding variables required to be injected into the scope.
        variables_to_inject = {
            UDFKeyWords.STATISTICS.value: self.transformation_statistics,
            UDFKeyWords.CONTEXT.value: self.transformation_context,
            "_output_col_names": self.output_column_names,
        }
        variables_to_inject.update(**kwargs)

        # Injecting variables that have a value into scope.
        scope.update({k: v for k, v in variables_to_inject.items() if v is not None})

        return scope

    def _python_udf_wrapper(self, rename_outputs) -> tuple[Callable, dict]:
        """Function that creates a dynamic wrapper function for the defined udf.

        The wrapper function would be used to specify column names, in spark engines and to localize timezones.

        The renames is done so that the column names match the schema expected by spark when multiple columns are returned in a spark udf.
        The wrapper function would be available in the main scope of the program.

        Parameters:
            rename_outputs:
                Whether to rename the output columns to the names specified in `output_column_names`.
                This should be set to `True` when the udf is executed in spark engine.

        Returns:
            A tuple of (wrapper_function, scope_dict) where scope_dict can be updated
            to inject new runtime values (statistics, context, output_col_names).
        """
        # Check if any output is of date time type.
        date_time_output_index = [
            ind for ind, ele in enumerate(self.return_types) if ele == "timestamp"
        ]

        # Function that converts the timestamp to localized timezone
        convert_timstamp_function = (
            "def convert_timezone(date_time_obj : datetime):\n"
            "   from datetime import datetime, timezone\n"
            "   import tzlocal\n"
            "   current_timezone = tzlocal.get_localzone()\n"
            "   if date_time_obj and isinstance(date_time_obj, datetime):\n"
            "      if date_time_obj.tzinfo is None:\n"
            "      # if timestamp is timezone unaware, make sure it's localized to the system's timezone.\n"
            "      # otherwise, spark will implicitly convert it to the system's timezone.\n"
            "         return date_time_obj.replace(tzinfo=current_timezone)\n"
            "      else:\n"
            "         return date_time_obj.astimezone(timezone.utc).replace(tzinfo=current_timezone)\n"
            "   else:\n"
            "      return None\n"
        )

        # Start wrapper function generation
        code = (
            self._module_imports
            + "\n"
            + (convert_timstamp_function + "\n" if date_time_output_index else "\n")
            + "def wrapper(*args):\n"
            + f"   {self._formatted_function_source}\n"
            + f"   transformed_features = {self.function_name}(*args)\n"
        )
        if len(self.return_types) > 1:
            # If date time columns are there convert make sure that they are localized.
            if date_time_output_index:
                code += (
                    "   transformed_features = list(transformed_features)\n"
                    "   for index in _date_time_output_index:\n"
                    "      transformed_features[index] = convert_timezone(transformed_features[index])\n"
                )
            if rename_outputs:
                # Use a dictionary to rename output to correct column names. This must be for the udf's to be executable in spark.
                code += "   return dict(zip(_output_col_names, transformed_features))"
            else:
                code += "   return transformed_features"
        else:
            if date_time_output_index:
                code += (
                    "   transformed_features = convert_timezone(transformed_features)\n"
                )
            code += "   return transformed_features"

        # Inject required parameter to scope
        scope = self._prepare_transformation_function_scope(
            _date_time_output_index=date_time_output_index
        )

        exec(code, scope)
        return scope["wrapper"], scope

    def _pandas_udf_wrapper(self) -> tuple[Callable, dict]:
        """Function that creates a dynamic wrapper function for the defined udf that renames the columns output by the UDF into specified column names.

        The renames is done so that the column names match the schema expected by spark when multiple columns are returned in a pandas udf.
        The wrapper function would be available in the main scope of the program.

        Returns:
            A tuple of (wrapper_function, scope_dict) where scope_dict can be updated
            to inject new runtime values (statistics, context, output_col_names).
        """
        date_time_output_columns = [
            self.output_column_names[ind]
            for ind, ele in enumerate(self.return_types)
            if ele == "timestamp"
        ]

        # Function to make transformation function time safe. Defined as a string because it has to be dynamically injected into scope to be executed by spark
        convert_timstamp_function = """def convert_timezone(date_time_col : pd.Series):
        import tzlocal
        current_timezone = tzlocal.get_localzone()
        if date_time_col.dt.tz is None:
            # if timestamp is timezone unaware, make sure it's localized to the system's timezone.
            # otherwise, spark will implicitly convert it to the system's timezone.
            return date_time_col.dt.tz_localize(str(current_timezone))
        else:
            # convert to utc, then localize to system's timezone
            return date_time_col.dt.tz_convert('UTC').dt.tz_localize(None).dt.tz_localize(str(current_timezone))"""

        # Defining wrapper function that renames the column names to specific names
        if len(self.return_types) > 1:
            code = (
                self._module_imports
                + "\n"
                + f"""import pandas as pd
{convert_timstamp_function}
def renaming_wrapper(*args):
    {self._formatted_function_source}
    df = {self.function_name}(*args)
    if isinstance(df, tuple):
        df = pd.concat(df, axis=1)
    df.columns = _output_col_names
    for col in _date_time_output_columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = convert_timezone(df[col])
    return df"""
            )
        else:
            code = (
                self._module_imports
                + "\n"
                + f"""import pandas as pd
{convert_timstamp_function}
def renaming_wrapper(*args):
    {self._formatted_function_source}
    df = {self.function_name}(*args)
    # If the output is a dataframe, then it should be a single column dataframe, so we can squeeze it to a series.
    df = df.squeeze(axis=1) if isinstance(df, pd.DataFrame) else df
    df = df.rename(_output_col_names[0])
    if _date_time_output_columns:
        # Set correct type is column is not of datetime type
        if pd.api.types.is_datetime64_any_dtype(df):
            df = convert_timezone(df)
    return df"""
            )

        # Inject required parameter to scope
        scope = self._prepare_transformation_function_scope(
            _date_time_output_columns=date_time_output_columns
        )

        exec(code, scope)
        return scope["renaming_wrapper"], scope

    def __call__(self, *features: list[str]) -> HopsworksUdf:
        """Set features to be passed as arguments to the user defined functions.

        Parameters:
            features: Name of features to be passed to the User Defined function.

        Returns:
            Meta data class for the user defined function.

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: If the provided number of features do not match the number of arguments in the defined UDF or if the provided feature names are not strings.
        """
        if len(features) != len(self.transformation_features):
            raise FeatureStoreException(
                "Number of features provided does not match the number of features provided in the UDF definition"
            )

        for arg in features:
            if not isinstance(arg, str):
                raise FeatureStoreException(
                    f'Feature names provided must be string "{arg}" is not string'
                )
        transformation_feature_name = self.transformation_features
        if self.dropped_features:
            index_dropped_features = [
                transformation_feature_name.index(dropped_feature)
                for dropped_feature in self.dropped_features
            ]
            updated_dropped_features = [
                features[index] for index in index_dropped_features
            ]
        else:
            updated_dropped_features = None

        # Create a copy of the UDF to associate it with new feature names.
        udf = copy.deepcopy(self)

        udf._transformation_features = [
            TransformationFeature(
                new_feature_name, transformation_feature.statistic_argument_name
            )
            for transformation_feature, new_feature_name in zip(
                self._transformation_features, features, strict=False
            )
        ]
        # Invalidate lazily cached feature lists since _transformation_features changed.
        udf._cached_transformation_features = None
        udf._cached_unprefixed_transformation_features = None
        udf.dropped_features = updated_dropped_features
        return udf

    @public
    def alias(self, *args: str):
        """Set the names of the transformed features output by the UDF.

        Parameters:
            args: Name of the output features after transformation. Can be passed as individual string arguments or as a list of strings. The number of output feature names provided must match the number of features returned by the transformation function.
        """
        if len(args) == 1 and isinstance(args[0], list):
            # If a single list is passed, use it directly
            output_col_names = args[0]
        else:
            # Otherwise, use the individual arguments as a list
            output_col_names = list(args)
        if any(
            not isinstance(output_col_name, str) for output_col_name in output_col_names
        ):
            raise FeatureStoreException(
                f"Invalid output feature names provided for the transformation function '{repr(self)}'. Please ensure all arguments are strings."
            )

        self._generate_output_col_name = False
        self.output_column_names = output_col_names

        return self

    def _validate_output_col_name(self, output_col_names):
        if any(
            len(output_col_name) > FEATURES.MAX_LENGTH_NAME
            for output_col_name in output_col_names
        ):
            raise FeatureStoreException(
                f"Invalid output feature names specified for the transformation function '{repr(self)}'. Please provide names shorter than {FEATURES.MAX_LENGTH_NAME} characters."
            )

        if len(output_col_names) != len(set(output_col_names)):
            raise FeatureStoreException(
                f"Duplicate output feature names provided for the transformation function '{repr(self)}'. Please ensure all arguments names are unique."
            )

        if output_col_names and len(output_col_names) != len(self.return_types):
            raise FeatureStoreException(
                f"The number of output feature names provided does not match the number of features returned by the transformation function '{repr(self)}'. Pease provide exactly {len(self.return_types)} feature name(s) to match the output."
            )

    def _validate_transformation_context(self, transformation_context: dict[str, Any]):
        """Function that checks if the context variables provided to the transformation function is valid.

        It checks if context variables are defined as a dictionary.
        """
        if not isinstance(transformation_context, dict):
            raise FeatureStoreException(
                "Transformation context variable must be passed as dictionary."
            )

        return transformation_context

    def _update_return_type_one_hot(self):
        self._return_types = [
            self._return_types[0]
            for _ in range(len(self.transformation_statistics.feature.unique_values))
        ]
        # The output count grows with the categories, so any cached output names
        # are stale.
        self._cached_output_column_names = None
        self._clear_udf_cache()

    def _clear_udf_cache(self) -> None:
        """Clear the cached UDF wrapper functions.

        Should be called when state that affects wrapper compilation changes
        (e.g., return types modified by _update_return_type_one_hot).
        """
        self._udf_cache.clear()
        self._return_types_tuple = None

    def _get_udf(
        self, online: bool = False, engine_type: str | None = None
    ) -> Callable:
        """Return a callable wrapper matching the current engine and execution mode.

        The wrapper is selected based on the `execution_mode` of this UDF, the active
        engine (spark / python / training), and whether online inference is requested.

        If the execution mode is `"default"`:

        - In the `spark` engine: during online inference a spark UDF is returned,
          otherwise a spark pandas UDF is returned.
        - In the `python` engine: during online inference a python UDF is returned,
          otherwise a pandas UDF is returned.

        If the execution mode is `"pandas"`:

        - In the `spark` engine: always returns a spark pandas UDF.
        - In the `python` engine: always returns a pandas UDF.

        If the execution mode is `"python"`:

        - In the `spark` engine: always returns a spark UDF.
        - In the `python` engine: always returns a python UDF.

        Note: Caching
            Wrappers are cached and reused across calls with the same
            `(execution_mode, engine_type, online, return_types)` key.
            Statistics, context, and output column names are injected into the
            cached wrapper's scope at runtime, so the wrapper does not need to
            be regenerated when only those values change.
            The wrapper's scope snapshots `__main__` globals at first
            compilation per cache key; redefining a notebook global that the
            UDF references after the first call has no effect on the cached
            wrapper.

        Parameters:
            online: Specify if udf required for online inference.
            engine_type: Override the engine type instead of auto-detecting it.
                Accepted values are `"spark"`, `"python"`, and `"training"`.
                When `None`, the engine type is resolved via `engine._get_type()`.

        Returns:
            A callable that applies this UDF to a dataframe or row input,
            matching the conventions of the resolved engine and execution mode.
        """
        engine_type = engine_type or engine._get_type()
        execution_mode = self.execution_mode._get_current_execution_mode(online)

        # For python/training engines (and online), use cached wrappers to avoid
        # repeated exec()/eval() overhead. The wrapper reads statistics, context,
        # and output_col_names from its scope dict at runtime, so we just update
        # the scope on cache hits.
        # Use cached tuple to avoid tuple() allocation on every lookup
        if self._return_types_tuple is None:
            self._return_types_tuple = tuple(self.return_types)
        cache_key = (execution_mode, engine_type, online, self._return_types_tuple)
        # Spark batch UDFs are serialized lazily: their scope is read at Spark
        # *action* time, not when _get_udf() returns. Reusing a cached wrapper
        # whose shared scope is mutated in place (below) would let a later
        # _get_udf() call silently change the statistics/context an
        # already-returned UDF computes with, e.g. a train-split transformation
        # picking up a full-dataset mean set by a later training-dataset step.
        # For the lazy Spark path always build a fresh wrapper with its own
        # immutable scope snapshot and never cache or mutate it. The eager
        # python/training/online paths apply immediately, so the in-place scope
        # refresh is safe and stays cached.
        spark_batch = engine_type == "spark" and not online
        cached = None if spark_batch else self._udf_cache.get(cache_key)
        if cached is not None:
            wrapper_fn, scope = cached
            scope["_output_col_names"] = self.output_column_names
            # Always refresh statistics and context. Assigning even when the
            # current values are None / empty prevents the cached scope from
            # carrying state from a previous call.
            scope[UDFKeyWords.STATISTICS.value] = self.transformation_statistics
            scope[UDFKeyWords.CONTEXT.value] = self.transformation_context
            return wrapper_fn

        # Cache miss: generate a new wrapper.
        if execution_mode == UDFExecutionMode.PANDAS:
            if engine_type in ["python", "training"] or online:
                wrapper_fn, scope = self._pandas_udf_wrapper()
                self._udf_cache[cache_key] = (wrapper_fn, scope)
                return wrapper_fn
            from pyspark.sql.functions import pandas_udf

            wrapper_fn, scope = self._pandas_udf_wrapper()
            spark_udf = pandas_udf(
                f=wrapper_fn,
                returnType=self._create_pandas_udf_return_schema_from_list(),
            )
            if not spark_batch:
                self._udf_cache[cache_key] = (spark_udf, scope)
            return spark_udf
        if execution_mode == UDFExecutionMode.PYTHON:
            if engine_type in ["python", "training"] or online:
                wrapper_fn, scope = self._python_udf_wrapper(rename_outputs=False)
                self._udf_cache[cache_key] = (wrapper_fn, scope)
                return wrapper_fn
            from pyspark.sql.functions import udf as pyspark_udf

            wrapper_fn, scope = self._python_udf_wrapper(rename_outputs=True)
            spark_udf = pyspark_udf(
                f=wrapper_fn,
                returnType=self._create_pandas_udf_return_schema_from_list(),
            )
            if not spark_batch:
                self._udf_cache[cache_key] = (spark_udf, scope)
            return spark_udf
        raise ValueError(
            f"Invalid execution mode '{self.execution_mode}' for UDF '{self.function_name}'."
        )

    @public
    def executor(
        self,
        statistics: TransformationStatistics
        | list[FeatureDescriptiveStatistics]
        | dict[str, dict[str, Any]] = None,
        context: dict[str, Any] = None,
        online: bool = False,
    ) -> Any:
        """Create an executable transformation with optional statistics and context for unit testing.

        This method returns a callable object that can execute the UDF with the specified
        configuration. It is designed for unit testing transformation functions locally.

        The executor allows you to:
        - Inject mock statistics for testing model-dependent transformations
        - Provide transformation context for testing transformation functions using
        - Switch between online (single-value) and offline (batch) execution modes

        !!! example "Testing UDF with pandas execution mode"
            ```python
            @udf(return_type=float, mode="pandas")
            def add_one(value):
                return value + 1

            # Create executor and test
            executor = add_one.executor()
            result = executor.execute(pd.Series([1.0, 2.0, 3.0]))
            assert result.tolist() == [2.0, 3.0, 4.0]
            ```

        !!! example "Testing UDF with python execution mode"
            ```python
            @udf(return_type=float, mode="python")
            def add_one(value):
                return value + 1

            # Create executor and test
            executor = add_one.executor()
            result = executor.execute(1.0)
            assert result == 2.0
            ```

        !!! example "Testing UDF with default execution mode"
            ```python
            # In the default execution mode, Hopsworks executes the transformation function as pandas UDF for batch processing and as python function for online processing to get optimal.
            # Hence, the function should should be able to handle both online and offline execution modes and unit-test musts be written for both these use-cases.
            # In the offline mode, Hopsworks would pass a pandas Series to the function.
            # In the online mode, Hopsworks would pass a single value to the function.

            @udf(return_type=float)
            def double_value(value):
                return value * 2

            # Offline mode (batch processing with pandas Series)
            offline_executor = double_value.executor(online=False)
            batch_result = offline_executor.execute(pd.Series([1.0, 2.0, 3.0]))

            # Online mode (single value processing)
            online_executor = double_value.executor(online=True)
            single_result = online_executor.execute(5.0)
            assert single_result == 10.0
            ```

        !!! example "Unit test with mocked statistics"
            ```python
            from hsfs.transformation_statistics import TransformationStatistics

            @udf(return_type=float)
            def normalize(value, statistics=TransformationStatistics("value")):
                return (value - statistics.value.mean) / statistics.value.std_dev

            # Test with mock statistics
            executor = normalize.executor(statistics={"value": {"mean": 100.0, "std_dev": 25.0}})
            result = executor.execute(pd.Series([100.0, 125.0, 150.0]))
            assert result.tolist() == [0.0, 1.0, 2.0]
            ```


        !!! example "Unit test with transformation context"
            ```python
            @udf(return_type=float)
            def apply_discount(price, context):
                return price * (1 - context["discount_rate"])

            executor = apply_discount.executor(context={"discount_rate": 0.1})
            result = executor.execute(pd.Series([100.0, 200.0]))
            assert result.tolist() == [90.0, 180.0]
            ```

        !!! example "Testing online vs offline execution modes"
            ```python
            # For transformation functions using the default execution mode `default`.
            # The function should should be able to handle both online and offline execution modes.
            # In the offline mode, Hopsworks would pass a pandas Series to the function.
            # In the online mode, Hopsworks would pass a single value to the function.
            @udf(return_type=float, mode="default")
            def double_value(value):
                return value * 2

            # Offline mode (batch processing with pandas Series)
            offline_executor = double_value.executor(online=False)
            batch_result = offline_executor.execute(pd.Series([1.0, 2.0, 3.0]))

            # Online mode (single value processing)
            online_executor = double_value.executor(online=True)
            single_result = online_executor.execute(5.0)
            assert single_result == 10.0
            ```

        Parameters:
            statistics: Statistics for model-dependent transformations.
                Can be provided as:

                - `TransformationStatistics`: Pre-built statistics object
                - `dict[str, dict[str, Any]]`: Dictionary mapping feature names to their statistics (e.g., `{"amount": {"mean": 100.0, "std_dev": 25.0}}`)
                - `list[FeatureDescriptiveStatistics]`: List of statistics objects from Hopsworks
            context: A dictionary mapping variable names to values that provide contextual
                information to the transformation function at runtime.
                The keys must match parameter names defined in the UDF.
            online: Whether to execute in online mode (single values) or offline mode (batch/vectorized).
                Only applicable when the UDF uses `mode="default"`.

        Returns:
            A callable object with an `execute(*args)` method to run the transformation.
        """
        # Fetch existing stateful information in the UDF.
        udf = copy.deepcopy(self)

        udf.transformation_context = context if context else udf.transformation_context
        if statistics:
            udf.transformation_statistics = statistics
        udf.output_column_names = (
            udf.output_column_names
            if udf.output_column_names
            else [f"col_{i}" for i in range(len(udf.return_types))]
        )

        executable = udf._get_udf(online=online)

        executable.execute = executable.__call__

        return executable

    @public
    def execute(
        self, *args: Any
    ) -> (
        pd.Series
        | pd.DataFrame
        | int
        | float
        | str
        | bool
        | datetime
        | time
        | date
        | tuple[int | float | str | bool | datetime | time | date, ...]
    ):
        """Execute the UDF directly with the provided arguments.

        This is a convenience method for quick testing of simple UDFs that don't require
        statistics or transformation context. It executes the UDF in offline mode (batch processing).

        !!! example "Quick UDF testing"
            ```python
            @udf(return_type=float)
            def add_one(value):
                return value + 1

            # Direct execution for simple tests
            result = add_one.execute(pd.Series([1.0, 2.0, 3.0]))
            assert result.tolist() == [2.0, 3.0, 4.0]
            ```

        !!! note
            For UDFs that require statistics or transformation context or need to be executed in online mode, use [`executor()`][hsfs.hopsworks_udf.HopsworksUdf.executor] instead:
            ```python
            result = my_udf.executor(statistics=stats, context=ctx).execute(data)
            ```

        Parameters:
            *args:
                Input arguments matching the UDF's parameter signature.
                For batch processing, pass pandas Series or DataFrames.

        Returns:
            The transformed values.
        """
        return self.executor().execute(*args)

    def to_dict(self) -> dict[str, Any]:
        """Convert class into a dictionary.

        Returns:
            Dictionary that contains all data required to json serialize the object.
        """
        connection = client._get_connection()
        backend_version = connection.backend_version if connection else current_version

        return {
            "sourceCode": self._function_source,
            "outputTypes": self.return_types,
            "transformationFeatures": self.transformation_features,
            "transformationFunctionArgumentNames": self._transformation_function_argument_names,
            "droppedArgumentNames": self._dropped_argument_names,
            "statisticsArgumentNames": self._statistics_argument_names
            if self.statistics_required
            else None,
            "name": self.function_name,
            "featureNamePrefix": self._feature_name_prefix,
            "executionMode": self.execution_mode.value.upper(),
            **(
                {"outputColumnNames": self.output_column_names}
                if Version(backend_version) >= Version("4.1.6")
                else {}
            ),  # This check is added for backward compatibility with older versions of Hopsworks. The "outputColumnNames" field was added in Hopsworks 4.1.6 and versions below do not support unknown fields in the backend.
        }

    @public
    def json(self) -> str:
        """Convert class into its json serialized form.

        Returns:
            JSON serialized object.
        """
        return json.dumps(self, cls=util.Encoder)

    @public
    @classmethod
    def from_response_json(
        cls: HopsworksUdf, json_dict: dict[str, Any]
    ) -> HopsworksUdf:
        """Function that constructs the class object from its json serialization.

        Parameters:
            json_dict: JSON serialized dictionary for the class.

        Returns:
            JSON deserialized class object.
        """
        json_decamelized = humps.decamelize(json_dict)
        function_source_code = json_decamelized["source_code"]
        function_name = json_decamelized["name"]
        feature_name_prefix = json_decamelized.get("feature_name_prefix", None)
        output_types = [
            output_type.strip() for output_type in json_decamelized["output_types"]
        ]
        transformation_features = [
            feature.strip() for feature in json_decamelized["transformation_features"]
        ]
        dropped_argument_names = (
            [
                dropped_feature.strip()
                for dropped_feature in json_decamelized["dropped_argument_names"]
            ]
            if json_decamelized.get("dropped_argument_names", None)
            else None
        )
        transformation_function_argument_names = (
            [
                arg_name.strip()
                for arg_name in json_decamelized[
                    "transformation_function_argument_names"
                ]
            ]
            if json_decamelized.get("transformation_function_argument_names", None)
            else None
        )
        statistics_features = (
            [
                feature.strip()
                for feature in json_decamelized["statistics_argument_names"]
            ]
            if json_decamelized.get("statistics_argument_names", None)
            else None
        )

        output_column_names = (
            [feature.strip() for feature in json_decamelized["output_column_names"]]
            if json_decamelized.get("output_column_names", None)
            else None
        )

        # Reconstructing statistics arguments.
        arg_list, _, _, _ = HopsworksUdf._parse_function_signature(function_source_code)

        transformation_features = (
            transformation_features if transformation_features else arg_list
        )

        dropped_feature_names = (
            [
                transformation_features[arg_list.index(dropped_argument_name)]
                for dropped_argument_name in dropped_argument_names
            ]
            if dropped_argument_names
            else None
        )

        if statistics_features:
            transformation_features = [
                TransformationFeature(
                    transformation_features[arg_index],
                    arg_list[arg_index]
                    if arg_list[arg_index] in statistics_features
                    else None,
                )
                for arg_index in range(len(arg_list))
            ]
        else:
            transformation_features = [
                TransformationFeature(transformation_features[arg_index], None)
                for arg_index in range(len(arg_list))
            ]

        hopsworks_udf: HopsworksUdf = cls(
            func=function_source_code,
            return_types=output_types,
            name=function_name,
            transformation_features=transformation_features,
            dropped_argument_names=dropped_argument_names,
            dropped_feature_names=dropped_feature_names,
            feature_name_prefix=feature_name_prefix,
            transformation_function_argument_names=transformation_function_argument_names,
            execution_mode=UDFExecutionMode.from_string(
                json_decamelized["execution_mode"]
            ),
            output_column_names=output_column_names,
            generate_output_col_names=not output_column_names,  # Do not generate output column names if they are retrieved from the back
        )

        # Set transformation features if already set.
        return hopsworks_udf

    @public
    @property
    def return_types(self) -> list[str]:
        """Get the output types of the UDF."""
        # Update the number of outputs for one hot encoder to match the number of unique values for the feature
        if self.function_name == "one_hot_encoder" and self.transformation_statistics:
            self._update_return_type_one_hot()
        return self._return_types

    @public
    @property
    def function_name(self) -> str:
        """Get the function name of the UDF."""
        return self._function_name

    @public
    @property
    def statistics_required(self) -> bool:
        """Get if statistics for any feature is required by the UDF."""
        return bool(self.statistics_features)

    @public
    @property
    def transformation_statistics(
        self,
    ) -> TransformationStatistics | None:
        """Feature statistics required for the defined UDF."""
        return self._statistics

    @public
    @property
    def output_column_names(self) -> list[str]:
        """Output columns names of the transformation function."""
        if self._cached_output_column_names is None:
            if self._feature_name_prefix:
                self._cached_output_column_names = [
                    self._feature_name_prefix + output_col_name
                    for output_col_name in self._output_column_names
                ]
            else:
                self._cached_output_column_names = self._output_column_names
        return self._cached_output_column_names

    @public
    @property
    def transformation_features(self) -> list[str]:
        """List of feature names to be used in the User Defined Function."""
        if self._cached_transformation_features is None:
            if self._feature_name_prefix:
                self._cached_transformation_features = [
                    self._feature_name_prefix + transformation_feature.feature_name
                    for transformation_feature in self._transformation_features
                ]
            else:
                self._cached_transformation_features = [
                    transformation_feature.feature_name
                    for transformation_feature in self._transformation_features
                ]
        return self._cached_transformation_features

    @public
    @property
    def unprefixed_transformation_features(self) -> list[str]:
        """List of feature name used in the transformation function without the feature name prefix."""
        if self._cached_unprefixed_transformation_features is None:
            self._cached_unprefixed_transformation_features = [
                transformation_feature.feature_name
                for transformation_feature in self._transformation_features
            ]
        return self._cached_unprefixed_transformation_features

    @public
    @property
    def feature_name_prefix(self) -> str | None:
        """The feature name prefix that needs to be added to the feature names."""
        return self._feature_name_prefix

    @feature_name_prefix.setter
    def feature_name_prefix(self, prefix: str | None) -> None:
        self._feature_name_prefix = prefix
        self._cached_output_column_names = None
        self._cached_transformation_features = None
        self._cached_unprefixed_transformation_features = None
        self._cached_dropped_features = None

    @public
    @property
    def statistics_features(self) -> list[str]:
        """List of feature names that require statistics."""
        return [
            transformation_feature.feature_name
            for transformation_feature in self._transformation_features
            if transformation_feature.statistic_argument_name is not None
        ]

    @property
    def _statistics_argument_mapping(self) -> dict[str, str]:
        """Dictionary that maps feature names to the statistics arguments names in the User defined function."""
        return {
            transformation_feature.feature_name: transformation_feature.statistic_argument_name
            for transformation_feature in self._transformation_features
        }

    @property
    def _statistics_argument_names(self) -> list[str]:
        """List of argument names required for statistics."""
        return [
            transformation_feature.statistic_argument_name
            for transformation_feature in self._transformation_features
            if transformation_feature.statistic_argument_name is not None
        ]

    @public
    @property
    def dropped_features(self) -> list[str]:
        """List of features that will be dropped after the UDF is applied."""
        if self._cached_dropped_features is None:
            if self._feature_name_prefix and self._dropped_features:
                self._cached_dropped_features = [
                    self._feature_name_prefix + dropped_feature
                    for dropped_feature in self._dropped_features
                ]
            else:
                self._cached_dropped_features = self._dropped_features
        return self._cached_dropped_features

    @public
    @property
    def execution_mode(self) -> UDFExecutionMode:
        return self._execution_mode

    @public
    @property
    def transformation_context(self) -> dict[str, Any]:
        """Dictionary that contains the context variables required for the UDF.

        These context variables passed to the UDF during execution.
        """
        return self._transformation_context if self._transformation_context else {}

    @transformation_context.setter
    def transformation_context(self, context_variables: dict[str, Any]) -> None:
        self._transformation_context = (
            self._validate_transformation_context(context_variables)
            if context_variables
            else {}
        )

    @dropped_features.setter
    def dropped_features(self, features: list[str]) -> None:
        self._dropped_features = HopsworksUdf._validate_and_convert_drop_features(
            features, self.transformation_features, self._feature_name_prefix
        )
        self._cached_dropped_features = None

    @transformation_statistics.setter
    def transformation_statistics(
        self,
        statistics: list[FeatureDescriptiveStatistics]
        | dict[str, dict[str, Any]]
        | TransformationStatistics,
    ) -> None:
        if isinstance(statistics, TransformationStatistics):
            self._statistics = statistics
        elif isinstance(statistics, dict):
            self._statistics = TransformationStatistics(*statistics.keys())
            for key, value in statistics.items():
                self._statistics.set_statistics(key, {"feature_name": key, **value})
        else:
            self._statistics = TransformationStatistics(
                *self._statistics_argument_names
            )
            for stat in statistics:
                if stat.feature_name in self._statistics_argument_mapping:
                    self._statistics.set_statistics(
                        self._statistics_argument_mapping[stat.feature_name],
                        stat.to_dict(),
                    )

    @output_column_names.setter
    def output_column_names(self, output_col_names: str | list[str]) -> None:
        if not isinstance(output_col_names, list):
            output_col_names = [output_col_names]
        self._validate_output_col_name(output_col_names)
        self._output_column_names = output_col_names
        self._cached_output_column_names = None  # invalidate cache

    def __repr__(self):
        return f"{self.function_name}({', '.join(self.transformation_features)})"

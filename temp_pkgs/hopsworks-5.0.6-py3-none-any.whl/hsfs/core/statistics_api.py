#
#   Copyright 2020 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

from typing import Any

from hopsworks_common import client
from hsfs import feature_group, feature_view, statistics, training_dataset
from hsfs.core import job


class StatisticsApi:
    def __init__(self, feature_store_id: int, entity_type: str) -> None:
        """Statistics endpoint for `trainingdatasets` and `featuregroups` resource.

        Parameters:
            feature_store_id: id of the respective featurestore
            entity_type: "trainingdatasets" or "featuregroups" or "featureview"
        """
        self._feature_store_id = feature_store_id
        self._entity_type = entity_type  # TODO: Support FV

    def _post(
        self,
        metadata_instance: feature_view.FeatureView
        | training_dataset.TrainingDataset
        | feature_group.FeatureGroup,
        stats: statistics.Statistics,
        training_dataset_version: int | None,
    ) -> statistics.Statistics | None:
        _client = client._get_instance()
        path_params = self._get_path(metadata_instance, training_dataset_version)

        headers = {"content-type": "application/json"}
        stats = statistics.Statistics.from_response_json(
            _client._send_request(
                "POST", path_params, headers=headers, data=stats.json()
            )
        )
        return self._extract_single_stats(stats)

    def _get(
        self,
        metadata_instance: feature_view.FeatureView
        | training_dataset.TrainingDataset
        | feature_group.FeatureGroup,
        computation_time: int | None = None,
        start_commit_time: int | None = None,
        end_commit_time: int | None = None,
        feature_names: list[str] | None = None,
        row_percentage: float | None = None,
        before_transformation: bool | None = None,
        training_dataset_version: int | None = None,
    ) -> statistics.Statistics | None:
        """Get single statistics of an entity.

        Parameters:
            metadata_instance: metadata object of the instance to get statistics of
            computation_time: Time at which statistics where computed
            start_commit_time: Window start commit time
            end_commit_time: Window end commit time
            feature_names: List of feature names of which statistics are retrieved
            row_percentage: Percentage of feature values used during statistics computation
            before_transformation: Whether the statistics were computed before transformations or not
            training_dataset_version: Version of the training dataset on which statistics were computed

        Returns:
            The statistics object, or `None` if not found.
        """
        # get statistics by entity + filters + sorts, including the feature descriptive statistics
        _client = client._get_instance()
        path_params = self._get_path(metadata_instance, training_dataset_version)

        # single statistics
        offset, limit = 0, 1

        headers = {"content-type": "application/json"}
        query_params = self._build_get_query_params(
            computation_time=computation_time,
            start_commit_time=start_commit_time,
            end_commit_time=end_commit_time,
            filter_eq_times=True,
            feature_names=feature_names,
            row_percentage=row_percentage,
            before_transformation=before_transformation,
            training_dataset_version=training_dataset_version,
            # retrieve only one entity statistics, including the feature descriptive statistics
            offset=offset,
            limit=limit,
            with_content=True,
        )

        # response is either a single item or not found exception
        stats = statistics.Statistics.from_response_json(
            _client._send_request("GET", path_params, query_params, headers=headers)
        )
        return self._extract_single_stats(stats)

    def _get_all(
        self,
        metadata_instance: feature_view.FeatureView
        | training_dataset.TrainingDataset
        | feature_group.FeatureGroup,
        computation_time: int | None = None,
        start_commit_time: int | None = None,
        end_commit_time: int | None = None,
        feature_names: list[str] | None = None,
        row_percentage: float | None = None,
        before_transformation: bool | None = None,
        training_dataset_version: int | None = None,
    ) -> list[statistics.Statistics] | None:
        """Get all statistics of an entity.

        Parameters:
            metadata_instance: metadata object of the instance to get statistics of
            computation_time: Time at which statistics where computed
            start_commit_time: Window start commit time
            end_commit_time: Window end commit time
            feature_names: List of feature names of which statistics are retrieved
            row_percentage: Percentage of feature values used during statistics computation
            before_transformation: Whether the statistics were computed before transformations or not
            training_dataset_version: Version of the training dataset on which statistics were computed

        Returns:
            A list of statistics objects, or `None` if not found.
        """
        # get all statistics by entity + filters + sorts, without the feature descriptive statistics
        _client = client._get_instance()
        path_params = self._get_path(metadata_instance, training_dataset_version)

        # multiple statistics
        offset, limit = 0, None

        headers = {"content-type": "application/json"}
        query_params = self._build_get_query_params(
            computation_time=computation_time,
            start_commit_time=start_commit_time,
            end_commit_time=end_commit_time,
            filter_eq_times=False,
            feature_names=feature_names,
            row_percentage=row_percentage,
            before_transformation=before_transformation,
            training_dataset_version=training_dataset_version,
            # retrieve all entity statistics, excluding feature descriptive statistics
            offset=offset,
            limit=limit,
            with_content=False,
        )

        return statistics.Statistics.from_response_json(
            _client._send_request("GET", path_params, query_params, headers=headers)
        )

    def _get_all_in_window(
        self,
        metadata_instance: feature_view.FeatureView
        | training_dataset.TrainingDataset
        | feature_group.FeatureGroup,
        start_commit_time: int | None = None,
        end_commit_time: int | None = None,
        feature_names: list[str] | None = None,
        limit: int | None = None,
    ) -> list[statistics.Statistics] | None:
        """Get all statistics rows for an entity within a commit time window, with content.

        Used by the KLL-merge path to enumerate per-batch statistics rows. Passing `limit`
        caps the response size; callers should treat a fully-populated response as a
        signal to fall back to re-profile (the merge sample would be truncated).

        Parameters:
            metadata_instance: metadata object of the instance
            start_commit_time: Window start commit time (inclusive)
            end_commit_time: Window end commit time (inclusive)
            feature_names: List of feature names to retrieve statistics for
            limit: Maximum number of rows to return; None = unlimited (not recommended
                for content-heavy responses).

        Returns:
            A list of statistics objects with feature descriptive statistics, or None.
        """
        _client = client._get_instance()
        path_params = self._get_path(metadata_instance, None)

        headers = {"content-type": "application/json"}
        query_params = self._build_get_query_params(
            start_commit_time=start_commit_time,
            end_commit_time=end_commit_time,
            filter_eq_times=False,
            feature_names=feature_names,
            offset=0,
            limit=limit,
            with_content=True,
        )

        return statistics.Statistics.from_response_json(
            _client._send_request("GET", path_params, query_params, headers=headers)
        )

    def _compute(
        self,
        metadata_instance: training_dataset.TrainingDataset
        | feature_view.FeatureView
        | feature_group.FeatureGroup,
        training_dataset_version: int | None = None,
        start_commit_time: int | None = None,
        end_commit_time: int | None = None,
    ) -> job.Job:
        """Compute statistics for an entity.

        Parameters:
            metadata_instance: metadata object of the instance to compute statistics for
            training_dataset_version: version of the training dataset metadata object
            start_commit_time: optional lower bound of the commit window to scope stats to.
            end_commit_time: optional upper bound of the commit window. When set on a feature
                group, statistics are persisted against this specific commit rather than head.

        Returns:
            The job metadata object for the statistics computation job.
        """
        _client = client._get_instance()
        path_params = self._get_path(metadata_instance, training_dataset_version) + [
            "compute"
        ]
        query_params = {}
        if start_commit_time is not None:
            query_params["start_commit_time"] = start_commit_time
        if end_commit_time is not None:
            query_params["end_commit_time"] = end_commit_time
        return job.Job.from_response_json(
            _client._send_request(
                "POST", path_params, query_params=query_params or None
            )
        )

    def _get_path(
        self,
        metadata_instance: training_dataset.TrainingDataset
        | feature_group.FeatureGroup
        | feature_view.FeatureView,
        training_dataset_version: int | None = None,
    ) -> list[str | int]:
        """Get statistics path.

        Parameters:
            metadata_instance: metadata object of the instance to compute statistics for
            training_dataset_version: version of the training dataset metadata object

        Returns:
            The API path as a list of path segments.
        """
        _client = client._get_instance()
        if isinstance(metadata_instance, feature_view.FeatureView):
            path = [
                "project",
                _client._project_id,
                "featurestores",
                self._feature_store_id,
                "featureview",
                metadata_instance.name,
                "version",
                metadata_instance.version,
            ]
            if training_dataset_version is not None:
                path += [
                    "trainingdatasets",
                    "version",
                    training_dataset_version,
                ]
            return path + ["statistics"]
        return [
            "project",
            _client._project_id,
            "featurestores",
            self._feature_store_id,
            self._entity_type,
            metadata_instance.id,
            "statistics",
        ]

    def _extract_single_stats(
        self, stats: statistics.Statistics | list[statistics.Statistics] | None
    ) -> statistics.Statistics | None:
        return stats[0] if isinstance(stats, list) else stats

    def _build_get_query_params(
        self,
        computation_time: int | None = None,
        start_commit_time: int | None = None,
        end_commit_time: int | None = None,
        filter_eq_times: bool = False,
        feature_names: list[str] | None = None,
        row_percentage: float | None = None,
        before_transformation: bool | None = None,
        training_dataset_version: int | None = None,
        offset: int = 0,
        limit: int | None = None,
        with_content: bool = False,
    ) -> dict[str, Any]:
        """Build query parameters for statistics requests.

        Parameters:
            computation_time: Time at which statistics where computed
            start_commit_time: Window start commit time
            end_commit_time: Window end commit time
            feature_names: List of feature names of which statistics are retrieved
            row_percentage: Percentage of feature values used during statistics computation
            before_transformation: Whether the statistics were computed for transformations or not
            training_dataset_version: Version of the training dataset on which statistics were computed
            offset: Offset for pagination queries
            limit: Limit for pagination queries
            with_content: Whether include feature descriptive statistics in the response or not
        """
        query_params: dict[str, int | str | list[str]] = {"offset": offset}
        if limit is not None:
            query_params["limit"] = limit
        if with_content:
            query_params["fields"] = "content"

        sorts: list[str] = []
        filters: list[str] = []

        # filters and sorts

        # window times
        if end_commit_time is not None:
            col_name = "window_end_commit_time"
            sorts.append(col_name + ":desc")  # first sort
            filter_name = col_name + ("_eq" if filter_eq_times else "_ltoeq")
            filters.append(filter_name + ":" + str(end_commit_time))
        if start_commit_time is not None:
            col_name = "window_start_commit_time"
            sorts.append(col_name + ":asc")  # second sort
            filter_name = col_name + ("_eq" if filter_eq_times else "_gtoeq")
            filters.append(filter_name + ":" + str(start_commit_time))

        # computation time -- order is important, this should be after the other sorts
        if start_commit_time is None and end_commit_time is None:
            sorts.append("computation_time:desc")  # third sort
        if computation_time is not None:
            filters.append("computation_time_ltoeq:" + str(computation_time))

        # row percentage
        if row_percentage is not None:
            filters.append("row_percentage_eq:" + str(row_percentage))

        # for transformation
        if before_transformation is not None:
            filters.append("before_transformation_eq:" + str(before_transformation))

        # feature names
        if feature_names is not None:
            query_params["feature_names"] = feature_names

        # others
        if training_dataset_version is not None:
            query_params["training_dataset_version"] = training_dataset_version

        if sorts:
            query_params["sort_by"] = sorts
        if filters:
            query_params["filter_by"] = filters

        return query_params

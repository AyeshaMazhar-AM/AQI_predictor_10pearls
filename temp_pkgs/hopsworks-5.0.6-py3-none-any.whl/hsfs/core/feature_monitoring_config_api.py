#
#   Copyright 2024 Hopsworks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

from hopsworks_common import client
from hsfs import decorators
from hsfs.core import feature_monitoring_config as fmc
from hsfs.core.job import Job


class FeatureMonitoringConfigApi:
    """Feature Monitoring Configuration endpoints for the Feature Group resource.

    Parameters:
        feature_store_id: id of the respective Feature Store
        feature_group_id: id of the feature group, if monitoring a feature group
        feature_view_name: name of the feature view, if monitoring a feature view
        feature_view_version: version of the feature view, if monitoring a feature view
    """

    def __init__(
        self,
        feature_store_id: int,
        feature_group_id: int | None = None,
        feature_view_name: str | None = None,
        feature_view_version: int | None = None,
        **kwargs,
    ) -> None:
        if feature_group_id is None:
            assert feature_view_name is not None
            assert feature_view_version is not None

        self._feature_store_id = feature_store_id
        self._feature_group_id = feature_group_id
        self._feature_view_name = feature_view_name
        self._feature_view_version = feature_view_version

    def _create(
        self,
        fm_config: fmc.FeatureMonitoringConfig,
    ) -> fmc.FeatureMonitoringConfig:
        """Create an feature monitoring configuration attached to the Feature of a Feature Group.

        Parameters:
            fm_config: feature monitoring config object to be attached to a Feature

        Returns:
            the created feature monitoring configuration
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
        )

        headers = {"content-type": "application/json"}
        payload = fm_config.json()
        return fmc.FeatureMonitoringConfig.from_response_json(
            _client._send_request("POST", path_params, headers=headers, data=payload)
        )

    def _update(
        self,
        fm_config: fmc.FeatureMonitoringConfig,
    ) -> fmc.FeatureMonitoringConfig:
        """Update a feature monitoring configuration attached to a Feature.

        Parameters:
            fm_config: feature monitoring configuration to be attached to a Feature

        Returns:
            the updated feature monitoring configuration
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
            config_id=fm_config._id,
        )

        headers = {"content-type": "application/json"}
        payload = fm_config.json()

        return fmc.FeatureMonitoringConfig.from_response_json(
            _client._send_request("PUT", path_params, headers=headers, data=payload)
        )

    def _delete(
        self,
        config_id: int,
    ) -> None:
        """Delete the Feature Monitoring configuration attached to a Feature.

        Parameters:
            config_id: Id of the feature monitoring configuration to delete
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
            config_id=config_id,
        )

        _client._send_request("DELETE", path_params)

    def _get_by_id(
        self,
        config_id: int,
    ) -> fmc.FeatureMonitoringConfig | None:
        """Get the Feature Monitoring Configuration attached to a Feature.

        Parameters:
            config_id: Id of the feature monitoring configuration to fetch

        Returns:
            fetched feature monitoring configuration attached to the Feature Group
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
            config_id=config_id,
        )

        return fmc.FeatureMonitoringConfig.from_response_json(
            _client._send_request("GET", path_params)
        )

    def _get_by_feature_name(
        self,
        feature_name: str,
    ) -> fmc.FeatureMonitoringConfig | None:
        """Get all Feature Monitoring Configurations attached to a Feature Name.

        Parameters:
            feature_name: Name of the feature for which to fetch monitoring configuration

        Returns:
            fetched feature monitoring configuration attached to the Feature Group
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
            feature_name=feature_name,
        )

        return fmc.FeatureMonitoringConfig.from_response_json(
            _client._send_request("GET", path_params)
        )

    @decorators._catch_not_found(
        "hsfs.core.feature_monitoring_config.FeatureMonitoringConfig",
        fallback_return=[],
    )
    def _get_by_name(
        self,
        name: str,
    ) -> fmc.FeatureMonitoringConfig | None:
        """Get all Feature Monitoring Configurations attached to a Feature Name.

        Parameters:
            name: Name of the feature monitoring configuration to fetch.

        Returns:
            Fetched feature monitoring configuration attached to the Feature Group.
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
            name=name,
        )
        return fmc.FeatureMonitoringConfig.from_response_json(
            _client._send_request("GET", path_params)
        )

    def _get_by_entity(self) -> list[fmc.FeatureMonitoringConfig]:
        """Get all Feature Monitoring Configurations attached to a Feature Name.

        Returns:
            Fetched feature monitoring configuration attached to the Feature Group.
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
            entity=True,
        )

        return fmc.FeatureMonitoringConfig.from_response_json(
            _client._send_request("GET", path_params)
        )

    def _setup_feature_monitoring_job(
        self,
        config_name: str,
    ) -> Job:
        """Setup a feature monitoring job for a configuration.

        Parameters:
            config_name: Name of the feature monitoring configuration to setup a job for

        Returns:
            Job object for the feature monitoring job
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
        )
        path_params.extend(["setup", config_name])

        return Job.from_response_json(_client._send_request("POST", path_params))

    def _trigger_feature_monitoring_job(
        self,
        config_id: int,
    ) -> Job:
        """Trigger a feature monitoring job for a configuration.

        Parameters:
            config_id: Id of the feature monitoring configuration to trigger a job for

        Returns:
            Job attached to the monitoring configuration
        """
        _client = client._get_instance()
        path_params = self._build_path_params(
            project_id=_client._project_id,
            config_id=config_id,
        )
        path_params.append("trigger")

        return Job.from_response_json(_client._send_request("POST", path_params))

    @staticmethod
    def _get_by_model(
        model_registry_id: int,
        model_id: str,
    ) -> list[fmc.FeatureMonitoringConfig]:
        """Get all Feature Monitoring Configurations associated with a model version.

        Parameters:
            model_registry_id: ID of the model registry.
            model_id: ID of the model version (``name_version`` format).

        Returns:
            List of feature monitoring configurations for the model version.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "modelregistries",
            model_registry_id,
            "models",
            model_id,
            "featuremonitoring",
        ]
        return fmc.FeatureMonitoringConfig.from_response_json(
            _client._send_request("GET", path_params)
        )

    def _build_path_params(
        self,
        project_id: int,
        feature_name: str | None = None,
        config_id: int | None = None,
        name: str | None = None,
        entity: bool = False,
    ) -> list[str | int]:
        """Builds the path parameters for the Feature Monitoring Config API.

        Parameters:
            project_id: ID of the project.
            feature_name: Name of the feature.
            config_id: ID of the feature monitoring configuration. Only to fetch feature monitoring configuration by ID.
            name: Name of the feature monitoring configuration. Only to fetch feature monitoring configuration by name.
            entity: Whether to append entity to path params. Only to fetch all feature monitoring configurations attached to an entity.

        Returns:
            Path parameters for the API call.
        """
        path_params = [
            "project",
            project_id,
            "featurestores",
            self._feature_store_id,
        ]
        if self._feature_group_id is not None:
            path_params.extend(["featuregroups", self._feature_group_id])
        else:
            path_params.extend(
                [
                    "featureview",
                    self._feature_view_name,
                    "version",
                    self._feature_view_version,
                ]
            )
        path_params.extend(["featuremonitoring", "config"])

        if config_id:
            path_params.append(config_id)
        elif feature_name:
            path_params.extend(["feature", feature_name])
        elif name:
            path_params.extend(["name", name])
        elif entity:
            path_params.append("entity")

        return path_params

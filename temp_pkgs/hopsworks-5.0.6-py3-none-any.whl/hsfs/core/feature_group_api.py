#
#   Copyright 2020 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

import warnings

from hopsworks_common import client
from hsfs import decorators, feature_group_commit, util
from hsfs import feature_group as fg_mod
from hsfs.core import (
    explicit_provenance,
    ingestion_job,
    ingestion_job_conf,
    job,
)


class FeatureGroupApi:
    BACKEND_FG_STREAM = "streamFeatureGroupDTO"
    BACKEND_FG_BATCH = "cachedFeaturegroupDTO"
    BACKEND_FG_EXTERNAL = "onDemandFeaturegroupDTO"
    BACKEND_FG_SPINE = "onDemandFeaturegroupDTO"

    def _save(
        self,
        feature_group_instance: fg_mod.FeatureGroup
        | fg_mod.ExternalFeatureGroup
        | fg_mod.SpineGroup,
    ) -> fg_mod.FeatureGroup | fg_mod.ExternalFeatureGroup | fg_mod.SpineGroup:
        """Save feature group metadata to the feature store.

        Parameters:
            feature_group_instance: metadata object of feature group to be saved

        Returns:
            updated metadata object of the feature group
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
        ]
        query_params = {
            "expand": [
                "features",
                "expectationsuite",
                "transformationfunctions",
                "mandatorytags",
            ]
        }
        headers = {"content-type": "application/json"}
        return feature_group_instance.update_from_response_json(
            _client._send_request(
                "POST",
                path_params,
                headers=headers,
                data=feature_group_instance.json(),
                query_params=query_params,
            ),
        )

    @decorators._catch_not_found(
        "hsfs.feature_group.FeatureGroupBase", fallback_return=[]
    )
    def _get_feature_group_by_name(self, feature_store_id: int, name: str):
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_store_id,
            "featuregroups",
            name,
        ]
        query_params = {
            "expand": [
                "features",
                "expectationsuite",
                "transformationfunctions",
                "mandatorytags",
            ]
        }
        return _client._send_request("GET", path_params, query_params)

    @decorators._catch_not_found(
        "hsfs.feature_group.FeatureGroupBase", fallback_return=None
    )
    def _get_feature_group_by_version(
        self, feature_store_id: int, name: str, version: int
    ):
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_store_id,
            "featuregroups",
            name,
        ]
        query_params = {
            "expand": [
                "features",
                "expectationsuite",
                "transformationfunctions",
                "mandatorytags",
            ],
            "version": version,
        }
        return _client._send_request("GET", path_params, query_params)

    def _get(
        self, feature_store_id: int, name: str, version: int | None
    ) -> (
        fg_mod.FeatureGroup
        | fg_mod.SpineGroup
        | fg_mod.ExternalFeatureGroup
        | list[fg_mod.FeatureGroup]
        | list[fg_mod.SpineGroup]
        | list[fg_mod.ExternalFeatureGroup]
    ):
        """Get the metadata of a feature group with a certain name and version.

        Parameters:
            feature_store_id: feature store id
            name: name of the feature group
            version: version of the feature group

        Returns:
            feature group metadata object
        """
        if version:
            fgs_json = self._get_feature_group_by_version(
                feature_store_id, name, version
            )
        else:
            fgs_json = self._get_feature_group_by_name(feature_store_id, name)

        if not fgs_json:
            return fgs_json

        fg_objs = []
        # In principle unique names are enforced across fg type and this should therefore
        # return only list of the same type. But it cost nothing to check in case this gets forgotten.
        for fg_json in fgs_json:
            if (
                fg_json["type"] == FeatureGroupApi.BACKEND_FG_STREAM
                or fg_json["type"] == FeatureGroupApi.BACKEND_FG_BATCH
            ):
                fg_objs.append(fg_mod.FeatureGroup.from_response_json(fg_json))
            elif fg_json["type"] == FeatureGroupApi.BACKEND_FG_EXTERNAL:
                if fg_json.get("spine", False):
                    fg_objs.append(fg_mod.SpineGroup.from_response_json(fg_json))
                else:
                    fg_objs.append(
                        fg_mod.ExternalFeatureGroup.from_response_json(fg_json)
                    )
            else:
                list_of_types = [
                    FeatureGroupApi.BACKEND_FG_STREAM,
                    FeatureGroupApi.BACKEND_FG_BATCH,
                    FeatureGroupApi.BACKEND_FG_EXTERNAL,
                    FeatureGroupApi.BACKEND_FG_SPINE,
                ]
                raise ValueError(
                    f"Unknown feature group type: {fg_json['type']}, expected one of: "
                    + str(list_of_types)
                )

        if version is not None:
            self._check_features(fg_objs[0])
            return fg_objs[0]
        for fg_obj in fg_objs:
            self._check_features(fg_obj)
        return fg_objs

    @decorators._catch_not_found(
        "hsfs.feature_group.FeatureGroupBase", fallback_return=None
    )
    def _get_by_id(
        self, feature_store_id: int, feature_group_id: int
    ) -> fg_mod.FeatureGroup | fg_mod.SpineGroup | fg_mod.ExternalFeatureGroup:
        """Get the metadata of a feature group with a certain id.

        Parameters:
            feature_store_id: feature store id
            feature_group_id: id of the feature group

        Returns:
            feature group metadata object
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_store_id,
            "featuregroups",
            feature_group_id,
        ]
        query_params = {
            "expand": [
                "features",
                "expectationsuite",
                "transformationfunctions",
                "mandatorytags",
            ]
        }
        fg_json = _client._send_request("GET", path_params, query_params)
        if (
            fg_json["type"] == FeatureGroupApi.BACKEND_FG_STREAM
            or fg_json["type"] == FeatureGroupApi.BACKEND_FG_BATCH
        ):
            return fg_mod.FeatureGroup.from_response_json(fg_json)
        if fg_json["type"] == FeatureGroupApi.BACKEND_FG_EXTERNAL:
            if fg_json.get("spine", False):
                return fg_mod.SpineGroup.from_response_json(fg_json)
            return fg_mod.ExternalFeatureGroup.from_response_json(fg_json)
        return None

    def _get_all(
        self,
        feature_store_id: int,
        with_features: bool = False,
    ) -> list[fg_mod.FeatureGroup | fg_mod.SpineGroup | fg_mod.ExternalFeatureGroup]:
        """Get a list of feature groups in a feature store.

        Parameters:
            feature_store_id: Feature store ID.
            with_features: Whether to also retrieve the features of the feature groups.

        Returns:
            List of feature group metadata objects.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_store_id,
            "featuregroups",
        ]
        query_params = {}
        if with_features:
            query_params["expand"] = ["features"]

        res = _client._send_request("GET", path_params, query_params)

        if "items" not in res:
            try:
                return [fg_mod.FeatureGroup.from_response_json(res)]
            except TypeError:
                return []

        return [fg_mod.FeatureGroup.from_response_json(r) for r in res["items"]]

    def _delete_content(
        self,
        feature_group_instance: fg_mod.FeatureGroup | fg_mod.ExternalFeatureGroup,
    ) -> None:
        """Delete the content of a feature group.

        This endpoint serves to simulate the overwrite/insert mode.

        Parameters:
            feature_group_instance: metadata object of feature group to clear the content for
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "clear",
        ]
        _client._send_request("POST", path_params)

    def _delete(
        self,
        feature_group_instance: fg_mod.FeatureGroup
        | fg_mod.ExternalFeatureGroup
        | fg_mod.SpineGroup,
        force: bool = False,
        delete_feature_views: bool = False,
    ) -> None:
        """Drop a feature group from the feature store.

        Drops the metadata and data of a version of a feature group.

        Parameters:
            feature_group_instance: Metadata object of feature group
            force: When True, delete the feature group even if feature views depend on it, leaving those feature views in place
            delete_feature_views: When True, also delete the feature views that depend on the feature group, along with their training data
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
        ]
        query_params = {}
        if force:
            query_params["force"] = True
        if delete_feature_views:
            query_params["deleteFeatureViews"] = True
        _client._send_request("DELETE", path_params, query_params=query_params or None)

    def _update_metadata(
        self,
        feature_group_instance: fg_mod.FeatureGroup
        | fg_mod.ExternalFeatureGroup
        | fg_mod.SpineGroup,
        feature_group_copy: fg_mod.FeatureGroup
        | fg_mod.ExternalFeatureGroup
        | fg_mod.SpineGroup,
        query_parameter: str,
        query_parameter_value: str | bool = True,
    ) -> fg_mod.FeatureGroup | fg_mod.ExternalFeatureGroup | fg_mod.SpineGroup:
        """Update the metadata of a feature group.

        This only updates description and schema/features. The
        `feature_group_copy` is the metadata object sent to the backend, while
        `feature_group_instance` is the user object, which is only updated
        after a successful REST call.

        Parameters:
            feature_group_instance: User metadata object of the feature group.
            feature_group_copy: Metadata object of the feature group with the information to be updated.
            query_parameter: Query parameter that controls which information is updated. E.g. "updateMetadata".
            query_parameter_value: Value of the query_parameter.

        Returns:
            FeatureGroup. The updated feature group metadata object.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
        ]
        headers = {"content-type": "application/json"}
        query_params = {query_parameter: query_parameter_value}
        return feature_group_instance.update_from_response_json(
            _client._send_request(
                "PUT",
                path_params,
                query_params,
                headers=headers,
                data=feature_group_copy.json(),
            ),
        )

    def _commit(
        self,
        feature_group_instance: fg_mod.FeatureGroup,
        feature_group_commit_instance: feature_group_commit.FeatureGroupCommit,
    ) -> feature_group_commit.FeatureGroupCommit:
        """Save feature group commit metadata.

        Parameters:
            feature_group_instance: Metadata object of feature group.
            feature_group_commit_instance: Metadata object of feature group commit.

        Returns:
            The feature group commit metadata object.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "commits",
        ]
        headers = {"content-type": "application/json"}
        return feature_group_commit_instance.update_from_response_json(
            _client._send_request(
                "POST",
                path_params,
                headers=headers,
                data=feature_group_commit_instance.json(),
            ),
        )

    def _get_commit_details(
        self,
        feature_group_instance: fg_mod.FeatureGroup,
        wallclock_timestamp: int,
        limit: int,
    ) -> feature_group_commit.FeatureGroupCommit:
        """Get feature group commit metadata.

        Parameters:
            feature_group_instance: Metadata object of feature group.
            wallclock_timestamp: Specific point in time.
            limit: Number of commits to retrieve.

        Returns:
            The feature group commit metadata object.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "commits",
        ]
        headers = {"content-type": "application/json"}
        query_params = {"sort_by": "committed_on:desc", "offset": 0, "limit": limit}
        if wallclock_timestamp is not None:
            query_params["filter_by"] = "commited_on_ltoeq:" + str(wallclock_timestamp)

        return feature_group_commit.FeatureGroupCommit.from_response_json(
            _client._send_request("GET", path_params, query_params, headers=headers),
        )

    def _ingestion(
        self,
        feature_group_instance: fg_mod.FeatureGroup,
        ingestion_conf: ingestion_job_conf.IngestionJobConf,
    ) -> ingestion_job.IngestionJob:
        """Setup a Hopsworks job for dataframe ingestion.

        Parameters:
            feature_group_instance: Metadata object of feature group.
            ingestion_conf: The configuration for the ingestion job application.

        Returns:
            The ingestion job metadata object.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "ingestion",
        ]

        headers = {"content-type": "application/json"}
        return ingestion_job.IngestionJob.from_response_json(
            _client._send_request(
                "POST", path_params, headers=headers, data=ingestion_conf.json()
            ),
        )

    def _update_table_schema(
        self,
        feature_group_instance: fg_mod.FeatureGroup,
    ) -> job.Job:
        """Setup a Hopsworks job to update table schema.

        Parameters:
            feature_group_instance: Metadata object of feature group.

        Returns:
            The job metadata object.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "updatetableschema",
        ]

        headers = {"content-type": "application/json"}
        return job.Job.from_response_json(
            _client._send_request("POST", path_params, headers=headers),
        )

    def _get_parent_feature_groups(
        self,
        feature_group_instance: fg_mod.FeatureGroup
        | fg_mod.SpineGroup
        | fg_mod.ExternalFeatureGroup,
    ) -> explicit_provenance.Links:
        """Get the parents of this feature group, based on explicit provenance.

        Parents are feature groups or external feature groups. These feature
        groups can be accessible, deleted or inaccessible.
        For deleted and inaccessible feature groups, only a minimal information is
        returned.

        Parameters:
            feature_group_instance: Metadata object of feature group.

        Returns:
            The feature groups used to generate this feature group.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "provenance",
            "links",
        ]
        query_params = {
            "expand": "provenance_artifacts",
            "upstreamLvls": 1,
            "downstreamLvls": 0,
        }
        links_json = _client._send_request("GET", path_params, query_params)
        return explicit_provenance.Links.from_response_json(
            links_json,
            explicit_provenance.Links.Direction.UPSTREAM,
            explicit_provenance.Links.Type.FEATURE_GROUP,
        )

    def _get_storage_connector_provenance(
        self, feature_group_instance
    ) -> explicit_provenance.Links:
        """Get the parents of this feature group, based on explicit provenance.

        Parents are storage connectors.
        These storage connector can be accessible, deleted or inaccessible.
        For deleted and inaccessible storage connector, only a minimal information is returned.

        Parameters:
            feature_group_instance: Metadata object of feature group.

        Returns:
            The storage connector used to generated this feature group.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "provenance",
            "links",
        ]
        query_params = {
            "expand": "provenance_artifacts",
            "upstreamLvls": 1,
            "downstreamLvls": 0,
        }
        links_json = _client._send_request("GET", path_params, query_params)
        return explicit_provenance.Links.from_response_json(
            links_json,
            explicit_provenance.Links.Direction.UPSTREAM,
            explicit_provenance.Links.Type.STORAGE_CONNECTOR,
        )

    def _get_generated_feature_views(
        self,
        feature_group_instance: fg_mod.FeatureGroup
        | fg_mod.SpineGroup
        | fg_mod.ExternalFeatureGroup,
    ) -> explicit_provenance.Links:
        """Get the generated feature view using this feature group, based on explicit provenance.

        These feature views can be accessible or inaccessible.
        Explicit provenance does not track deleted generated feature view links, so deleted will always be empty.
        For inaccessible feature views, only a minimal information is returned.

        Parameters:
            feature_group_instance: Metadata object of feature group.

        Returns:
            The feature views generated using this feature group.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "provenance",
            "links",
        ]
        query_params = {
            "expand": "provenance_artifacts",
            "upstreamLvls": 0,
            "downstreamLvls": 1,
        }
        links_json = _client._send_request("GET", path_params, query_params)
        return explicit_provenance.Links.from_response_json(
            links_json,
            explicit_provenance.Links.Direction.DOWNSTREAM,
            explicit_provenance.Links.Type.FEATURE_VIEW,
        )

    def _get_generated_feature_groups(
        self,
        feature_group_instance: fg_mod.FeatureGroup
        | fg_mod.SpineGroup
        | fg_mod.ExternalFeatureGroup,
    ) -> explicit_provenance.Links:
        """Get the generated feature groups using this feature group, based on explicit provenance.

        These feature groups can be accessible or inaccessible.
        Explicit provenance does not track deleted generated feature group links, so deleted will always be empty.
        For inaccessible feature groups, only a minimal information is returned.

        Parameters:
            feature_group_instance: Metadata object of feature group.

        Returns:
            The feature groups generated using this feature group.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "featurestores",
            feature_group_instance.feature_store_id,
            "featuregroups",
            feature_group_instance.id,
            "provenance",
            "links",
        ]
        query_params = {
            "expand": "provenance_artifacts",
            "upstreamLvls": 0,
            "downstreamLvls": 1,
        }
        links_json = _client._send_request("GET", path_params, query_params)
        return explicit_provenance.Links.from_response_json(
            links_json,
            explicit_provenance.Links.Direction.DOWNSTREAM,
            explicit_provenance.Links.Type.FEATURE_GROUP,
        )

    def _check_features(self, feature_group_instance) -> None:
        if not feature_group_instance._features:
            warnings.warn(
                f"Feature Group `{feature_group_instance._name}`, version `{feature_group_instance._version}` has no features (to resolve this issue contact the admin or delete and recreate the feature group)",
                util.FeatureGroupWarning,
                stacklevel=1,
            )

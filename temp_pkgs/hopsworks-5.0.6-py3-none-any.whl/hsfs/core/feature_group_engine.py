#
#   Copyright 2020 Logical Clocks AB
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

import warnings
from typing import TYPE_CHECKING, Any

from hopsworks_common.client import exceptions
from hopsworks_common.core.sink_job_configuration import (
    FeatureColumnMapping,
    SinkJobConfiguration,
)
from hsfs import engine, feature, util
from hsfs import feature_group as fg
from hsfs.core import (
    delta_engine,
    feature_group_base_engine,
    hudi_engine,
    job_api,
    transformation_execution_dag,
    transformation_function_engine,
)
from hsfs.core.deltastreamer_jobconf import DeltaStreamerJobConf
from hsfs.core.schema_validation import DataFrameValidator
from hsfs.storage_connector import StorageConnector


if TYPE_CHECKING:
    import pandas as pd
    import polars as pl
    from hsfs.feature import Feature


class FeatureGroupEngine(feature_group_base_engine.FeatureGroupBaseEngine):
    def __init__(self, feature_store_id: int):
        super().__init__(feature_store_id)

        # cache online feature store connector
        self._online_conn = None
        self._job_api = job_api.JobApi()

    def _update_feature_group_schema_on_demand_transformations(
        self, feature_group: fg.FeatureGroup, features: list[feature.Feature]
    ):
        """Function to update feature group schema based on the on demand transformation available in the feature group.

        Parameters:
            feature_group: The feature group for which the schema has to be updated.
            features: List of features currently in the feature group.

        Returns:
            Updated list of features. That has on-demand features and removes dropped features.
        """
        if not feature_group.transformation_functions:
            return features
        transformed_features = []
        dropped_features = []
        feature_names = [f.name for f in features]
        for tf in feature_group.transformation_functions:
            transformed_features.extend(
                [
                    feature.Feature(
                        output_column_name,
                        return_type,
                        on_demand=True,
                    )
                    for output_column_name, return_type in zip(
                        tf.hopsworks_udf.output_column_names,
                        tf.hopsworks_udf.return_types,
                        strict=False,
                    )
                    if output_column_name
                    not in feature_names  # Don't add features that are already in the feature group. Feature names can already be in the feature group if the user explicitly added them in the feature group creation or if the feature group drop
                ]
            )
            if tf.hopsworks_udf.dropped_features:
                dropped_features.extend(tf.hopsworks_udf.dropped_features)
        updated_schema = []

        for feat in features:
            if feat.name not in dropped_features:
                updated_schema.append(feat)
        # Also filter out transformed (intermediate) features that are dropped
        # by downstream transformation functions in the chain.
        transformed_features = [
            feat for feat in transformed_features if feat.name not in dropped_features
        ]
        return updated_schema + transformed_features

    def _save(
        self,
        feature_group: fg.FeatureGroup | fg.ExternalFeatureGroup,
        feature_dataframe,
        write_options,
        transformation_context: dict[str, Any] = None,
        validation_options: dict = None,
        n_processes: int | None = None,
    ):
        dataframe_features = engine._get_instance()._parse_schema_feature_group(
            feature_dataframe, feature_group.time_travel_format
        )
        dataframe_features = (
            self._update_feature_group_schema_on_demand_transformations(
                feature_group=feature_group, features=dataframe_features
            )
        )

        # Currently on-demand transformation functions not supported in external feature groups.
        if feature_group.transformation_functions:
            if not isinstance(feature_group, fg.ExternalFeatureGroup):
                feature_dataframe = transformation_function_engine.TransformationFunctionEngine._apply_transformation_functions(
                    execution_graph=feature_group._transformation_function_execution_dag,
                    data=feature_dataframe,
                    online=False,
                    transformation_context=transformation_context,
                    n_processes=n_processes,
                )
            else:
                warnings.warn(
                    "On-Demand features were not created because On-Demand Transformations are not supported for External Feature Groups.",
                    stacklevel=1,
                )

        util._validate_embedding_feature_type(
            feature_group.embedding_index, dataframe_features
        )

        if not validation_options or (
            validation_options.get(
                "online_schema_validation", True
            )  # for backwards compatibility
            and validation_options.get("schema_validation", True)
        ):
            # validate df schema
            dataframe_features = DataFrameValidator()._validate_schema(
                feature_group, feature_dataframe, dataframe_features
            )

        self._save_feature_group_metadata(
            feature_group,
            dataframe_features,
            write_options,
        )

        # ge validation on python and non stream feature groups on spark
        ge_report = feature_group._great_expectation_engine._validate(
            feature_group=feature_group,
            dataframe=feature_dataframe,
            validation_options=validation_options or {},
            ingestion_result="INGESTED",
        )

        if ge_report is not None and ge_report.ingestion_result == "REJECTED":
            return None, ge_report

        offline_write_options = write_options
        online_write_options = write_options

        return (
            engine._get_instance()._save_dataframe(
                feature_group,
                feature_dataframe,
                (
                    hudi_engine.HudiEngine.HUDI_BULK_INSERT
                    if feature_group.time_travel_format in ["HUDI", "DELTA"]
                    else None
                ),
                feature_group.online_enabled,
                None,
                offline_write_options,
                online_write_options,
            ),
            ge_report,
        )

    def _apply_on_demand_transformations(
        self,
        execution_graph: transformation_execution_dag.TransformationExecutionDAG,
        data: pd.DataFrame | pl.DataFrame | list[dict[str, Any]],
        online: bool = False,
        transformation_context: dict[str, Any] | list[dict[str, Any]] = None,
        request_parameters: dict[str, Any] | list[dict[str, Any]] = None,
        n_processes: int | None = None,
    ) -> list[dict[str, Any]] | pd.DataFrame:
        """Function to apply on demand transformations to the passed dataframe or list of dictionaries.

        Parameters:
            execution_graph: The transformation DAG containing on-demand transformation functions with dependency tracking.
            data: The dataframe or list of dictionaries to apply the transformations to.
            online: Apply the transformations for online or offline usecase.
                This parameter is applicable when a transformation function is defined using the `default` execution mode.
            transformation_context: Transformation context to be used when applying the transformations.
            request_parameters: Request parameters to be used when applying the transformations.
            n_processes: Number of worker processes for applying transformation functions in parallel.
                Defaults to `1` (sequential execution); a value above the DAG's maximum parallelism is capped, with a warning.
                Ignored by the Spark engine.

        Returns:
            The updated dataframe or list of dictionaries with the transformations applied.
        """
        try:
            df = transformation_function_engine.TransformationFunctionEngine._apply_transformation_functions(
                execution_graph=execution_graph,
                data=data,
                online=online,
                transformation_context=transformation_context,
                request_parameters=request_parameters,
                n_processes=n_processes,
            )
        except exceptions.TransformationFunctionException as e:
            raise exceptions.FeatureStoreException(
                f"The following feature(s): {e.missing_features}, specified in the {e.transformation_type} transformation function '{e.transformation_function_name}' are not present in the feature group. "
                " Please verify that the correct features are specified in the transformation function."
            ) from e
        return df

    def _insert(
        self,
        feature_group: fg.FeatureGroup | fg.ExternalFeatureGroup,
        feature_dataframe,
        overwrite,
        operation,
        storage,
        write_options,
        validation_options: dict = None,
        transformation_context: dict[str, Any] = None,
        transform: bool = True,
        n_processes: int | None = None,
    ):
        dataframe_features = engine._get_instance()._parse_schema_feature_group(
            feature_dataframe,
            feature_group.time_travel_format,
            features=feature_group.columns,
        )

        # Currently on-demand transformation functions not supported in external feature groups.
        if (
            not isinstance(feature_group, fg.ExternalFeatureGroup)
            and feature_group.transformation_functions
            and transform
        ):
            try:
                feature_dataframe = transformation_function_engine.TransformationFunctionEngine._apply_transformation_functions(
                    execution_graph=feature_group._transformation_function_execution_dag,
                    data=feature_dataframe,
                    transformation_context=transformation_context,
                    online=False,
                    n_processes=n_processes,
                )
            except exceptions.TransformationFunctionException as e:
                raise exceptions.FeatureStoreException(
                    f"The following feature(s): {e.missing_features}, specified in the {e.transformation_type} transformation function '{e.transformation_function_name}'  are not present in the dataframe being inserted into the feature group. "
                    "Please verify that the correct feature names are used in the transformation function and that these features exist in the dataframe being inserted"
                ) from e

            dataframe_features = (
                self._update_feature_group_schema_on_demand_transformations(
                    feature_group=feature_group, features=dataframe_features
                )
            )

        util._validate_embedding_feature_type(
            feature_group.embedding_index, dataframe_features
        )

        if not validation_options or (
            validation_options.get(
                "online_schema_validation", True
            )  # for backwards compatibility
            and validation_options.get("schema_validation", True)
        ):
            # validate df schema
            dataframe_features = DataFrameValidator()._validate_schema(
                feature_group, feature_dataframe, dataframe_features
            )

        if not feature_group._id:
            # only save metadata if feature group does not exist
            self._save_feature_group_metadata(
                feature_group,
                dataframe_features,
                write_options,
            )
        else:
            # else, just verify that feature group schema matches user-provided dataframe
            self._verify_schema_compatibility(feature_group.columns, dataframe_features)

        # ge validation on python and non stream feature groups on spark
        ge_report = feature_group._great_expectation_engine._validate(
            feature_group=feature_group,
            dataframe=feature_dataframe,
            validation_options=validation_options or {},
            ingestion_result="INGESTED",
            ge_type=False,
        )

        if ge_report is not None and ge_report.ingestion_result == "REJECTED":
            feature_group_url = util._get_feature_group_url(
                feature_store_id=feature_group.feature_store_id,
                feature_group_id=feature_group.id,
            )
            raise exceptions.DataValidationException(
                "Data validation failed while validation ingestion policy set to strict, "
                f"insertion to {feature_group.name} was aborted.\n"
                f"You can check a summary or download your report at {feature_group_url}."
            )

        offline_write_options = write_options
        online_write_options = write_options

        if not feature_group.online_enabled and storage == "online":
            raise exceptions.FeatureStoreException(
                "Online storage is not enabled for this feature group."
            )

        if overwrite:
            self._feature_group_api._delete_content(feature_group)

        return (
            engine._get_instance()._save_dataframe(
                feature_group,
                feature_dataframe,
                "bulk_insert" if overwrite else operation,
                feature_group.online_enabled,
                storage,
                offline_write_options,
                online_write_options,
            ),
            ge_report,
        )

    def _commit_details(self, feature_group, wallclock_time, limit):
        if (
            feature_group._time_travel_format is None
            or feature_group._time_travel_format.upper() not in ["HUDI", "DELTA"]
        ):
            raise exceptions.FeatureStoreException(
                "commit_details can only be used on time travel enabled feature groups"
            )

        wallclock_timestamp = util._convert_event_time_to_timestamp(wallclock_time)

        feature_group_commits = self._feature_group_api._get_commit_details(
            feature_group, wallclock_timestamp, limit
        )
        commit_details = {}
        for feature_group_commit in feature_group_commits:
            commit_details[feature_group_commit.commitid] = {
                "committedOn": util._get_hudi_datestr_from_timestamp(
                    feature_group_commit.commitid
                ),
                "rowsUpdated": feature_group_commit.rows_updated,
                "rowsInserted": feature_group_commit.rows_inserted,
                "rowsDeleted": feature_group_commit.rows_deleted,
            }
        return commit_details

    @staticmethod
    def _get_spark_session_and_context():
        if isinstance(engine._get_instance(), engine.spark.Engine):
            return (
                engine._get_instance()._spark_session,
                engine._get_instance()._spark_context,
            )
        return None, None

    @staticmethod
    def _delete_online_records(feature_group, delete_df, write_options):
        # Produce online delete tombstones to the feature group topic; OnlineFS
        # applies a RonDB delete by primary key. The offline delete is handled
        # separately by `_commit_delete`.
        online_engine = engine._get_instance()
        if isinstance(online_engine, engine.spark.Engine):
            online_engine._delete_online_dataframe(
                feature_group, delete_df, write_options
            )
        else:
            online_engine._delete_dataframe_kafka(
                feature_group, delete_df, write_options
            )

    @staticmethod
    def _commit_delete(feature_group, delete_df, write_options):
        spark_session, spark_context = (
            FeatureGroupEngine._get_spark_session_and_context()
        )
        if feature_group.time_travel_format == "DELTA":
            delta_engine_instance = delta_engine.DeltaEngine(
                feature_group.feature_store_id,
                feature_group.feature_store_name,
                feature_group,
                spark_session,
                spark_context,
            )
            return delta_engine_instance._delete_record(delete_df)
        if spark_context is None:
            raise exceptions.FeatureStoreException(
                "Hudi feature group deletes are not supported with Spark Connect. "
                "Use DELTA time travel format instead."
            )
        hudi_engine_instance = hudi_engine.HudiEngine(
            feature_group.feature_store_id,
            feature_group.feature_store_name,
            feature_group,
            spark_context,
            spark_session,
        )
        return hudi_engine_instance._delete_record(delete_df, write_options)

    @staticmethod
    def _delta_vacuum(feature_group, retention_hours):
        if feature_group.time_travel_format == "DELTA":
            spark_session, spark_context = (
                FeatureGroupEngine._get_spark_session_and_context()
            )

            delta_engine_instance = delta_engine.DeltaEngine(
                feature_group.feature_store_id,
                feature_group.feature_store_name,
                feature_group,
                spark_session,
                spark_context,
            )
            return delta_engine_instance._vacuum(retention_hours)
        return None

    def _sql(self, query, feature_store_name, dataframe_type, online, read_options):
        if online and self._online_conn is None:
            self._online_conn = self._storage_connector_api._get_online_connector(
                self._feature_store_id
            )
        return engine._get_instance()._sql(
            query,
            feature_store_name,
            self._online_conn if online else None,
            dataframe_type,
            read_options,
        )

    def _update_features_metadata(self, feature_group: fg.FeatureGroup, features):
        # perform changes on copy in case the update fails, so we don't leave
        # the user object in corrupted state
        copy_feature_group = fg.FeatureGroup.from_response_json(feature_group.to_dict())
        copy_feature_group.columns = features
        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "updateMetadata"
        )

    def _update_features(
        self, feature_group: fg.FeatureGroup, updated_features: list[Feature]
    ) -> None:
        """Updates features safely.

        Parameters:
            feature_group: The feature group to update.
            updated_features:
                The new list of features to set on the feature group.
                This will replace the existing list of features.
        """
        self._update_features_metadata(
            feature_group, self._new_feature_list(feature_group, updated_features)
        )

    def _append_features(
        self, feature_group: fg.FeatureGroup, new_features: list[Feature]
    ) -> None:
        """Appends features to a feature group.

        Parameters:
            feature_group: The feature group to update.
            new_features: The new list of features to append to the feature group.
        """
        self._update_features_metadata(
            feature_group,
            feature_group.columns + new_features,  # todo allows for duplicates
        )

        # write empty dataframe to update parquet schema
        engine._get_instance()._update_table_schema(feature_group)

    def _update_description(
        self, feature_group: fg.FeatureGroup, description: str
    ) -> None:
        """Updates the description of a feature group.

        Parameters:
            feature_group: The feature group to update.
            description: The new description to set on the feature group.
        """
        copy_feature_group = fg.FeatureGroup.from_response_json(feature_group.to_dict())
        copy_feature_group.description = description
        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "updateMetadata"
        )

    def _update_topic_name(
        self, feature_group: fg.FeatureGroup, topic_name: str
    ) -> None:
        """Updates the topic_name of a feature group.

        Parameters:
            feature_group: The feature group to update.
            topic_name: The new topic name to set on the feature group.
        """
        copy_feature_group = fg.FeatureGroup.from_response_json(feature_group.to_dict())
        copy_feature_group.topic_name = topic_name
        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "updateMetadata"
        )

    def _update_notification_topic_name(
        self, feature_group: fg.FeatureGroup, notification_topic_name: str
    ) -> None:
        """Updates the notification_topic_name of a feature group.

        Parameters:
            feature_group: The feature group to update.
            notification_topic_name: The new notification topic name to set on the feature group.
        """
        copy_feature_group = fg.FeatureGroup.from_response_json(feature_group.to_dict())
        copy_feature_group.notification_topic_name = notification_topic_name
        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "updateMetadata"
        )

    def _update_deprecated(
        self, feature_group: fg.FeatureGroup, deprecate: bool
    ) -> None:
        """Updates the deprecation status of a feature group.

        Parameters:
            feature_group: The feature group to update.
            deprecate: The new deprecation status to set on the feature group.
        """
        copy_feature_group = fg.FeatureGroup.from_response_json(feature_group.to_dict())
        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "deprecate", deprecate
        )

    def _insert_stream(
        self,
        feature_group: fg.FeatureGroup | fg.ExternalFeatureGroup,
        dataframe,
        query_name,
        output_mode,
        await_termination,
        timeout,
        checkpoint_dir,
        write_options,
        transformation_context: dict[str, Any] = None,
        transform: bool = True,
    ):
        if not feature_group.online_enabled and not feature_group.stream:
            raise exceptions.FeatureStoreException(
                "Online storage is not enabled for this feature group. "
                "It is currently only possible to stream to the online storage."
            )

        dataframe_features = engine._get_instance()._parse_schema_feature_group(
            dataframe, feature_group.time_travel_format
        )
        dataframe_features = (
            self._update_feature_group_schema_on_demand_transformations(
                feature_group=feature_group, features=dataframe_features
            )
        )

        if feature_group.transformation_functions and transform:
            try:
                dataframe = transformation_function_engine.TransformationFunctionEngine._apply_transformation_functions(
                    execution_graph=feature_group._transformation_function_execution_dag,
                    data=dataframe,
                    online=False,
                    transformation_context=transformation_context,
                )
            except exceptions.TransformationFunctionException as e:
                raise exceptions.FeatureStoreException(
                    f"The following feature(s): {e.missing_features}, specified in the {e.transformation_type} transformation function '{e.transformation_function_name}' are not present in the dataframe being inserted into the feature group. "
                    "Please verify that the correct feature names are used in the transformation function and that these features exist in the dataframe being inserted"
                ) from e

        util._validate_embedding_feature_type(
            feature_group.embedding_index, dataframe_features
        )

        if not feature_group._id:
            self._save_feature_group_metadata(
                feature_group,
                dataframe_features,
                write_options,
            )

            if not feature_group.stream:
                # insert_stream method was called on non stream feature group object that has not been saved.
                # we will use save_dataframe method on empty dataframe to create directory structure
                offline_write_options = write_options
                online_write_options = write_options
                engine._get_instance()._save_dataframe(
                    feature_group,
                    engine._get_instance()._create_empty_df(dataframe),
                    (
                        hudi_engine.HudiEngine.HUDI_BULK_INSERT
                        if feature_group.time_travel_format == "HUDI"
                        else None
                    ),
                    feature_group.online_enabled,
                    None,
                    offline_write_options,
                    online_write_options,
                )
        else:
            # else, just verify that feature group schema matches user-provided dataframe
            self._verify_schema_compatibility(feature_group.columns, dataframe_features)

        if not feature_group.stream:
            warnings.warn(
                "`insert_stream` method in the next release will be available only for feature groups created with "
                "`stream=True`.",
                stacklevel=1,
            )

        return engine._get_instance()._save_stream_dataframe(
            feature_group,
            dataframe,
            query_name,
            output_mode,
            await_termination,
            timeout,
            checkpoint_dir,
            write_options,
        )

    def _save_feature_group_metadata(
        self,
        feature_group,
        dataframe_features,
        write_options,
    ):
        feature_schema_available = (
            feature_group.columns is not None and len(feature_group.columns) > 0
        )

        # this means FG doesn't exist and should create the new one
        if len(feature_group.columns) == 0:
            # User didn't provide a schema; extract it from the dataframe
            feature_group._features = dataframe_features
        elif dataframe_features:
            # User provided a schema; check if it is compatible with dataframe.
            self._verify_schema_compatibility(feature_group.columns, dataframe_features)

        # set primary, foreign and partition key columns
        # we should move this to the backend
        util._verify_attribute_key_names(feature_group)

        for feat in feature_group.columns:
            if feat.name in feature_group.primary_key:
                feat.primary = True
            if feat.name in feature_group.foreign_key:
                feat.foreign = True
            if feat.name in feature_group.partition_key:
                feat.partition = True
            if (
                feature_group.hudi_precombine_key is not None
                and feat.name == feature_group.hudi_precombine_key
            ):
                feat.hudi_precombine_key = True

        if feature_group.stream:
            # when creating a stream feature group, users have the possibility of passing
            # a spark_job_configuration object as part of the write_options with the key "spark"
            # filter out consumer config, not needed for delta streamer
            _spark_options = write_options.pop("spark", None)
            _client_only_options = {
                "kafka_producer_config",
                "online_ingestion_options",
            }
            _write_options = (
                [
                    {"name": k, "value": v}
                    for k, v in write_options.items()
                    if k not in _client_only_options
                ]
                if write_options
                else None
            )
            feature_group._deltastreamer_jobconf = DeltaStreamerJobConf(
                _write_options, _spark_options
            )

        if (
            feature_group.sink_enabled
            and feature_group.storage_connector.type == StorageConnector.REST
            and (
                not feature_group.data_source
                or not feature_group.data_source.rest_endpoint
            )
        ):
            raise exceptions.FeatureStoreException(
                "REST endpoint configuration is missing in the data source."
            )
        is_new_feature_group = feature_group.id is None
        requested_sink_job_conf = feature_group.sink_job_conf
        pre_save_features = list(feature_group.columns) if feature_group.columns else []
        pre_save_rest_endpoint = (
            feature_group.data_source.rest_endpoint
            if feature_group.data_source
            else None
        )
        new_fg = self._feature_group_api._save(feature_group)
        if (
            pre_save_rest_endpoint
            and new_fg.data_source
            and not new_fg.data_source.rest_endpoint
        ):
            new_fg.data_source.rest_endpoint = pre_save_rest_endpoint
        self._create_sink_job_if_needed(
            new_fg,
            is_new_feature_group,
            sink_job_conf=requested_sink_job_conf,
            source_features=pre_save_features,
        )

        if feature_schema_available:
            # create empty table to write feature schema to table path
            self._save_empty_table(feature_group, write_options=write_options)

        print(
            "Feature Group created successfully, explore it at \n"
            + util._get_feature_group_url(
                feature_store_id=feature_group.feature_store_id,
                feature_group_id=feature_group.id,
            )
        )

    def _update_ttl(
        self,
        feature_group: fg.FeatureGroup,
        ttl: int | None = None,
        enabled: bool | None = None,
    ):
        """Updates the TTL configuration of a feature group.

        Parameters:
            feature_group: The feature group to update.
            ttl: The new TTL value to set on the feature group, in seconds.
            enabled: The new TTL enabled status to set on the feature group.
        """
        copy_feature_group = fg.FeatureGroup.from_response_json(feature_group.to_dict())

        if ttl is not None:
            copy_feature_group.ttl = ttl
        if enabled is not None:
            copy_feature_group.ttl_enabled = enabled

        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "updateMetadata"
        )

    def _save_empty_table(self, feature_group, write_options=None):
        # If time travel format is DELTA, an empty table is needed to be created
        # such that the feature schema is written to the table and
        # the subsequent writes in python can refer to that schema.
        if (
            feature_group.time_travel_format is not None
            and feature_group.time_travel_format.upper() == "DELTA"
        ):
            spark_session, spark_context = (
                FeatureGroupEngine._get_spark_session_and_context()
            )

            delta_engine_instance = delta_engine.DeltaEngine(
                feature_group.feature_store_id,
                feature_group.feature_store_name,
                feature_group,
                spark_session,
                spark_context,
            )
            delta_engine_instance._save_empty_table(write_options=write_options)

    def _create_sink_job_if_needed(
        self,
        feature_group: fg.FeatureGroup,
        is_new_feature_group: bool,
        sink_job_conf: SinkJobConfiguration | None = None,
        source_features: list[feature.Feature] | None = None,
    ) -> None:
        if not is_new_feature_group or not feature_group.sink_enabled:
            return
        sink_job_conf = (
            sink_job_conf or feature_group.sink_job_conf or SinkJobConfiguration()
        )
        sink_job_conf = self._merge_default_sink_column_mappings(
            source_features or feature_group.columns,
            sink_job_conf,
        )
        job_name = sink_job_conf.name
        job_name = job_name or self._get_default_ingestion_job_name(feature_group)
        kwargs: dict[str, Any] = {}
        kwargs["featuregroup_id"] = feature_group.id
        kwargs["featurestore_id"] = feature_group.feature_store_id
        kwargs["storage_connector_id"] = feature_group.storage_connector.id
        if (
            feature_group.storage_connector.type == StorageConnector.REST
            and feature_group.data_source.rest_endpoint
        ):
            kwargs["endpoint_config"] = feature_group.data_source.rest_endpoint
        sink_job_conf._set_extra_params(**kwargs)
        job = self._job_api.create(job_name, sink_job_conf)
        feature_group._sink_job = job
        feature_group._sink_job_conf = sink_job_conf
        print(f"Sink job created successfully, explore it at {job.get_url()}")
        if sink_job_conf.schedule_config:
            self._job_api.create_or_update_schedule_job(
                job_name, sink_job_conf.schedule_config
            )

    @staticmethod
    def _merge_default_sink_column_mappings(
        features: list[feature.Feature],
        sink_job_conf: SinkJobConfiguration,
    ) -> SinkJobConfiguration:
        existing_mappings = sink_job_conf.column_mappings or []
        existing_features = {mapping.feature_name for mapping in existing_mappings}

        default_mappings = [
            FeatureColumnMapping(
                source_column=getattr(feat, "original_name", feat.name),
                feature_name=feat.name,
            )
            for feat in features
            if not feat.on_demand and feat.name not in existing_features
        ]
        sink_job_conf.column_mappings = existing_mappings + default_mappings
        return sink_job_conf

    def _get_default_ingestion_job_name(self, feature_group: fg.FeatureGroup) -> str:
        return f"{feature_group.storage_connector.name}_to_{util._feature_group_name(feature_group)}"

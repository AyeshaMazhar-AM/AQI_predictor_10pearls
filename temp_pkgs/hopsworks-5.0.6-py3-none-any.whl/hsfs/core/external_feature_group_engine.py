#
#   Copyright 2020 Logical Clocks AB
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

from typing import TYPE_CHECKING

from hopsworks_common.client.exceptions import (
    DataValidationException,
    FeatureStoreException,
)
from hsfs import engine, feature, util
from hsfs import feature_group as fg
from hsfs.core import arrow_flight_client, feature_group_base_engine


if TYPE_CHECKING:
    from hsfs.feature import Feature
    from hsfs.feature_group import FeatureGroup


class ExternalFeatureGroupEngine(feature_group_base_engine.FeatureGroupBaseEngine):
    def _save(self, feature_group):
        if not feature_group.data_source:
            raise FeatureStoreException(
                "A data source needs to be provided when creating an external feature group."
            )

        if feature_group.columns is None or len(feature_group.columns) == 0:
            if (
                (feature_group.data_source.database and feature_group.data_source.table)
                or feature_group.data_source.path is not None
                or feature_group.data_source.query
            ) and arrow_flight_client._supports([feature_group]):
                # If the user provided a data source, we can use it to infer the schema
                feature_group._features = [
                    feature.Feature.from_response_json(feat)
                    if isinstance(feat, dict)
                    else feat
                    for feat in (feature_group.data_source.get_data().features or [])
                ]
            else:
                # If the user didn't specify the schema, parse it from the query
                external_dataset = (
                    engine._get_instance()._register_external_temporary_table(
                        feature_group, "read_ondmd"
                    )
                )
                # if python engine user should pass features as we do not parse it in this case
                if external_dataset is None:
                    raise FeatureStoreException(
                        "Features (schema) need to be set for creation of external feature groups with engine "
                        + engine._get_type()
                        + ". Alternatively use Spark kernel."
                    )

                feature_group._features = (
                    engine._get_instance()._parse_schema_feature_group(external_dataset)
                )

        # set primary, foreign and partition key columns
        # we should move this to the backend
        util._verify_attribute_key_names(feature_group, True)
        for feat in feature_group.columns:
            if feat.name in feature_group.primary_key:
                feat.primary = True
            if feat.name in feature_group.foreign_key:
                feat.foreign = True
        util._validate_embedding_feature_type(
            feature_group.embedding_index, feature_group._features
        )

        self._feature_group_api._save(feature_group)

    def _insert(
        self,
        feature_group,
        feature_dataframe,
        write_options: dict,
        validation_options: dict = None,
    ):
        if not feature_group.online_enabled:
            raise FeatureStoreException(
                "Online storage is not enabled for this feature group. External feature groups can only store data in"
                " online storage. To create an offline only external feature group, use the `save` method."
            )

        schema = engine._get_instance()._parse_schema_feature_group(feature_dataframe)
        util._validate_embedding_feature_type(feature_group.embedding_index, schema)

        if not feature_group._id:
            # only save metadata if feature group does not exist
            feature_group.columns = schema
            self._save(feature_group)
        else:
            # else, just verify that feature group schema matches user-provided dataframe
            self._verify_schema_compatibility(feature_group.columns, schema)

        # ge validation on python and non stream feature groups on spark
        ge_report = feature_group._great_expectation_engine._validate(
            feature_group=feature_group,
            dataframe=feature_dataframe,
            validation_options=validation_options or {},
            ingestion_result="INGESTED",
            ge_type=False,
        )

        if ge_report is not None and ge_report.ingestion_result == "REJECTED":
            feature_group_url = util._get_feature_group_url(
                feature_store_id=feature_group.feature_store_id,
                feature_group_id=feature_group.id,
            )
            raise DataValidationException(
                "Data validation failed while validation ingestion policy set to strict, "
                f"insertion to {feature_group.name} was aborted.\n"
                f"You can check a summary or download your report at {feature_group_url}"
            )

        return (
            engine._get_instance()._save_dataframe(
                feature_group=feature_group,
                dataframe=feature_dataframe,
                operation=None,
                online_enabled=feature_group.online_enabled,
                storage="online",
                offline_write_options=write_options,
                online_write_options=write_options,
            ),
            ge_report,
        )

    def _update_features_metadata(self, feature_group, features):
        # perform changes on copy in case the update fails, so we don't leave
        # the user object in corrupted state
        fg_dict = feature_group.to_dict()
        copy_feature_group = fg.ExternalFeatureGroup.from_response_json(fg_dict)
        copy_feature_group.columns = features
        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "updateMetadata"
        )

    def _update_features(
        self, feature_group: FeatureGroup, updated_features: list[Feature]
    ):
        """Updates features safely.

        Parameters:
            feature_group: The feature group to update.
            updated_features:
                The new list of features to set on the feature group.
                This will replace the existing list of features.
        """
        self._update_features_metadata(
            feature_group, self._new_feature_list(feature_group, updated_features)
        )

    def _append_features(
        self, feature_group: FeatureGroup, new_features: list[Feature]
    ):
        """Appends features to a feature group.

        Parameters:
            feature_group: The feature group to update.
            new_features: The new list of features to append to the feature group.
        """
        self._update_features_metadata(
            feature_group,
            feature_group.columns + new_features,  # todo allows for duplicates
        )

    def _update_description(self, feature_group: FeatureGroup, description: str):
        """Updates the description of a feature group.

        Parameters:
            feature_group: The feature group to update.
            description: The new description to set on the feature group.
        """
        fg_dict = feature_group.to_dict()
        copy_feature_group = fg.ExternalFeatureGroup.from_response_json(fg_dict)
        copy_feature_group.description = description
        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "updateMetadata"
        )

    def _update_deprecated(self, feature_group: FeatureGroup, deprecate: bool):
        """Updates the deprecation status of a feature group.

        Parameters:
            feature_group: The feature group to update.
            deprecate: The new deprecation status to set on the feature group.
        """
        fg_dict = feature_group.to_dict()
        copy_feature_group = fg.ExternalFeatureGroup.from_response_json(fg_dict)
        self._feature_group_api._update_metadata(
            feature_group, copy_feature_group, "deprecate", deprecate
        )

#
#   Copyright 2022 Hopsworks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from datetime import date, datetime

    import great_expectations


from hsfs import util
from hsfs.core import validation_result_api
from hsfs.ge_validation_result import ValidationResult


class ValidationResultEngine:
    def __init__(self, feature_store_id: int, feature_group_id: int):
        """Validation Result engine.

        Parameters:
            feature_store_id: id of the respective featurestore
            feature_group_id: id of the featuregroup it is attached to
        """
        self._validation_result_api = validation_result_api.ValidationResultApi(
            feature_store_id=feature_store_id, feature_group_id=feature_group_id
        )

    def _get_validation_history(
        self,
        expectation_id: int,
        start_validation_time: str | int | datetime | date | None = None,
        end_validation_time: str | int | datetime | date | None = None,
        filter_by: list[str] = None,
        ge_type: bool = True,
    ) -> (
        list[ValidationResult]
        | list[great_expectations.core.ExpectationValidationResult]
    ):
        """Get Validation Results relevant to an Expectation specified by expectation_id.

        Parameters:
            expectation_id: id of the expectation for which to fetch the validation history
            start_validation_time: retrieve validation result posterior to start_validation_time. Supported format include timestamps(int), datetime, date or string formatted to be datutils parsable.
            end_validation_time: retrieve validation result anterior to end_validation_time Supported format include timestamps(int), datetime, date or string formatted to be datutils parsable.
            filter_by: list of ingestion result categories to include.
            ge_type: whether to convert Hopsworks object to native Great Expectations object

        Returns:
            A list of validation results for the given expectation.
        """
        query_params = self._build_query_params(
            filter_by=filter_by or [],
            start_validation_time=start_validation_time,
            end_validation_time=end_validation_time,
        )

        history = self._validation_result_api._get_validation_history(
            expectation_id=expectation_id, query_params=query_params
        )

        if isinstance(history, ValidationResult):
            history = [history]

        if ge_type:
            return [result.to_ge_type() for result in history]
        return history

    def _build_query_params(
        self,
        filter_by: list[str] = None,
        start_validation_time: str | int | datetime | date | None = None,
        end_validation_time: str | int | datetime | date | None = None,
    ) -> dict[str, str]:
        query_params = {"filter_by": [], "sort_by": "validation_time:desc"}
        allowed_ingestion_filters = [
            "INGESTED",
            "REJECTED",
            "UNKNOWN",
            "EXPERIMENT",
            "FG_DATA",
        ]
        if isinstance(filter_by, list):
            ingestion_filters = []
            for ingestion_filter in filter_by:
                if ingestion_filter.upper() in allowed_ingestion_filters:
                    ingestion_filters.append(
                        f"ingestion_result_eq:{ingestion_filter.upper()}"
                    )
                else:
                    raise ValueError(
                        f"Illegal Value {ingestion_filter} in filter_by."
                        f"Allowed values are {', '.join(allowed_ingestion_filters)}"
                    )

        query_params["filter_by"].extend(ingestion_filters)

        if (
            start_validation_time
            and end_validation_time
            and util._convert_event_time_to_timestamp(start_validation_time)
            > util._convert_event_time_to_timestamp(end_validation_time)
        ):
            raise ValueError(
                f"start_validation_time : {start_validation_time} is posterior to end_validation_time : {end_validation_time}"
            )

        if start_validation_time:
            query_params["filter_by"].append(
                "validation_time_gte:"
                + str(util._convert_event_time_to_timestamp(start_validation_time))
            )
        if end_validation_time:
            query_params["filter_by"].append(
                "validation_time_lte:"
                + str(util._convert_event_time_to_timestamp(end_validation_time))
            )

        return query_params

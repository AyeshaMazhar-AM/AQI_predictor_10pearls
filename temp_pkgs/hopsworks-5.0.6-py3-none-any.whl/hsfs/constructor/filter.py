#
#   Copyright 2020 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

import json
from typing import Any, Literal

from hopsworks_apigen import public
from hsfs import feature, util


@public
class Filter:
    GE = "GREATER_THAN_OR_EQUAL"
    GT = "GREATER_THAN"
    NE = "NOT_EQUALS"
    EQ = "EQUALS"
    LE = "LESS_THAN_OR_EQUAL"
    LT = "LESS_THAN"
    IN = "IN"
    LK = "LIKE"

    def __init__(
        self, feature: feature.Feature, condition: str, value: Any, **kwargs
    ) -> None:
        self._feature = feature
        self._condition = condition
        self._value = value

    @classmethod
    def from_response_json(cls, json_dict: dict[str, Any]) -> Filter | None:
        if json_dict is None:
            return None

        return cls(
            feature=feature.Feature.from_response_json(json_dict["feature"]),
            condition=json_dict["condition"],
            value=json_dict["value"],
        )

    def json(self) -> str:
        return json.dumps(self, cls=util.Encoder)

    def to_dict(self) -> dict[str, Any]:
        return {
            "feature": self._feature,
            "condition": self._condition,
            "value": str(self._value) if self._value is not None else None,
        }

    def __and__(self, other: Logic | Filter) -> Logic:
        if isinstance(other, Filter):
            return Logic._And(left_f=self, right_f=other)
        if isinstance(other, Logic):
            return Logic._And(left_f=self, right_l=other)
        raise TypeError(
            f"Operator `&` expected type `Filter` or `Logic`, got `{type(other)}`"
        )

    def __or__(self, other: Filter | Logic) -> Logic:
        if isinstance(other, Filter):
            return Logic._Or(left_f=self, right_f=other)
        if isinstance(other, Logic):
            return Logic._Or(left_f=self, right_l=other)
        raise TypeError(
            f"Operator `|` expected type `Filter` or `Logic`, got `{type(other)}`"
        )

    def __repr__(self) -> str:
        return f"Filter({self._feature!r}, {self._condition!r}, {self._value!r})"

    def __str__(self) -> str:
        return self.json()

    @public
    @property
    def feature(self) -> feature.Feature:
        """The feature the filter is applied on."""
        return self._feature

    @public
    @property
    def condition(
        self,
    ) -> Literal[
        "GREATER_THAN_OR_EQUAL",
        "GREATER_THAN",
        "NOT_EQUALS",
        "EQUALS",
        "LESS_THAN_OR_EQUAL",
        "LESS_THAN",
        "IN",
        "LIKE",
    ]:
        """Condition of the filter."""
        return self._condition

    @public
    @property
    def value(self) -> Any:
        """Value of the filter."""
        return self._value


@public
class Logic:
    AND = "AND"
    OR = "OR"
    SINGLE = "SINGLE"

    def __init__(
        self,
        type: str | None,
        left_f: Filter | None = None,
        right_f: Filter | None = None,
        left_l: Logic | None = None,
        right_l: Logic | None = None,
        **kwargs,
    ) -> None:
        self._type = type
        self._left_f = left_f
        self._right_f = right_f
        self._left_l = left_l
        self._right_l = right_l

    def json(self) -> str:
        return json.dumps(self, cls=util.Encoder)

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self._type,
            "leftFilter": self._left_f,
            "rightFilter": self._right_f,
            "leftLogic": self._left_l,
            "rightLogic": self._right_l,
        }

    @classmethod
    def from_response_json(cls, json_dict: dict[str, Any] | None) -> Logic | None:
        if json_dict is None:
            return None

        return cls(
            type=json_dict.get("type", None),
            left_f=Filter.from_response_json(json_dict.get("left_filter", None)),
            right_f=Filter.from_response_json(json_dict.get("right_filter", None)),
            left_l=Logic.from_response_json(json_dict.get("left_logic", None)),
            right_l=Logic.from_response_json(json_dict.get("right_logic", None)),
        )

    @classmethod
    def _And(
        cls,
        left_f: Filter | None = None,
        right_f: Filter | None = None,
        left_l: Logic | None = None,
        right_l: Logic | None = None,
    ) -> Logic:
        return cls(cls.AND, left_f, right_f, left_l, right_l)

    @classmethod
    def _Or(
        cls,
        left_f: Filter | None = None,
        right_f: Filter | None = None,
        left_l: Logic | None = None,
        right_l: Logic | None = None,
    ) -> Logic:
        return cls(cls.OR, left_f, right_f, left_l, right_l)

    @classmethod
    def _Single(cls, left_f: Filter) -> Logic:
        return cls(cls.SINGLE, left_f)

    def __and__(self, other: Filter | Logic) -> Logic:
        if isinstance(other, Filter):
            return Logic._And(left_l=self, right_f=other)
        if isinstance(other, Logic):
            return Logic._And(left_l=self, right_l=other)
        raise TypeError(
            f"Operator `&` expected type `Filter` or `Logic`, got `{type(other)}`"
        )

    def __or__(self, other: Logic) -> Logic:
        if isinstance(other, Filter):
            return Logic._Or(left_l=self, right_f=other)
        if isinstance(other, Logic):
            return Logic._Or(left_l=self, right_l=other)
        raise TypeError(
            f"Operator `|` expected type `Filter` or `Logic`, got `{type(other)}`"
        )

    def __repr__(self) -> str:
        return f"Logic({self._type!r}, {self._left_f!r}, {self._right_f!r}, {self._left_l!r}, {self._right_l!r})"

    def __str__(self) -> str:
        return self.json()

    @public
    @property
    def type(self) -> Literal["AND", "OR", "SINGLE"] | None:
        """Type of the logical operator."""
        return self._type

    @public
    def get_left_filter_or_logic(self) -> Filter | Logic:
        """Left side of the logical operator.

        Returns:
            The left side of the logical operator.
        """
        return self._left_f or self._left_l

    @public
    def get_right_filter_or_logic(self) -> Filter | Logic | None:
        """Right side of the logical operator.

        Returns:
            The right side of the logical operator.
        """
        return self._right_f or self._right_l

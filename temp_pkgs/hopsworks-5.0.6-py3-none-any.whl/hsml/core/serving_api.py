#
#   Copyright 2022 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

import json
from typing import Any

from hopsworks_common import tag
from hsml import (
    client,
    decorators,
    deployable_component_logs,
    deployment,
    inference_endpoint,
    predictor_state,
)
from hsml.client.istio.utils.infer_type import (
    InferInput,
    InferOutput,
    InferRequest,
)
from hsml.constants import INFERENCE_ENDPOINTS as IE


class ServingApi:
    def __init__(self):
        pass

    @decorators._catch_not_found("hsml.deployment.Deployment", fallback_return=None)
    def _get_by_id(self, id: int) -> deployment.Deployment | None:
        """Get the metadata of a deployment with a certain id.

        Parameters:
            id: Id of the deployment.

        Returns:
            Deployment metadata object.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            str(id),
        ]
        query_params = {"expand": ["mandatorytags"]}

        deployment_json = _client._send_request(
            "GET", path_params, query_params=query_params
        )
        deployment_instance = deployment.Deployment.from_response_json(deployment_json)
        deployment_instance.model_registry_id = _client._project_id
        deployment_instance.project_name = _client._project_name
        return deployment_instance

    @decorators._catch_not_found("hsml.deployment.Deployment", fallback_return=None)
    def _get(self, name: str) -> deployment.Deployment | None:
        """Get the metadata of a deployment with a certain name.

        Parameters:
            name: Name of the deployment.

        Returns:
            Deployment metadata object.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "serving"]
        query_params = {"name": name, "expand": ["mandatorytags"]}

        deployment_json = _client._send_request(
            "GET", path_params, query_params=query_params
        )
        deployment_instance = deployment.Deployment.from_response_json(deployment_json)
        deployment_instance.model_registry_id = _client._project_id
        deployment_instance.project_name = _client._project_name
        return deployment_instance

    def _get_all(
        self, model_name: str = None, status: str = None
    ) -> list[deployment.Deployment]:
        """Get the metadata of all deployments.

        Parameters:
            model_name: filter deployments by model name
            status: filter deployments by status

        Returns:
            List of deployment metadata objects.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "serving"]
        query_params = {
            "model": model_name,
            "status": status.capitalize() if status is not None else None,
        }
        deployments_json = _client._send_request(
            "GET", path_params, query_params=query_params
        )
        deployment_instances = deployment.Deployment.from_response_json(
            deployments_json
        )
        for deployment_instance in deployment_instances:
            deployment_instance.model_registry_id = _client._project_id
            deployment_instance.project_name = _client._project_name
        return deployment_instances

    def _set_tag(
        self, deployment_instance: deployment.Deployment, name: str, value: Any
    ) -> None:
        """Attach a name/value tag to a deployment.

        A tag consists of a name/value pair.
        Tag names are unique identifiers.
        The value of a tag can be any valid json - primitives, arrays or json objects.

        Parameters:
            deployment_instance: deployment instance to attach the tag to
            name: name of the tag to be added
            value: value of the tag to be added
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            str(deployment_instance.id),
            "tags",
            name,
        ]
        headers = {"content-type": "application/json"}
        json_value = json.dumps(value)
        _client._send_request("PUT", path_params, headers=headers, data=json_value)

    def _delete_tag(
        self, deployment_instance: deployment.Deployment, name: str
    ) -> None:
        """Delete a tag attached to a deployment.

        Tag names are unique identifiers.

        Parameters:
            deployment_instance: deployment instance to delete the tag from
            name: name of the tag to be removed
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            str(deployment_instance.id),
            "tags",
            name,
        ]
        _client._send_request("DELETE", path_params)

    @decorators._catch_not_found("hopsworks_common.tag.Tag", fallback_return={})
    def _get_tags(self, deployment_instance: deployment.Deployment) -> dict[str, Any]:
        """Get all tags attached to a deployment.

        Parameters:
            deployment_instance: deployment instance to get the tags from

        Returns:
            dict of tag name/values
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            str(deployment_instance.id),
            "tags",
        ]
        return {
            t._name: t._value
            for t in tag.Tag.from_response_json(
                _client._send_request("GET", path_params)
            )
        }

    @decorators._catch_not_found("hopsworks_common.tag.Tag", fallback_return=None)
    def _get_tag(
        self, deployment_instance: deployment.Deployment, name: str
    ) -> Any | None:
        """Get the tag with a specific name attached to a deployment.

        Parameters:
            deployment_instance: deployment instance to get the tag from
            name: tag name

        Returns:
            the tag value, or `None` if it does not exist
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            str(deployment_instance.id),
            "tags",
            name,
        ]
        tags = {
            t._name: t._value
            for t in tag.Tag.from_response_json(
                _client._send_request("GET", path_params)
            )
        }
        return tags.get(name)

    def _get_inference_endpoints(self) -> list[inference_endpoint.InferenceEndpoint]:
        """Get inference endpoints.

        Returns:
            Inference endpoints for the current project.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "inference", "endpoints"]
        endpoints_json = _client._send_request("GET", path_params)
        return inference_endpoint.InferenceEndpoint.from_response_json(endpoints_json)

    def _put(self, deployment_instance: deployment.Deployment) -> deployment.Deployment:
        """Save deployment metadata to model serving.

        Parameters:
            deployment_instance: Metadata object of deployment to be saved.

        Returns:
            Updated metadata object of the deployment.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "serving"]
        headers = {"content-type": "application/json"}

        deployment_instance = deployment_instance.update_from_response_json(
            _client._send_request(
                "PUT",
                path_params,
                headers=headers,
                data=deployment_instance.json(),
            )
        )
        deployment_instance.model_registry_id = _client._project_id
        deployment_instance.project_name = _client._project_name
        return deployment_instance

    def _post(self, deployment_instance: deployment.Deployment, action: str):
        """Perform an action on the deployment.

        Parameters:
            deployment_instance: Metadata object of the deployment.
            action: Action to perform on the deployment (i.e., START or STOP).
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            deployment_instance.id,
        ]
        query_params = {"action": action}
        return _client._send_request("POST", path_params, query_params=query_params)

    def _delete(self, deployment_instance: deployment.Deployment):
        """Delete the deployment and metadata.

        Parameters:
            deployment_instance: Metadata object of the deployment to delete.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            deployment_instance.id,
        ]
        return _client._send_request("DELETE", path_params)

    def _get_state(
        self, deployment_instance: deployment.Deployment
    ) -> predictor_state.PredictorState:
        """Get the state of a given deployment.

        Parameters:
            deployment_instance: Metadata object of the deployment to get state of.

        Returns:
            Predictor state.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            str(deployment_instance.id),
        ]
        deployment_json = _client._send_request("GET", path_params)
        return predictor_state.PredictorState.from_response_json(deployment_json)

    def _reset_changes(
        self, deployment_instance: deployment.Deployment
    ) -> deployment.Deployment:
        """Reset a given deployment to the original values in the Hopsworks instance.

        Parameters:
            deployment_instance: Metadata object of the deployment to reset.

        Returns:
            Deployment with reset values.
        """
        _client = client._get_instance()
        path_params = ["project", _client._project_id, "serving"]
        query_params = {"name": deployment_instance.name}
        deployment_json = _client._send_request(
            "GET", path_params, query_params=query_params
        )
        deployment_aux = deployment_instance.update_from_response_json(deployment_json)
        # TODO: remove when model_registry_id is added properly to deployments in backend
        deployment_aux.model_registry_id = _client._project_id
        deployment_aux.project_name = _client._project_name
        return deployment_aux

    def _send_inference_request(
        self,
        deployment_instance: deployment.Deployment,
        data: dict | list[InferInput],
        through_hopsworks: bool = False,
    ) -> dict | list[InferOutput]:
        """Send inference requests to a deployment with a certain id.

        Parameters:
            deployment_instance: Metadata object of the deployment to be used for the prediction.
            data: Payload of the inference request.
            through_hopsworks: Whether to send the inference request through the Hopsworks REST API or not.

        Returns:
            Inference response.
        """
        if deployment_instance.api_protocol == IE.API_PROTOCOL_REST:
            # REST protocol, use hopsworks or istio client
            return self._send_inference_request_via_rest_protocol(
                deployment_instance, data, through_hopsworks
            )
        # gRPC protocol, use the deployment grpc channel
        return self._send_inference_request_via_grpc_protocol(deployment_instance, data)

    def _send_inference_request_via_rest_protocol(
        self,
        deployment_instance,
        data: dict,
        through_hopsworks: bool = False,
    ) -> dict:
        headers = {"content-type": "application/json"}
        if through_hopsworks:
            # use Hopsworks client
            _client = client._get_instance()
            path_params = self._get_hopsworks_inference_path(
                _client._project_id, deployment_instance
            )
            with_base_path_params = True
        else:
            _client = client.istio._get_instance()
            if _client is not None:
                # use istio client
                path_params = self._get_istio_inference_path(deployment_instance)
                with_base_path_params = False
            else:
                # fallback to Hopsworks client
                _client = client._get_instance()
                path_params = self._get_hopsworks_inference_path(
                    _client._project_id, deployment_instance
                )
                with_base_path_params = True

        # send inference request
        return _client._send_request(
            "POST",
            path_params,
            headers=headers,
            data=json.dumps(data),
            with_base_path_params=with_base_path_params,
        )

    def _send_inference_request_via_grpc_protocol(
        self, deployment_instance, data: list[InferInput]
    ) -> list[InferOutput]:
        # get grpc channel
        if deployment_instance._grpc_channel is None:
            # The gRPC channel is lazily initialized. The first call to deployment.predict() will initialize
            # the channel, which will be reused in all following calls on the same deployment object.
            # The gRPC channel is freed when calling deployment.stop()
            print("Initializing gRPC channel...")
            deployment_instance._grpc_channel = self._create_grpc_channel(
                deployment_instance
            )
        # build an infer request
        request = InferRequest(
            infer_inputs=data,
            model_name=deployment_instance.name,
        )

        # send infer request
        infer_response = deployment_instance._grpc_channel.infer(
            infer_request=request, headers=None
        )

        # extract infer outputs
        return infer_response.outputs

    def _create_grpc_channel(self, deployment_instance):
        _client = client.istio._get_instance()
        path_prefix = (
            f"/v1/{deployment_instance.project_name}/{deployment_instance.name}"
        )
        return _client._create_grpc_channel(path_prefix)

    def _is_kserve_installed(self) -> bool:
        """Check if kserve is installed.

        Returns:
            Whether kserve is installed.
        """
        _client = client._get_instance()
        path_params = ["variables", "kube_kserve_installed"]
        kserve_installed = _client._send_request("GET", path_params)
        return (
            "successMessage" in kserve_installed
            and kserve_installed["successMessage"] == "true"
        )

    def _get_num_instances_limits(self) -> list[int]:
        """Get number of instances limits for model serving.

        Returns:
            A list of [min_instances, max_instances].
        """
        _client = client._get_instance()

        path_params = ["variables", "kube_serving_min_num_instances"]
        min_instances = _client._send_request("GET", path_params)

        path_params = ["variables", "kube_serving_max_num_instances"]
        max_instances = _client._send_request("GET", path_params)

        return [
            int(min_instances["successMessage"]),
            int(max_instances["successMessage"]),
        ]

    def _get_knative_domain(self) -> str:
        """Get the domain used by knative.

        Returns:
            The knative domain name string.
        """
        _client = client._get_instance()

        path_params = ["variables", "kube_knative_domain_name"]
        domain = _client._send_request("GET", path_params)

        return domain["successMessage"]

    def _get_logs(
        self,
        deployment_instance: deployment.Deployment,
        component: str,
        tail: int,
        source: str | None = None,
        since: str | None = None,
        until: str | None = None,
        pod: str | None = None,
    ) -> list[deployable_component_logs.DeployableComponentLogs]:
        """Get the logs of a deployment.

        Parameters:
            deployment_instance: Metadata object of the deployment to get logs from.
            component: Deployment component (e.g., predictor or transformer).
            tail: Number of tailing lines to retrieve.
            source: ``"opensearch"`` for historical logs from the project's
                serving index (works for stopped deployments), ``"kubernetes"``
                for live pod-tailing. Default ``None`` lets the backend
                pick the legacy Kubernetes path.
            since: ISO-8601 lower bound on the log timestamp; ignored on
                the Kubernetes path.
            until: ISO-8601 upper bound on the log timestamp; ignored on
                the Kubernetes path.
            pod: Restrict to a single instance / container name.

        Returns:
            Deployment logs.
        """
        _client = client._get_instance()
        path_params = [
            "project",
            _client._project_id,
            "serving",
            deployment_instance.id,
            "logs",
        ]
        query_params: dict = {"component": component, "tail": tail}
        # Only forward optional params when set so the wire format stays
        # identical to the pre-CLI release for old call sites.
        if source is not None:
            query_params["source"] = source
        if since is not None:
            query_params["since"] = since
        if until is not None:
            query_params["until"] = until
        if pod is not None:
            query_params["pod"] = pod
        return deployable_component_logs.DeployableComponentLogs.from_response_json(
            _client._send_request("GET", path_params, query_params=query_params)
        )

    def _get_hopsworks_inference_path(
        self, project_id: int, deployment_instance
    ) -> list[str]:
        """Get the Hopsworks inference path for a deployment.

        Inference requests sent to this path will be forwarded by Hopsworks to the Istio ingress endpoint.

        Parameters:
            project_id: Id of the project.
            deployment_instance: Metadata object of the deployment to get the inference path for.

        Returns:
            List of path segments.
        """
        return [
            "project",
            project_id,
            "inference",
            "models",
            deployment_instance.name + ":predict",
        ]

    def _get_istio_inference_path(
        self, deployment_instance, base_only: bool = False
    ) -> list[str]:
        """Get the Istio inference path for a deployment.

        Parameters:
            deployment_instance: Metadata object of the deployment to get the inference path for.
            base_only: If `True`, return only the base path. Used for vLLM and Python deployments without a model.

        Returns:
            List of path segments.
        """
        base_path = ["v1", deployment_instance.project_name, deployment_instance.name]
        if base_only:
            return base_path
        return base_path + ["v1", "models", deployment_instance.name + ":predict"]

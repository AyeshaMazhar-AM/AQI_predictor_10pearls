#
#   Copyright 2022 Logical Clocks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

import os
import tempfile
import time
import uuid

from hopsworks_common.client.exceptions import ModelServingException, RestAPIError
from hopsworks_common.client.istio.utils.infer_type import InferInput
from hopsworks_common.constants import (
    DEPLOYMENT,
    MODEL_REGISTRY,
    MODEL_SERVING,
    PREDICTOR,
    PREDICTOR_STATE,
)
from hopsworks_common.constants import INFERENCE_ENDPOINTS as IE
from hopsworks_common.core import dataset_api, inode
from hsml.core import serving_api
from hsml.engine import local_engine
from tqdm.auto import tqdm


def _render_chunk(chunk) -> str:
    r"""Render a single log chunk's content with a trailing newline.

    Adding a newline here (rather than relying on the upstream pipeline) lets
    ``read_logs(...)`` produce output you can pipe straight to ``grep`` or
    ``awk`` without each block getting glued to the next one. We only add the
    separator when content does not already end in ``\n`` so we never
    double-space lines that already carry their own terminator.
    """
    content = chunk.content or ""
    if content and not content.endswith("\n"):
        content += "\n"
    return content


class ServingEngine:
    START_STEPS = [
        PREDICTOR_STATE.CONDITION_TYPE_STOPPED,
        PREDICTOR_STATE.CONDITION_TYPE_SCHEDULED,
        PREDICTOR_STATE.CONDITION_TYPE_INITIALIZED,
        PREDICTOR_STATE.CONDITION_TYPE_STARTED,
        PREDICTOR_STATE.CONDITION_TYPE_READY,
    ]
    STOP_STEPS = [
        PREDICTOR_STATE.CONDITION_TYPE_SCHEDULED,
        PREDICTOR_STATE.CONDITION_TYPE_STOPPED,
    ]

    def __init__(self):
        self._serving_api = serving_api.ServingApi()
        self._dataset_api = dataset_api.DatasetApi()

        self._engine = local_engine.LocalEngine()

    def _set_tag(self, deployment_instance, name: str, value):
        """Attach a name/value tag to a deployment.

        Parameters:
            deployment_instance: the deployment to tag
            name: tag name
            value: tag value
        """
        self._serving_api._set_tag(deployment_instance, name, value)

    def _delete_tag(self, deployment_instance, name: str):
        """Remove a tag from a deployment.

        Parameters:
            deployment_instance: the deployment to remove the tag from
            name: tag name to remove
        """
        self._serving_api._delete_tag(deployment_instance, name)

    def _get_tag(self, deployment_instance, name: str):
        """Get tag with a certain name.

        Parameters:
            deployment_instance: the deployment to get the tag from
            name: tag name
        """
        return self._serving_api._get_tag(deployment_instance, name)

    def _get_tags(self, deployment_instance):
        """Get all tags for a deployment.

        Parameters:
            deployment_instance: the deployment to get tags from
        """
        return self._serving_api._get_tags(deployment_instance)

    def _poll_deployment_status(
        self, deployment_instance, status: str, await_status: int, update_progress=None
    ):
        if await_status > 0:
            sleep_seconds = 5
            for _ in range(int(await_status / sleep_seconds)):
                time.sleep(sleep_seconds)
                state = deployment_instance.get_state()
                num_instances = self._get_available_instances(state)
                if update_progress is not None:
                    update_progress(state, num_instances)
                if state.status == status:
                    return state  # deployment reached desired status
                if (
                    status == PREDICTOR_STATE.STATUS_RUNNING
                    and state.status == PREDICTOR_STATE.STATUS_FAILED
                ):
                    error_msg = state.condition.reason
                    if (
                        state.condition.type
                        == PREDICTOR_STATE.CONDITION_TYPE_INITIALIZED
                        or state.condition.type
                        == PREDICTOR_STATE.CONDITION_TYPE_STARTED
                    ):
                        component = (
                            "transformer"
                            if "transformer" in state.condition.reason
                            else "predictor"
                        )
                        error_msg += (
                            ". Please, check the server logs using `.get_logs(component='"
                            + component
                            + "')`"
                        )
                    raise ModelServingException(error_msg)
            raise ModelServingException(
                "Deployment has not reached the desired status within the expected awaiting time. Check the current status by using `.get_state()`, "
                "explore the server logs using `.get_logs()` or set a higher value for await_"
                + status.lower()
            )
        return None

    def _start(self, deployment_instance, await_status: int) -> bool:
        (done, state) = self._check_status(
            deployment_instance, PREDICTOR_STATE.STATUS_RUNNING
        )

        if not done:
            min_instances = self._get_min_starting_instances(deployment_instance)
            num_steps = (len(self.START_STEPS) - 1) + min_instances
            if deployment_instance._predictor._state.condition is None:
                num_steps = min_instances  # backward compatibility
            pbar = tqdm(total=num_steps)
            pbar.set_description("Creating deployment")

            # set progress function
            def update_progress(state, num_instances):
                (progress, desc) = self._get_starting_progress(
                    pbar.n, state, num_instances
                )
                pbar.update(progress)
                if desc is not None:
                    pbar.set_description(desc)

            try:
                update_progress(state, num_instances=0)

                if state.status == PREDICTOR_STATE.STATUS_CREATING:
                    state = self._poll_deployment_status(  # wait for preparation
                        deployment_instance,
                        PREDICTOR_STATE.STATUS_CREATED,
                        await_status,
                        update_progress,
                    )

                self._serving_api._post(
                    deployment_instance, DEPLOYMENT.ACTION_START
                )  # start deployment

                state = self._poll_deployment_status(  # wait for status
                    deployment_instance,
                    PREDICTOR_STATE.STATUS_RUNNING,
                    await_status,
                    update_progress,
                )
            except RestAPIError as re:
                self._stop(deployment_instance, await_status=0)
                raise re

        if state.status == PREDICTOR_STATE.STATUS_RUNNING:
            if deployment_instance.model_server == PREDICTOR.MODEL_SERVER_VLLM:
                print("Start prompting using any OpenAI API-compatible client.")
            elif not deployment_instance.has_model:
                print("Start sending requests with your HTTP client of preference.")
            else:
                print("Start making predictions by using `.predict()`")

    def _stop(self, deployment_instance, await_status: int) -> bool:
        (done, state) = self._check_status(
            deployment_instance, PREDICTOR_STATE.STATUS_STOPPED
        )
        if not done:
            num_instances = self._get_available_instances(state)
            num_steps = len(self.STOP_STEPS) + (
                deployment_instance.requested_instances
                if deployment_instance.requested_instances >= num_instances
                else num_instances
            )
            if deployment_instance._predictor._state.condition is None:
                # backward compatibility
                num_steps = self._get_min_starting_instances(deployment_instance)
            pbar = tqdm(total=num_steps)
            pbar.set_description("Preparing to stop deployment")

            # set progress function
            def update_progress(state, num_instances):
                (progress, desc) = self._get_stopping_progress(
                    pbar.total, pbar.n, state, num_instances
                )
                pbar.update(progress)
                if desc is not None:
                    pbar.set_description(desc)

            update_progress(state, num_instances)
            self._serving_api._post(
                deployment_instance, DEPLOYMENT.ACTION_STOP
            )  # stop deployment

            _ = self._poll_deployment_status(  # wait for status
                deployment_instance,
                PREDICTOR_STATE.STATUS_STOPPED,
                await_status,
                update_progress,
            )

        # free grpc channel
        deployment_instance._grpc_channel = None

    def _check_status(self, deployment_instance, desired_status):
        state = deployment_instance.get_state()
        if state is None:
            return (True, None)

        # desired status: running
        if desired_status == PREDICTOR_STATE.STATUS_RUNNING:
            if (
                state.status == PREDICTOR_STATE.STATUS_RUNNING
                or state.status == PREDICTOR_STATE.STATUS_IDLE
            ):
                print("Deployment is already running")
                return (True, state)
            if state.status == PREDICTOR_STATE.STATUS_STARTING:
                print("Deployment is already starting")
                return (True, state)
            if state.status == PREDICTOR_STATE.STATUS_UPDATING:
                print("Deployments is already running and updating")
                return (True, state)
            if state.status == PREDICTOR_STATE.STATUS_FAILED:
                print("Deployment is in failed state. " + state.condition.reason)
                return (True, state)
            if state.status == PREDICTOR_STATE.STATUS_STOPPING:
                raise ModelServingException(
                    "Deployment is stopping, please wait until it completely stops"
                )

        # desired status: stopped
        if desired_status == PREDICTOR_STATE.STATUS_STOPPED:
            if (
                state.status == PREDICTOR_STATE.STATUS_CREATING
                or state.status == PREDICTOR_STATE.STATUS_CREATED
                or state.status == PREDICTOR_STATE.STATUS_STOPPED
            ):
                print("Deployment is already stopped")
                return (True, state)
            if state.status == PREDICTOR_STATE.STATUS_STOPPING:
                print("Deployment is already stopping")
                return (True, state)

        return (False, state)

    def _get_starting_progress(self, current_step, state, num_instances):
        if state.condition is None:  # backward compatibility
            progress = num_instances - current_step
            if state.status == PREDICTOR_STATE.STATUS_RUNNING:
                return (progress, "Deployment is ready")
            return (progress, None if current_step == 0 else "Deployment is starting")

        step = self.START_STEPS.index(state.condition.type)
        if (
            state.condition.type == PREDICTOR_STATE.CONDITION_TYPE_STARTED
            or state.condition.type == PREDICTOR_STATE.CONDITION_TYPE_READY
        ):
            step += num_instances
        progress = step - current_step
        desc = None
        if state.condition.type != PREDICTOR_STATE.CONDITION_TYPE_STOPPED:
            desc = (
                state.condition.reason
                if state.status != PREDICTOR_STATE.STATUS_FAILED
                else "Deployment failed to start"
            )
        return (progress, desc)

    def _get_stopping_progress(self, total_steps, current_step, state, num_instances):
        if state.condition is None:  # backward compatibility
            progress = (total_steps - num_instances) - current_step
            if state.status == PREDICTOR_STATE.STATUS_STOPPED:
                return (progress, "Deployment is stopped")
            return (
                progress,
                None if total_steps == current_step else "Deployment is stopping",
            )

        step = 0
        if state.condition.type == PREDICTOR_STATE.CONDITION_TYPE_SCHEDULED:
            step = 1 if state.condition.status is None else 0
        elif state.condition.type == PREDICTOR_STATE.CONDITION_TYPE_STOPPED:
            num_instances = (total_steps - 2) - num_instances  # num stopped instances
            step = (
                (2 + num_instances)
                if (state.condition.status is None or state.condition.status)
                else 0
            )
        progress = step - current_step
        desc = None
        if (
            state.condition.type != PREDICTOR_STATE.CONDITION_TYPE_READY
            and state.status != PREDICTOR_STATE.STATUS_FAILED
        ):
            desc = (
                "Deployment is stopped"
                if state.status == PREDICTOR_STATE.STATUS_STOPPED
                else state.condition.reason
            )

        return (progress, desc)

    def _get_min_starting_instances(self, deployment_instance):
        min_start_instances = 1  # predictor
        if deployment_instance.transformer is not None:
            min_start_instances += 1  # transformer
        return (
            deployment_instance.requested_instances
            if deployment_instance.requested_instances >= min_start_instances
            else min_start_instances
        )

    def _get_available_instances(self, state):
        if state.status == PREDICTOR_STATE.STATUS_CREATING:
            return 0
        num_instances = state.available_predictor_instances
        if state.available_transformer_instances is not None:
            num_instances += state.available_transformer_instances
        return num_instances

    def _get_stopped_instances(self, available_instances, requested_instances):
        num_instances = requested_instances - available_instances
        return num_instances if num_instances >= 0 else 0

    def _download_files_from_hopsfs_recursive(
        self,
        from_hdfs_path: str,
        to_local_path: str,
        update_download_progress,
        n_dirs,
        n_files,
    ):
        """Download model files from a model path in hdfs, recursively."""
        count, items = self._dataset_api._list_dataset_path(
            from_hdfs_path, inode.Inode, sort_by="NAME:desc"
        )
        for entry in items:
            basename = os.path.basename(entry.path)
            if entry.dir:
                # otherwise, make a recursive call for the folder
                if (
                    basename == MODEL_SERVING.ARTIFACTS_DIR_NAME
                ):  # NOTE: Keep for backward compatibility (<4.6). Existing models during upgrade contain Artifacts folder
                    continue  # skip Artifacts subfolder
                local_folder_path = os.path.join(to_local_path, basename)
                os.mkdir(local_folder_path)
                n_dirs, n_files = self._download_files_from_hopsfs_recursive(
                    from_hdfs_path=entry.path,
                    to_local_path=local_folder_path,
                    update_download_progress=update_download_progress,
                    n_dirs=n_dirs,
                    n_files=n_files,
                )
                n_dirs += 1
                update_download_progress(n_dirs=n_dirs, n_files=n_files)
            else:
                # if it's a file, download it
                local_file_path = os.path.join(to_local_path, basename)
                self._engine._download(entry.path, local_file_path)
                n_files += 1
                update_download_progress(n_dirs=n_dirs, n_files=n_files)

        return n_dirs, n_files

    def _download_files_from_hopsfs(
        self, from_hdfs_path: str, to_local_path: str, update_download_progress
    ):
        """Download files from a deployment path in hdfs."""
        n_dirs, n_files = self._download_files_from_hopsfs_recursive(
            from_hdfs_path=from_hdfs_path,
            to_local_path=to_local_path,
            update_download_progress=update_download_progress,
            n_dirs=0,
            n_files=0,
        )
        update_download_progress(n_dirs=n_dirs, n_files=n_files, done=True)

    def _download_artifact_files(self, deployment_instance, local_path=None):
        if deployment_instance.id is None:
            raise ModelServingException(
                "Deployment is not created yet. To create the deployment use `.save()`"
            )

        if local_path is None:
            local_path = os.path.join(
                tempfile.gettempdir(),
                str(uuid.uuid4()),
                deployment_instance.name,
                str(deployment_instance.version),
            )
        os.makedirs(local_path, exist_ok=True)

        def update_download_progress(n_dirs, n_files, done=False):
            print(
                "Downloading artifact files ({} dirs, {} files)... {}".format(
                    n_dirs, n_files, "DONE" if done else ""
                ),
                end="\r",
            )

        try:
            from_hdfs_path = deployment_instance.artifact_files_path
            if from_hdfs_path.startswith("hdfs:/"):
                projects_index = from_hdfs_path.find("/Projects", 0)
                from_hdfs_path = from_hdfs_path[projects_index:]

            # backward compatibility: running deployments during upgrade contain artifact files under /Models/name/version/Artifacts folder
            # if the deployment scales out, this method is used by storage-initializer to pull the files. Therefore, we need to pull files
            # from the legacy path if the deployment has not yet been migrated
            if deployment_instance.has_model and not self._dataset_api.path_exists(
                from_hdfs_path
            ):
                # legacy artifact version path under Models dataset
                legacy_from_hdfs_path = "{}/{}/{}/{}/{}/{}/{}".format(
                    "/Projects",
                    deployment_instance.project_name,
                    MODEL_REGISTRY.MODELS_DATASET,
                    deployment_instance.model_name,
                    str(deployment_instance.model_version),
                    MODEL_SERVING.ARTIFACTS_DIR_NAME,
                    str(deployment_instance.version),
                )
                if self._dataset_api.path_exists(legacy_from_hdfs_path):
                    from_hdfs_path = legacy_from_hdfs_path

            self._download_files_from_hopsfs(
                from_hdfs_path=from_hdfs_path,
                to_local_path=local_path,
                update_download_progress=update_download_progress,
            )
        except BaseException as be:
            raise be

        return local_path

    def _create(self, deployment_instance):
        try:
            self._serving_api._put(deployment_instance)
            print("Deployment created, explore it at " + deployment_instance.get_url())
        except RestAPIError as re:
            raise_err = True
            if re.error_code == ModelServingException.ERROR_CODE_DUPLICATED_ENTRY:
                msg = "Deployment with the same name already exists"
                existing_deployment = self._serving_api._get(deployment_instance.name)
                if (
                    existing_deployment.model_name == deployment_instance.model_name
                    and existing_deployment.model_version
                    == deployment_instance.model_version
                ):  # if same name and model version, retrieve existing deployment
                    print(msg + ". Getting existing deployment...")
                    print("To create a new deployment choose a different name.")
                    deployment_instance.update_from_response_json(
                        existing_deployment.to_dict()
                    )
                    raise_err = False
                else:  # otherwise, raise an exception
                    print(msg + ", but it is serving a different model version.")
                    print("Please, choose a different name.")

            if raise_err:
                raise re

        if deployment_instance.is_stopped():
            print("Before making predictions, start the deployment by using `.start()`")

    def _update(self, deployment_instance, await_update):
        state = deployment_instance.get_state()
        if state is None:
            return

        if state.status == PREDICTOR_STATE.STATUS_STARTING:
            # if starting, it cannot be updated yet
            raise ModelServingException(
                "Deployment is starting, please wait until it is running before applying changes. \n"
                "Check the current status by using `.get_state()` or explore the server logs using `.get_logs()`"
            )
        if (
            state.status == PREDICTOR_STATE.STATUS_RUNNING
            or state.status == PREDICTOR_STATE.STATUS_IDLE
            or state.status == PREDICTOR_STATE.STATUS_FAILED
        ):
            # if running, it's fine
            self._serving_api._put(deployment_instance)
            print("Deployment updated, applying changes to running instances...")
            state = self._poll_deployment_status(  # wait for status
                deployment_instance, PREDICTOR_STATE.STATUS_RUNNING, await_update
            )
            if state is not None and state.status == PREDICTOR_STATE.STATUS_RUNNING:
                print("Running instances updated successfully")
            return
        if state.status == PREDICTOR_STATE.STATUS_UPDATING:
            # if updating, it cannot be updated yet
            raise ModelServingException(
                "Deployment is updating, please wait until it is running before applying changes. \n"
                "Check the current status by using `.get_state()` or explore the server logs using `.get_logs()`"
            )
        if state.status == PREDICTOR_STATE.STATUS_STOPPING:
            # if stopping, it cannot be updated yet
            raise ModelServingException(
                "Deployment is stopping, please wait until it is stopped before applying changes"
            )
        if (
            state.status == PREDICTOR_STATE.STATUS_CREATING
            or state.status == PREDICTOR_STATE.STATUS_CREATED
            or state.status == PREDICTOR_STATE.STATUS_STOPPED
        ):
            # if stopped, it's fine
            self._serving_api._put(deployment_instance)
            print("Deployment updated, explore it at " + deployment_instance.get_url())
            return

        raise ValueError("Unknown deployment status: " + state.status)

    def _save(self, deployment_instance, await_update: int):
        if deployment_instance.id is None:
            # if new deployment
            self._create(deployment_instance)
            return

        # if existing deployment
        self._update(deployment_instance, await_update)

    def _delete(self, deployment_instance, force=False):
        state = deployment_instance.get_state()
        if state is None:
            return

        if (
            not force
            and state.status != PREDICTOR_STATE.STATUS_STOPPED
            and state.status != PREDICTOR_STATE.STATUS_CREATED
        ):
            raise ModelServingException(
                "Deployment not stopped, please stop it first by using `.stop()` or check its status with .get_state()"
            )

        self._serving_api._delete(deployment_instance)
        print("Deployment deleted successfully")

    def _get_state(self, deployment_instance):
        try:
            state = self._serving_api._get_state(deployment_instance)
        except RestAPIError as re:
            if re.error_code == ModelServingException.ERROR_CODE_SERVING_NOT_FOUND:
                raise ModelServingException("Deployment not found") from re
            raise re
        deployment_instance._predictor._set_state(state)
        return state

    def _get_logs(self, deployment_instance, component, tail):
        state = self._get_state(deployment_instance)
        if state is None:
            return None

        if state.status == PREDICTOR_STATE.STATUS_STOPPING:
            print(
                "Deployment is stopping, explore historical logs at "
                + deployment_instance.get_url()
            )
            return None
        if state.status == PREDICTOR_STATE.STATUS_STOPPED:
            print(
                "Deployment not running, explore historical logs at "
                + deployment_instance.get_url()
            )
            return None
        if state.status == PREDICTOR_STATE.STATUS_STARTING:
            print("Deployment is starting, server logs might not be ready yet")

        print(
            "Explore all the logs and filters in the Kibana logs at "
            + deployment_instance.get_url(),
            end="\n\n",
        )

        return self._serving_api._get_logs(deployment_instance, component, tail)

    # ----- Programmatic log APIs (read_logs / tail_logs) ---------------------
    # These never print and never short-circuit on deployment state. The
    # OpenSearch source returns logs even when the deployment is stopped, so
    # the legacy "deployment is stopping → return None" guard would just hide
    # data that is in fact retrievable.

    def _read_logs(
        self,
        deployment_instance,
        component: str = "predictor",
        tail: int = 100,
        source: str = "opensearch",
        since: str | None = None,
        until: str | None = None,
        pod: str | None = None,
    ) -> str:
        """Return deployment logs as a single plain-text string.

        Programmatic counterpart to :py:meth:`get_logs`. Never prints; the
        caller decides what to do with the returned value.

        Parameters:
            deployment_instance: The deployment whose logs to read.
            component: Which deployment component to read (``predictor``, ``transformer``).
            tail: Maximum number of recent log entries to fetch.
            source: Log source (``opensearch`` or ``kubernetes``).
            since: ISO-8601 lower bound for log timestamps, if any.
            until: ISO-8601 upper bound for log timestamps, if any.
            pod: Specific pod name to read logs for, if any.

        Returns:
            All matching log chunks concatenated into a single string.
        """
        chunks = self._serving_api._get_logs(
            deployment_instance,
            component,
            tail,
            source=source,
            since=since,
            until=until,
            pod=pod,
        )
        return self._format_log_chunks(chunks or [])

    def _tail_logs(
        self,
        deployment_instance,
        component: str = "predictor",
        interval: float = 2.0,
        source: str = "opensearch",
        since: str | None = "now",
        timeout: float | None = None,
        stop_on_status=None,
    ):
        """Yield only newly observed log chunks as plain text.

        v1 streaming is client-side polling: each tick calls
        :py:meth:`read_logs` with a moving ``since`` cursor and yields the
        portion not already seen. Deduplication is by (timestamp, doc_id)
        on the OpenSearch path and by content hash for the Kubernetes path
        (which has neither field). The generator stops when:

        - ``timeout`` (seconds, optional) elapses,
        - ``stop_on_status`` matches the current ``deployment.get_state().status``, or
        - the caller breaks out of the loop / closes the generator.

        Parameters:
            deployment_instance: The deployment whose logs to tail.
            component: Which deployment component to tail (``predictor``, ``transformer``).
            interval: Seconds between successive polls.
            source: Log source (``opensearch`` or ``kubernetes``).
            since: ISO-8601 starting cursor, or ``"now"`` for new-only.
            timeout: Stop after this many seconds, if set.
            stop_on_status: Stop when the deployment status matches this value.

        Yields:
            Log text observed since the previous yield.
        """
        # OpenSearch documents are uniquely identified by ``doc_id`` and
        # ordered by ``timestamp``; this state suffices to dedupe across
        # successive overlapping windows.
        seen_doc_ids: set[str] = set()
        last_timestamp: str | None = since if (since and since != "now") else None
        # Kubernetes path has no doc id / timestamp, so dedupe by content
        # hash instead. Bound the set so a chatty deployment doesn't keep
        # the dedupe state growing forever.
        seen_hashes: set[int] = set()
        seen_hashes_cap = 4096

        # ``since="now"`` is a UX shorthand: start streaming brand-new lines
        # only. Resolved here on the first call to a real ISO-8601 timestamp
        # so subsequent polls are time-bounded the same way.
        if since == "now":
            from datetime import datetime, timezone

            last_timestamp = datetime.now(tz=timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%S.%fZ"
            )

        deadline = (time.monotonic() + timeout) if timeout else None

        while True:
            chunks = (
                self._serving_api._get_logs(
                    deployment_instance,
                    component,
                    # Bounded per-poll fetch. Larger values just mean more work
                    # for the dedupe pass; the SDK still yields only what's new.
                    tail=200,
                    source=source,
                    since=last_timestamp,
                    until=None,
                    pod=None,
                )
                or []
            )

            new_chunks = []
            for chunk in chunks:
                if chunk.doc_id is not None:
                    if chunk.doc_id in seen_doc_ids:
                        continue
                    seen_doc_ids.add(chunk.doc_id)
                else:
                    key = hash((chunk.instance_name, chunk.content))
                    if key in seen_hashes:
                        continue
                    if len(seen_hashes) >= seen_hashes_cap:
                        # Drop the oldest half — set has no ordering, so we
                        # just clear and start fresh; worst case we re-yield
                        # at most ``seen_hashes_cap / 2`` already-seen lines
                        # once before steady state is restored.
                        seen_hashes = set()
                    seen_hashes.add(key)
                new_chunks.append(chunk)
                if chunk.timestamp is not None and (
                    last_timestamp is None or chunk.timestamp > last_timestamp
                ):
                    last_timestamp = chunk.timestamp

            if new_chunks:
                yield self._format_log_chunks(new_chunks)

            if stop_on_status is not None:
                state = self._get_state(deployment_instance)
                if state is not None and state.status == stop_on_status:
                    return

            if deadline is not None and time.monotonic() >= deadline:
                return

            time.sleep(interval)

    @staticmethod
    def _format_log_chunks(chunks) -> str:
        r"""Merge a list of ``DeployableComponentLogs`` into one plain string.

        When more than one distinct ``instance_name`` is present, prefix each
        block with ``==> <instance> <==\n`` (tail-style). Single-instance
        responses join contents directly so ``read_logs(...)`` round-trips
        cleanly through grep/awk.
        """
        if not chunks:
            return ""
        instance_names = {c.instance_name for c in chunks if c.instance_name}
        if len(instance_names) <= 1:
            return "".join(_render_chunk(c) for c in chunks)
        # Group chronologically per instance, then concatenate.
        by_instance: dict[str, list] = {}
        for c in chunks:
            by_instance.setdefault(c.instance_name or "", []).append(c)
        parts = []
        for instance, items in by_instance.items():
            parts.append(f"==> {instance} <==\n")
            for c in items:
                parts.append(_render_chunk(c))
        return "".join(parts)

    # Model inference

    def _predict(
        self,
        deployment_instance,
        data: dict | list[InferInput],
        inputs: dict | list[dict],
    ):
        # validate user-provided payload
        if deployment_instance.model_server == PREDICTOR.MODEL_SERVER_VLLM:
            raise ModelServingException(
                "Inference requests to LLM deployments are not supported by the `predict` method. Please, use any OpenAI API-compatible client instead."
            )

        self._validate_inference_payload(deployment_instance.api_protocol, data, inputs)

        # build inference payload based on API protocol
        payload = self._build_inference_payload(
            deployment_instance.api_protocol, data, inputs
        )

        # if not KServe, send request through Hopsworks
        serving_tool = deployment_instance.predictor.serving_tool
        through_hopsworks = serving_tool != PREDICTOR.SERVING_TOOL_KSERVE
        try:
            return self._serving_api._send_inference_request(
                deployment_instance, payload, through_hopsworks
            )
        except RestAPIError as re:
            if (
                re.response.status_code == RestAPIError.STATUS_CODE_NOT_FOUND
                or re.error_code
                == ModelServingException.ERROR_CODE_DEPLOYMENT_NOT_RUNNING
            ):
                raise ModelServingException(
                    "Deployment not created or running. If it is already created, start it by using `.start()` or check its status with .get_state()"
                ) from re

            re.args = (
                re.args[0] + "\n\n Check the model server logs by using `.get_logs()`",
            )
            raise re

    def _validate_inference_payload(
        self,
        api_protocol,
        data: dict | list[InferInput],
        inputs: dict | list[dict],
    ):
        """Validates the user-provided inference payload. Either data or inputs parameter is expected, but both cannot be provided together."""
        # check null inputs
        if data is not None and inputs is not None:
            raise ModelServingException(
                "Inference data and inputs parameters cannot be provided together."
            )
        # check data or inputs
        if data is not None:
            self._validate_inference_data(api_protocol, data)
        else:
            self._validate_inference_inputs(api_protocol, inputs)

    def _validate_inference_data(self, api_protocol, data: dict | list[InferInput]):
        """Validates the inference payload when provided through the `data` parameter.

        The data parameter contains the raw payload to be sent
        in the inference request and should have the corresponding type and format depending on the API protocol.
        For the REST protocol, data should be a dictionary. For GRPC protocol, one or more InferInput objects is expected.
        """
        if api_protocol == IE.API_PROTOCOL_REST:  # REST protocol
            if isinstance(data, dict):
                if "instances" not in data and "inputs" not in data:
                    raise ModelServingException(
                        "Inference data is missing 'instances' key."
                    )

                payload = data["instances"] if "instances" in data else data["inputs"]
                if not isinstance(payload, list):
                    raise ModelServingException(
                        "Instances field should contain a 2-dim list."
                    )
                if len(payload) == 0:
                    raise ModelServingException(
                        "Inference data cannot contain an empty list."
                    )
                # KServe V1 instances may be lists (columnar predictors) or
                # objects/dicts (custom predictors that key on field names).
                # Accept both; only reject bare scalars and empty entries.
                first = payload[0]
                if isinstance(first, list):
                    if len(first) == 0:
                        raise ModelServingException(
                            "Inference data cannot contain an empty list."
                        )
                elif isinstance(first, dict):
                    if len(first) == 0:
                        raise ModelServingException(
                            "Inference data cannot contain an empty object."
                        )
                else:
                    raise ModelServingException(
                        "Instances field should contain a list of lists or a "
                        "list of objects."
                    )
            else:  # not Dict
                if isinstance(data, InferInput) or (
                    isinstance(data, list) and isinstance(data[0], InferInput)
                ):
                    raise ModelServingException(
                        "Inference data cannot contain `InferInput` for deployments with gRPC protocol disabled. Use a dictionary instead."
                    )
                raise ModelServingException(
                    "Inference data must be a dictionary. Otherwise, use the `inputs` parameter."
                )

        else:  # gRPC protocol
            if isinstance(data, dict):
                raise ModelServingException(
                    "Inference data cannot be a dictionary for deployments with gRPC protocol enabled. "
                    "Create a `InferInput` object or use the `inputs` parameter instead."
                )
            if isinstance(data, list):
                if len(data) == 0:
                    raise ModelServingException(
                        "Inference data cannot contain an empty list."
                    )
                if not isinstance(data[0], InferInput):
                    raise ModelServingException(
                        "Inference data must contain a list of `InferInput` objects. Otherwise, use the `inputs` parameter."
                    )
            else:
                raise ModelServingException(
                    "Inference data must contain a list of `InferInput` objects for deployments with gRPC protocol enabled."
                )

    def _validate_inference_inputs(
        self, api_protocol, inputs: dict | list[dict], recursive_call=False
    ):
        """Validates the inference payload when provided through the `inputs` parameter.

        The inputs parameter contains only the payload values, which will be parsed when building the request payload.
        It can be either a dictionary or a list.
        """
        if isinstance(inputs, list):
            if len(inputs) == 0:
                raise ModelServingException("Inference inputs cannot be an empty list.")
            self._validate_inference_inputs(
                api_protocol, inputs[0], recursive_call=True
            )
        elif isinstance(inputs, InferInput):
            raise ModelServingException(
                "Inference inputs cannot be of type `InferInput`. Use the `data` parameter instead."
            )
        elif isinstance(inputs, dict):
            required_keys = ("name", "shape", "datatype", "data")
            if api_protocol == IE.API_PROTOCOL_GRPC and not all(
                k in inputs for k in required_keys
            ):
                raise ModelServingException(
                    f"Inference inputs is missing one or more keys. Required keys are [{', '.join(required_keys)}]."
                )
        elif not recursive_call or (api_protocol == IE.API_PROTOCOL_GRPC):
            # if it is the first call to this method, inputs have an invalid type/format
            # if GRPC protocol is used, only Dict type is valid for the input values
            raise ModelServingException(
                "Inference inputs type is not valid. Supported types are dictionary and list."
            )

    def _build_inference_payload(
        self,
        api_protocol,
        data: dict | list[InferInput],
        inputs: dict | list[dict],
    ):
        """Build the inference payload for an inference request.

        If the 'data' parameter is provided, this method ensures it has the correct format depending on the API protocol.
        Otherwise, if the 'inputs' parameter is provided, this method builds the correct request payload depending on the API protocol.
        """
        if data is not None:
            # data contains the raw payload (dict or InferInput), nothing needs to be changed
            return data
        # parse inputs
        return self._parse_inference_inputs(api_protocol, inputs)

    def _parse_inference_inputs(
        self, api_protocol, inputs: dict | list[dict], recursive_call=False
    ):
        if api_protocol == IE.API_PROTOCOL_REST:  # REST protocol
            if not isinstance(inputs, list):
                data = {"instances": [[inputs]]}  # wrap inputs in a 2-dim list
            else:
                data = {"instances": inputs}  # use given inputs list by default
                # check depth of the list: at least two levels are required for batch inference
                # if the content is neither a list or dict, wrap it in an additional list
                for i in inputs:
                    if not isinstance(i, list) and not isinstance(i, dict):
                        # if there are no two levels, wrap inputs in a list
                        data = {"instances": [inputs]}
                        break
        else:  # gRPC protocol
            if isinstance(inputs, dict):  # dict
                data = InferInput(
                    name=inputs["name"],
                    shape=inputs["shape"],
                    datatype=inputs["datatype"],
                    data=inputs["data"],
                    parameters=(inputs.get("parameters", None)),
                )
                if not recursive_call:
                    # if inputs is of type dict, return a singleton
                    data = [data]

            else:  # list[dict]
                data = inputs
                for index, inputs_item in enumerate(inputs):
                    data[index] = self._parse_inference_inputs(
                        api_protocol, inputs_item, recursive_call=True
                    )

        return data

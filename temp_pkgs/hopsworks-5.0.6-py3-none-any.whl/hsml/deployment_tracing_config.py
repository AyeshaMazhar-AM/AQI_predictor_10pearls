#
#   Copyright 2026 Hopsworks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
from __future__ import annotations

import json

import humps
from hopsworks_apigen import public
from hopsworks_common import util


@public
class DeploymentTracingConfig:
    """Tracing configuration for a serving deployment.

    Parameters:
        enabled: Whether tracing is enabled.
        otel_tracing_storage: Where traces are stored. Allowed values are
            ``online``, ``offline`` and ``both``. Defaults to ``online``.
        input_token_price_per_million_tokens: Optional input token price used to
            compute trace cost metrics.
        output_token_price_per_million_tokens: Optional output token price used to
            compute trace cost metrics.
    """

    STORAGE_ONLINE = "online"
    STORAGE_OFFLINE = "offline"
    STORAGE_BOTH = "both"
    VALID_STORAGES = (STORAGE_ONLINE, STORAGE_OFFLINE, STORAGE_BOTH)

    def __init__(
        self,
        enabled: bool | None = None,
        otel_tracing_storage: str | None = STORAGE_ONLINE,
        input_token_price_per_million_tokens: float | None = None,
        output_token_price_per_million_tokens: float | None = None,
    ):
        self._enabled = enabled
        self._otel_tracing_storage = self._validate_otel_tracing_storage(
            otel_tracing_storage
        )

        self._input_token_price_per_million_tokens = (
            input_token_price_per_million_tokens
        )
        self._output_token_price_per_million_tokens = (
            output_token_price_per_million_tokens
        )

    @public
    def describe(self):
        """Print a JSON description of the tracing configuration."""
        util.pretty_print(self)

    @classmethod
    def _validate_otel_tracing_storage(cls, otel_tracing_storage: str | None):
        if otel_tracing_storage is None:
            return cls.STORAGE_ONLINE
        if otel_tracing_storage not in cls.VALID_STORAGES:
            raise ValueError(
                "Tracing storage '{}' is not valid. Possible values are '{}'".format(
                    otel_tracing_storage, ", ".join(cls.VALID_STORAGES)
                )
            )
        return otel_tracing_storage

    @classmethod
    def from_response_json(cls, json_dict):
        json_decamelized = humps.decamelize(json_dict)
        return cls.from_json(json_decamelized)

    @classmethod
    def from_json(cls, json_decamelized):
        return DeploymentTracingConfig(**cls.extract_fields_from_json(json_decamelized))

    @classmethod
    def extract_fields_from_json(cls, json_decamelized):
        config = (
            json_decamelized.pop("tracing")
            if "tracing" in json_decamelized
            else json_decamelized.pop("tracing_config")
            if "tracing_config" in json_decamelized
            else json_decamelized
        )

        kwargs = {}
        kwargs["enabled"] = util._extract_field_from_json(config, "enabled")
        kwargs["otel_tracing_storage"] = util._extract_field_from_json(
            config, "otel_tracing_storage"
        )
        input_price = util._extract_field_from_json(
            config, "input_token_price_per_million_tokens"
        )
        if input_price is None:
            input_price = util._extract_field_from_json(
                config, "otel_input_token_price_per_million"
            )
        kwargs["input_token_price_per_million_tokens"] = input_price

        output_price = util._extract_field_from_json(
            config, "output_token_price_per_million_tokens"
        )
        if output_price is None:
            output_price = util._extract_field_from_json(
                config, "otel_output_token_price_per_million"
            )
        kwargs["output_token_price_per_million_tokens"] = output_price
        return kwargs

    def update_from_response_json(self, json_dict):
        json_decamelized = humps.decamelize(json_dict)
        self.__init__(**self.extract_fields_from_json(json_decamelized))
        return self

    def json(self):
        return json.dumps(self, cls=util.Encoder)

    def to_dict(self):
        json = {"otelTracingStorage": self._otel_tracing_storage}
        if self._enabled is not None:
            json["enabled"] = self._enabled
        if self._input_token_price_per_million_tokens is not None:
            json["otelInputTokenPricePerMillion"] = (
                self._input_token_price_per_million_tokens
            )
        if self._output_token_price_per_million_tokens is not None:
            json["otelOutputTokenPricePerMillion"] = (
                self._output_token_price_per_million_tokens
            )
        return json

    @public
    @property
    def enabled(self):
        """Whether tracing is enabled."""
        return self._enabled

    @enabled.setter
    def enabled(self, enabled: bool | None):
        self._enabled = enabled

    @public
    @property
    def otel_tracing_storage(self):
        """Where traces are stored."""
        return self._otel_tracing_storage

    @otel_tracing_storage.setter
    def otel_tracing_storage(self, otel_tracing_storage: str | None):
        self._otel_tracing_storage = self._validate_otel_tracing_storage(
            otel_tracing_storage
        )

    @public
    @property
    def input_token_price_per_million_tokens(self):
        """Optional input token price used to compute trace cost metrics."""
        return self._input_token_price_per_million_tokens

    @input_token_price_per_million_tokens.setter
    def input_token_price_per_million_tokens(
        self, input_token_price_per_million_tokens: float | None
    ):
        self._input_token_price_per_million_tokens = (
            input_token_price_per_million_tokens
        )

    @public
    @property
    def output_token_price_per_million_tokens(self):
        """Optional output token price used to compute trace cost metrics."""
        return self._output_token_price_per_million_tokens

    @output_token_price_per_million_tokens.setter
    def output_token_price_per_million_tokens(
        self, output_token_price_per_million_tokens: float | None
    ):
        self._output_token_price_per_million_tokens = (
            output_token_price_per_million_tokens
        )

    def __repr__(self):
        return (
            "DeploymentTracingConfig("
            f"enabled: {self._enabled!r}, "
            f"otel_tracing_storage: {self._otel_tracing_storage!r}, "
            f"input_token_price_per_million_tokens: "
            f"{self._input_token_price_per_million_tokens!r}, "
            f"output_token_price_per_million_tokens: "
            f"{self._output_token_price_per_million_tokens!r})"
        )
